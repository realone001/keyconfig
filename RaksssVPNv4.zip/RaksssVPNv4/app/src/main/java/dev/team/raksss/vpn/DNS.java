package dev.team.raksss.vpn;

import android.os.*;
import android.support.v7.app.*;
import renz.vpn.material.R;



public class DNS extends AppCompatActivity 
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abc_dns_resolver);
		

    }
}
