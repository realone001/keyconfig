package dev.team.raksss.vpn.utils;

public interface WorkerAction {
    void runFirst();

    void runLast();
}
