package net.openvpn.openvpn;
import android.support.v7.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import java.io.*;
import android.content.*;
import renz.vpn.material.*;
import android.text.*;

public class ExportActivity extends AppCompatActivity
{

	private EditText edit;

	private Button btn;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.export_config);
		edit = (EditText)findViewById(R.id.exportconfigEditText);
		btn = (Button)findViewById(R.id.exportconfigButton);
		btn.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View p1)
				{
					if (Environment.getExternalStorageState().equals(Environment.MEDIA_REMOVED)) {
						Toast.makeText(getApplicationContext(), "No SDCARD Found", -1).show();
					} else {
							String path = Environment.getExternalStorageDirectory().getAbsolutePath() +"/Configs";
							File dir = new File(path);
							dir.mkdirs();
							File file = new File(dir, edit.getText().toString() +".ovpn");
						try {
							OutputStream out = new FileOutputStream(file);
							
							String name = getIntent().getStringExtra("PROF_NAME") +".ovpn";
							String s1 = "";
							String s2 = "";
							try {
								s1 = read(ExportActivity.this,"imported",name);
							} catch (Exception e) {
								
							}
							try {
								s2 = read(ExportActivity.this, "bundled",name);
							} catch (Exception e) {
								
							}
							if (s2.isEmpty()) {
								out.write(s1.getBytes());
								out.flush();
								out.close();
							} else {
								out.write(s2.getBytes());
								out.flush();
								out.close();
							}
							Toast.makeText(getApplicationContext(), "Config Exported!",-1).show();
							finish();
							
						} catch (Exception e) {
							Toast.makeText(getApplicationContext(), "Permission: Denied Write External Storage not Granted Go App info and Check Permission Storage", Toast.LENGTH_LONG).show();
						}
					}
					// TODO: Implement this method
				}
				
			
		});
		
	}
	public String read(Context con, String loc, String name) throws IOException
	{
		if (loc.equals("imported")) {
			return FileUtil.readFileAppPrivate(con, name);
		} else if (loc.equals("bundled")) {
			return readAsset(con, name);
		}
		return null;
	}
	private String readAsset(Context con, String name) throws IOException
	{
		StringBuilder b = new StringBuilder();
		Reader reader = new BufferedReader(new InputStreamReader(con.getResources().getAssets().open(name)));
		char[] chars = new char[1024];
		while (true) {
			int i = reader.read(chars,0,chars.length);
			if (i <= 0) {
				break;
			}
			b.append(chars,0,i);
		}
		return b.toString();
	}
	
}
