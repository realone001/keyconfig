package net.openvpn.openvpn;

import android.os.Bundle;
import android.preference.*;
import renz.vpn.material.*;


public class SettingsActivity extends MainBase
{
	public void onCreate(Bundle bundle)
	{
		super.onCreate(bundle);
		setContentView(R.layout.account_container);
		getFragmentManager().beginTransaction().replace(R.id.account_container, new SettingsFragment()).commit();
	}
   public class SettingsFragment extends PreferenceFragment
   {
      public void onCreate(Bundle savedInstanceState)
	  {
         super.onCreate(savedInstanceState);
         addPreferencesFromResource(R.xml.preferences);
      }
	}
}
