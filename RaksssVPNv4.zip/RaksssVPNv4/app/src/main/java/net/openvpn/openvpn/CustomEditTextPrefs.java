package net.openvpn.openvpn;

import android.content.*;
import android.preference.*;
import android.util.*;

public class CustomEditTextPrefs extends EditTextPreference
{
	public CustomEditTextPrefs(Context con, AttributeSet attr)
	{
		super(con,attr);
	}

	@Override
	public void setSummary(CharSequence summary)
	{
		if (summary.toString().isEmpty()) {
			super.setSummary(getSummary());
		} else {
			super.setSummary(summary);
		}
	}

	@Override
	public void setText(String text)
	{
		// TODO: Implement this method
		super.setText(text);
		setSummary(text);
	}
}
