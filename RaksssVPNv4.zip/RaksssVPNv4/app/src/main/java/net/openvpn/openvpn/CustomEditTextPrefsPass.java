package net.openvpn.openvpn;

import android.content.*;
import android.preference.*;
import android.util.*;

public class CustomEditTextPrefsPass extends EditTextPreference
{
	public CustomEditTextPrefsPass(Context con, AttributeSet attr)
	{
		super(con,attr);
	}

	@Override
	public void setSummary(CharSequence summary)
	{
		if (summary.toString().isEmpty()) {
			super.setSummary(getSummary());
		} else {
			super.setSummary(hide(summary.toString()));
		}
	}

	@Override
	public void setText(String text)
	{
		// TODO: Implement this method
		super.setText(text);
		setSummary(text);
	}
	

	private String hide(String toString)
	{
		StringBuilder b = new StringBuilder();
		for (int i = 0; i < toString.length(); i++) {
			b.append("*");
		}
		// TODO: Implement this method
		return b.toString();
	}
	
}
