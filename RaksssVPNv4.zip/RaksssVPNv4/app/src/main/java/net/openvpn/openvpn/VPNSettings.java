package net.openvpn.openvpn;
import android.os.*;
import renz.vpn.material.*;

public class VPNSettings extends MainBase
{
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		setContentView(R.layout.account_container);
		getFragmentManager().beginTransaction().replace(R.id.account_container, new Util.VPNSettings()).commit();
	}
}
