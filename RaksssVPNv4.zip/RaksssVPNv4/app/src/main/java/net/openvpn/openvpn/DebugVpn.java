package net.openvpn.openvpn;

class DebugVpn {
    DebugVpn() {
    }

    public static String pw_repl(String user, String pw) {
        return pw;
    }
}
