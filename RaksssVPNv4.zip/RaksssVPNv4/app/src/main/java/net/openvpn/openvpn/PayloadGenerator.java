package net.openvpn.openvpn;

import android.support.v7.app.*;
import android.os.*;
import android.support.design.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import java.io.*;
import android.content.DialogInterface.*;
import android.preference.*;
import android.content.SharedPreferences.*;
import renz.vpn.material.*;
import android.widget.AdapterView.*;

public class PayloadGenerator extends MainBase implements OnClickListener, OnItemSelectedListener
{
	private EditText url_host;
	private CheckBox online_host;
	private CheckBox forward_host;
	private CheckBox forwarded_for;
	private CheckBox keep_alive;
	private EditText proxy;
	private EditText port;
	private CheckBox pull;
	private CheckBox redirect,defaultRp;
	private Button export_button;
	private Spinner requestMethod,injectionMethod;
	private String[] injectArray,requestArray;
	private RadioGroup radioGroup;
	private SharedPreferences prefs;
	private SharedPreferences.Editor editor;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abc_screen_material_default);
		
		url_host = (EditText)findViewById(R.id.url_host);
		online_host = (CheckBox)findViewById(R.id.online_host);
		forward_host = (CheckBox)findViewById(R.id.forward_host);
		forwarded_for = (CheckBox)findViewById(R.id.forwarded_for);
		keep_alive = (CheckBox)findViewById(R.id.keep_alive);
		proxy = (EditText)findViewById(R.id.remote_proxy);
		port = (EditText)findViewById(R.id.proxy_port);
		pull = (CheckBox)findViewById(R.id.option_pull);
		redirect = (CheckBox)findViewById(R.id.option_redirect_gateway);
		export_button = (Button)findViewById(R.id.export_button);
	    requestMethod = (Spinner)findViewById(R.id.request_method);
		injectionMethod = (Spinner)findViewById(R.id.injection_method);
		radioGroup = (RadioGroup)findViewById(R.id.split_radiogroup);
		defaultRp = (CheckBox)findViewById(R.id.default_proxy);
		
		requestArray = getResources().getStringArray(R.array.request_method);
		injectArray = getResources().getStringArray(R.array.injection_method);
		
		requestMethod.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,requestArray));
		injectionMethod.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, injectArray));
		
		radioGroup.setOnCheckedChangeListener(onChecked());
		export_button.setOnClickListener(this);
		requestMethod.setOnItemSelectedListener(this);
		injectionMethod.setOnItemSelectedListener(this);
		defaultRp.setOnCheckedChangeListener(onCheck());
		prefs = PreferenceManager.getDefaultSharedPreferences(this);
		editor = prefs.edit();
		String name = getIntent().getStringExtra("PROF_NAME")+".ovpn";
		defaultRp.setChecked(prefs.getBoolean(name, false));
		injectionMethod.setSelection(prefs.getInt(Util.SELECTED_INJECTION_METHOD,0));
		requestMethod.setSelection(prefs.getInt(Util.SELECTED_REQUEST_METHOD,0));
		pull.setChecked(prefs.getBoolean(Util.PULL_KEY, false));
		redirect.setChecked(prefs.getBoolean(Util.REDIRECT_KEY, false));
		online_host.setChecked(prefs.getBoolean(Util.ONLINE_HOST_KEY, false));
		forward_host.setChecked(prefs.getBoolean(Util.FORWARD_HOST_KEY, false));
		forwarded_for.setChecked(prefs.getBoolean(Util.FORWARDED_FOR_KEY, false));
		keep_alive.setChecked(prefs.getBoolean(Util.KEEP_ALIVE_KEY, false));
		url_host.setText(prefs.getString(Util.URL_HOST_KET, ""));
		String rp = prefs.getString(Util.PROXY_KEY, "");
		String rp_port = prefs.getString(Util.PORT_KEY, "");
		proxy.setText(defaultRp.isChecked() ? hide(rp): rp);
		port.setText(defaultRp.isChecked() ? hide(rp_port): rp_port);
		((RadioButton)radioGroup.getChildAt(prefs.getInt(Util.SELECTED_SPLIT,0))).setChecked(true);
		
	}

	private CompoundButton.OnCheckedChangeListener onCheck()
	{
		// TODO: Implement this method
		return new CompoundButton.OnCheckedChangeListener()
		{

			@Override
			public void onCheckedChanged(CompoundButton p1, boolean p2)
			{
				String name = getIntent().getStringExtra("PROF_NAME")+".ovpn";
				int id = p1.getId();
				if (id == R.id.default_proxy) {
					if (p1.isChecked()) {
						proxy.setText(hide(Util.getRp(PayloadGenerator.this, name)));
					    port.setText(hide("8080"));
						proxy.setEnabled(false);
						port.setEnabled(false);
						editor.putBoolean(name, true).apply();
					} else {
						proxy.setText("");
						port.setText("");
						proxy.setEnabled(true);
						port.setEnabled(true);
						editor.putBoolean(name, false).apply();
					}
				}
				// TODO: Implement this method
			}
			
			
		};
	}
	public String hide(String str)
	{
		StringBuilder b = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			b.append("*");
		}
		return b.toString();
	}
	private RadioGroup.OnCheckedChangeListener onChecked()
	{
		return new RadioGroup.OnCheckedChangeListener()
		{

			@Override
			public void onCheckedChanged(RadioGroup p1, int p2)
			{
				RadioButton radio = (RadioButton)radioGroup.findViewById(p2);
				editor.putInt(Util.SELECTED_SPLIT, radioGroup.indexOfChild(radio)).apply();
				// TODO: Implement this method
			}
			
			
		};
	}

	@Override
	public void onClick(View p1)
	{
		int id = p1.getId();
		if (id == R.id.export_button) {
		
			editor.putString(Util.URL_HOST_KET, url_host.getText().toString()).commit();
			String name = getIntent().getStringExtra("PROF_NAME")+".ovpn";
			if (defaultRp.isChecked()) {
				editor.putString(Util.PROXY_KEY, Util.getRp(this,name)).apply();
				editor.putString(Util.PORT_KEY, "8080").apply();
			} else {
				editor.putString(Util.PROXY_KEY, proxy.getText().toString()).apply();
				editor.putString(Util.PORT_KEY,port.getText().toString()).apply();
			}
			 if (pull.isChecked()) {
			  editor.putBoolean(Util.PULL_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.PULL_KEY, false).commit();
		   }  if (redirect.isChecked()) {
			  editor.putBoolean(Util.REDIRECT_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.REDIRECT_KEY, false).commit();
		   } if (online_host.isChecked()) {
			  editor.putBoolean(Util.ONLINE_HOST_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.ONLINE_HOST_KEY, false).commit();
		   } if (forward_host.isChecked()) {
			  editor.putBoolean(Util.FORWARD_HOST_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.FORWARD_HOST_KEY, false).commit();
		   } if (forwarded_for.isChecked()) {
			  editor.putBoolean(Util.FORWARDED_FOR_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.FORWARDED_FOR_KEY, false).commit();
		   } if (keep_alive.isChecked()) {
			  editor.putBoolean(Util.KEEP_ALIVE_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.KEEP_ALIVE_KEY, false).commit();
		   } 
		String split = "";
		switch (radioGroup.getCheckedRadioButtonId()) {
			case R.id.split_normal:
				split = "[split]";
				break;
			case R.id.split_delay:
				split = "[delay_split]";
				break;
			case R.id.split_instant:
				split = "[instant_split]";
		}
		String url = url_host.getText().toString();
		String host_port = "[host_port]";
		String proto = "[protocol]";
		String crlf = "[crlf]";
		String sp = new String(new byte[]{32});
		String payloadFormat = "";
		int injectPosition = injectionMethod.getSelectedItemPosition();
		int requestPosition = requestMethod.getSelectedItemPosition();
		String headers = isChecked(online_host.isChecked(),"X-Online-Host:",url,sp,crlf) + isChecked(forward_host.isChecked(),"X-Forward-Host:",url,sp,crlf)+isChecked(forwarded_for.isChecked(),"X-Forwarded-For:",url,sp,crlf)+isKeepAlive(keep_alive.isChecked(),"Connection: Keep-Alive",crlf);
		if (injectPosition == 0) {
			payloadFormat = requestArray[0]+sp+host_port+proto+crlf +"Host: "+url+crlf+headers+crlf;
		} else if (injectPosition == 1) {
			payloadFormat = requestArray[0]+sp+host_port+proto+crlf+split+crlf+requestArray[requestPosition]+sp+"http://"+url+"/"+sp+"HTTP/1.1"+crlf+headers+crlf;
		} else if (injectPosition == 2) {
			payloadFormat = requestArray[requestPosition]+sp+"http://"+url+"/"+sp+"HTTP/1.1"+crlf+"Host:"+sp+url+crlf+headers+crlf+split+requestArray[0]+sp+host_port+proto+crlf+crlf;
		}
		editor.putString(Util.PAYLOAD_FORM,payloadFormat).apply();
		finish();
		}
		// TODO: Implement this method
	}

	private String isKeepAlive(boolean isChecked, String p1, String crlf)
	{
		if (isChecked) {
			return p1+crlf;
		}
		// TODO: Implement this method
		return "";
	}
	@Override
	public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
	{
		int id = p1.getId();
		if (id == R.id.request_method) {
			if (p3 == 0) {
				injectionMethod.setSelection(0);
			}
			editor.putInt(Util.SELECTED_REQUEST_METHOD,p3).apply();
		} else if (id == R.id.injection_method) {
			if (p3 == 0) {
				requestMethod.setSelection(0);
			}
			editor.putInt(Util.SELECTED_INJECTION_METHOD,p3).apply();
		}
		// TODO: Implement this method
	}

	@Override
	public void onNothingSelected(AdapterView<?> p1)
	{
		// TODO: Implement this method
	}
	public String isChecked(boolean z, String header, String url,String sp,String crlf)
	{
		if (z) {
			return header+sp+url+crlf;
		}
		return "";
	}
	 
}
