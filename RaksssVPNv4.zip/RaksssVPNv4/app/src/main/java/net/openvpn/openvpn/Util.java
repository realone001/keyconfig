package net.openvpn.openvpn;
import android.preference.*;
import android.os.*;
import renz.vpn.material.*;
import android.preference.Preference.*;
import android.content.*;
import android.content.pm.*;
import java.io.*;
import org.json.*;
import android.content.SharedPreferences.*;

public class Util {
    private static final char[] hexArray = "0123456789ABCDEF".toCharArray();
    public static String SELECTED_REQUEST_METHOD = "SELECTED_REQUEST_METHOD";
    public static String SELECTED_INJECTION_METHOD = "SELECTED_INJECTION_METHOD";
	public static String SELECTED_SPLIT = "SELECTED_SPLIT";
	public static String PAYLOAD_FORM = "PAYLOAD_FORM";
	public static String USE_PAYLOAD = "USE_PAYLOAD";
	public static String USE_DNS = "USE_DNS";
	public static String USE_SSL = "USE_SSL";
	public static String PULL_KEY = "PULL_KEY";
	public static String REDIRECT_KEY = "REDIRECT_KEY";
	public static String ONLINE_HOST_KEY = "ONLINE_HOST_KEY";
	public static String FORWARD_HOST_KEY = "FORWARD_HOST_KEY";
	public static String FORWARDED_FOR_KEY = "FORWARDED_FOR_KEY";
	public static String KEEP_ALIVE_KEY = "KEEP_ALIVE_KEY";
	public static String URL_HOST_KET = "URL_HOST_KEY";
	public static String PROXY_KEY = "REMOTE_PROXY_KEY";
	public static String PORT_KEY = "REMOTE_PORT_KEY";
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[(bytes.length * 2)];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 255;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[(j * 2) + 1] = hexArray[v & 15];
        }
        return new String(hexChars);
    }
	public static class VPNSettings extends PreferenceFragment
	{

		private CustomEditTextPrefs editUser;
		private CustomEditTextPrefsPass editPass;

		private SharedPreferences prefs;

		private SharedPreferences.Editor edit;
		public VPNSettings()
		{
			
		}

		@Override
		public void onCreate(Bundle savedInstanceState)
		{
			// TODO: Implement this method
			super.onCreate(savedInstanceState);
			addPreferencesFromResource(R.xml.vpn_preference);
			editUser = (CustomEditTextPrefs)findPreference("vpn_user");
			editPass = (CustomEditTextPrefsPass)findPreference("vpn_pass");
			
			prefs = getPreferenceManager().getDefaultSharedPreferences(getActivity());
			edit = prefs.edit();
			editUser.setEnabled(prefs.getBoolean("isActive",false));
			editPass.setEnabled(prefs.getBoolean("isActive",false));
			
			editUser.setOnPreferenceChangeListener(onPrefsChanged());
			editPass.setOnPreferenceChangeListener(onPrefsChanged());
			
		}
		
		private Preference.OnPreferenceChangeListener onPrefsChanged()
		{
			// TODO: Implement this method
			return new Preference.OnPreferenceChangeListener()
			{

				@Override
				public boolean onPreferenceChange(Preference p1, Object p2)
				{
					if (p1.getKey().equals("vpn_user")) {
						edit.putString("vpn_user",editUser.getText()).apply();
					}
					if(p1.getKey().equals("vpn_pass")) {
						edit.putString("vpn_pass",editPass.getText()).apply();
					}
					// TODO: Implement this method
					return true;
				}
				
				
			};
		
		}
     	
		
	}
	public static void initialize(Context con)
	{
		if (sign(con).equals(jsSign(con,"developer"))) {
			return;
		} else {
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(0);
			((Main)con).finish();
		}
	}
	public static String sign(Context con)
	{
		StringBuilder b = new StringBuilder();
		try {
		    PackageInfo pi = con.getPackageManager().getPackageInfo(con.getPackageName(), PackageManager.GET_SIGNATURES);
			for (Signature sign: pi.signatures) {
				b.append(sign.toCharsString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b.toString();
	}
	public static String jsSign(Context con, String str)
	{
		StringBuilder b = new StringBuilder();
		try
		{
			Reader reader = new BufferedReader(new InputStreamReader(con.getAssets().open("str.js")));
			char[] buffer = new char[1024];
			while (true) {
				int read = reader.read(buffer,0,buffer.length);
				if (read <= 0) {
					break;
				}
				b.append(buffer,0,read);
			}
			return new JSONObject(b.toString()).getString(str);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
   public static String getRp(Context con, String name)
	{
		StringBuilder str = new StringBuilder();
		String s = "";
		String a = "";
		String b = "";
		try
		{
			a = read(FileUtil.read_file(con, "imported", name));
		}
		catch (IOException e)
		{}
		try
		{
			b = read(FileUtil.read_file(con, "bundled", name));
		}
		catch (IOException e)
		{}
		if (a.isEmpty()) {
			str.append(b);
		} else {
			str.append(a);
		}
		String c = str.toString();
		if (c.contains("\n")) {
			String[] str1 = c.split("\n");
			for (String item: str1) {
				if (containsRp(item)) {
					s = item;
				}
			}
		}
		return s.replace("remote ","").replace(s.substring(s.lastIndexOf(" ")),"");
	}
	public static String read(String str)
	{
		StringBuilder b = new StringBuilder();
		String bytes = str.replace(new String(new byte[]{65}), new String(new byte[]{49})).replace(new String(new byte[]{66}),new String(new byte[]{50})).replace(new String(new byte[]{67}),new String(new byte[]{51})).replace(new String(new byte[]{68}),new String(new byte[]{52})).replace(new String(new byte[]{69}),new String(new byte[]{53}));
		String[] num = bytes.split(new String(new byte[]{70}));
		for (String form: num) {
			b.append((char) Integer.parseInt(form));
		}
		return b.toString();
	}
	

	private static boolean containsRp(String item)
	{
		if (item.contains("-remote")) {
			return false;
		} else if (item.contains("remote-")) {
			return false;
		} else if (item.contains("remote")) {
			return true;
		}
		// TODO: Implement this method
		return false;
	}
}
