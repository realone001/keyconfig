package net.openvpn.openvpn.Activity;

import com.github.javiersantos.appupdater.enums.AppUpdaterError;
import com.github.javiersantos.appupdater.enums.Display;
import com.github.javiersantos.appupdater.enums.Duration;
import com.github.javiersantos.appupdater.enums.UpdateFrom;
import com.github.javiersantos.appupdater.interfaces.IAppUpdater;
import com.github.javiersantos.appupdater.objects.GitHub;
import com.github.javiersantos.appupdater.objects.Update;
import android.content.*;
import com.github.javiersantos.appupdater.AppUpdater;
import net.openvpn.openvpn.*;

public class ApplicationUpdater
{
	public AppUpdater n;
	public static AppUpdater d;
	public static String app_url = "https://pastebin.com/raw/JmWvcrYM";
	public ApplicationUpdater(OpenVPNClient h){
		n = new AppUpdater(h);
		n.setUpdateFrom(UpdateFrom.JSON);
		n.setUpdateJSON(app_url);
		n.setDisplay(Display.NOTIFICATION);
		n.showAppUpdated(true);
		n.start2();
		d = new AppUpdater(h);
		d.setDisplay(Display.DIALOG);
		d.setUpdateFrom(UpdateFrom.JSON);
		d.setUpdateJSON(app_url);
		d.setTitleOnUpdateAvailable("CyberZone New Update");
		d.setButtonDoNotShowAgain(null);
		d.setCancelable(true);
		d.showAppUpdated(true);
		d.start2();
	}
	public static void appUpdaterManual(OpenVPNClient h1){
		d = new AppUpdater(h1);
		d.setDisplay(Display.DIALOG);
		d.setUpdateFrom(UpdateFrom.JSON);
		d.setUpdateJSON(app_url);
		d.setTitleOnUpdateAvailable("Update is available");
		d.setTitleOnUpdateNotAvailable("Update not available");
		d.setContentOnUpdateNotAvailable("No update version available. Check for updates again later!");
		d.setButtonDoNotShowAgain(null);
		d.setCancelable(false);
		d.showAppUpdated(true);
		d.start1();
	}
}
