package net.openvpn.openvpn.Utils;

import android.content.*;
import android.preference.*;
import harlies.paid.ovpn.com.ph.*;


public class ThemeUtils {


    public static void setTheme(Context fagmmmu, int theme){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(fagmmmu);
        pref.edit().putInt(fagmmmu.getString(R.string.prefs_themes_key),theme).apply();
    }
    public static int getTheme(Context fagmmmu){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(fagmmmu);
        return pref.getInt(fagmmmu.getString(R.string.prefs_themes_key),R.style.AppTheme);
    }



}

