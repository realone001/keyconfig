package net.openvpn.openvpn.Activity;

import android.app.*;
import android.content.*;
import android.os.*;
import android.util.*;
import java.io.*;
import java.net.*;
import android.preference.*;
import android.content.SharedPreferences.*;
import net.openvpn.openvpn.*;
import net.openvpn.openvpn.Utils.*;

public class AutoUpdateCF extends AsyncTask<String, String, String> {
    private static final String TAG = "NetGuard.Download";

    private Context context;

    private Listener listener;
    private PowerManager.WakeLock wakeLock;

	private HttpURLConnection uRLConnection;

	private InputStream is;

	private BufferedReader buffer;

	
	private SharedPreferences pref;

	private SharedPreferences.Editor editor;

	//private ProgressDialog pd;

    public interface Listener {
        void onCompleted(String config);

        void onCancelled();

        void onException(String ex);
    }

    public AutoUpdateCF(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
		pref = PreferenceManager.getDefaultSharedPreferences(context);
		editor = pref.edit();
    }

    @Override
    protected void onPreExecute() {
		/*pd = new ProgressDialog(context);
		 pd.setMessage("Updating, Please wait...");
		 pd.show();*/
    }

    @Override
    protected String doInBackground(String... args) {
		try {
			String api = pref.getString(Util.custom_update_url, "");
			if(!api.startsWith("http")){
				api = new StringBuilder().append("http://").append(pref.getString(Util.custom_update_url, "")).toString();
			}
            URL url = new URL(api);
            uRLConnection = (HttpURLConnection) url.openConnection();
            uRLConnection.setRequestMethod("POST");
            is = uRLConnection.getInputStream();
            buffer = new BufferedReader(new InputStreamReader(is));
            StringBuilder strBuilder = new StringBuilder();
            String line;
            while ((line = buffer.readLine()) != null) {
                strBuilder.append(line);
            }
            return strBuilder.toString();
        } catch (Exception e) {
            return "error";
        } finally {
            if (buffer != null) {
                try {
                    buffer.close();
                } catch (IOException ignored) {
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException ignored) {

                }
            }
            if (uRLConnection != null) {
                uRLConnection.disconnect();
            }
        }
	}

    @Override
    protected void onCancelled() {
        super.onCancelled();
		// Log.i(TAG, "Cancelled");
		//pd.dismiss();
        listener.onCancelled();
    }

    @Override
    protected void onPostExecute(String result) {
		// wakeLock.release();
        //nm.cancel(1);
		//pd.dismiss();
        if (result.equals("error")) {
            listener.onException(result);
        } else
            listener.onCompleted(result);
    }

	
	
	
}

