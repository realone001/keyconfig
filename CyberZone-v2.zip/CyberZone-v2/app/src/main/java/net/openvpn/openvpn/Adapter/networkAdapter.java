package net.openvpn.openvpn.Adapter;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import harlies.paid.ovpn.com.ph.*;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class networkAdapter extends BaseAdapter {
	Context c;
	LayoutInflater inflater;
	ArrayList<HashMap<String, String>> data;
	HashMap<String, String> resultp = new HashMap<String, String>();

	public networkAdapter(Context context,
					  ArrayList<HashMap<String, String>> arraylist) {
		c = context;
		data = arraylist;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}
	public View getView(final int position, View convertView, ViewGroup parent) {
		inflater = (LayoutInflater) c
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		Animation anim = AnimationUtils.loadAnimation(c, R.animator.side_in);
		View itemView = inflater.inflate(R.layout.promo_item, parent, false);
		resultp = data.get(position);
		LinearLayout promoitemLinearLayout = (LinearLayout)itemView.findViewById(R.id.promoitemLinearLayout);
		TextView Name = (TextView)itemView.findViewById(R.id.promo_name);
		ImageView image = (ImageView)itemView.findViewById(R.id.promo_logo);
		
		Name.setText(resultp.get("net_pro"));
		String ovpn_net = resultp.get("net_iv");
		if (ovpn_net.contains(("GTM")))
		{
			image.setImageResource(R.drawable.ic_globe);
		}
		else if (ovpn_net.contains(("TM")))
		{
			image.setImageResource(R.drawable.ic_tm);
		}
		else if (ovpn_net.contains(("GLOBE")))
		{
			image.setImageResource(R.drawable.ic_globe);
		}
		else if (ovpn_net.contains(("TNT")))
		{
			image.setImageResource(R.drawable.ic_tnt);
		}
		else if (ovpn_net.contains(("SMART")))
		{
			image.setImageResource(R.drawable.ic_smart);
		}
		else if (ovpn_net.contains(("SUN")))
		{
			image.setImageResource(R.drawable.ic_sun);
		}
		else if (ovpn_net.contains(("Default")))
		{
			image.setImageResource(R.drawable.harlie_icon);
		}
		promoitemLinearLayout.startAnimation(anim);
		
		return itemView;
	}
}
