package net.openvpn.openvpn.Activity;

import android.os.Bundle;
import net.openvpn.openvpn.*;
import android.preference.*;
import harlies.paid.ovpn.com.ph.*;
import android.app.*;

public class SettingsActivity extends PreferenceActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
    }
}
