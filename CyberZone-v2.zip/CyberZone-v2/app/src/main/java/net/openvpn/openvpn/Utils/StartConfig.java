package net.openvpn.openvpn.Utils;
import net.openvpn.openvpn.*;

public class StartConfig
{
	public static String appName = new String(new byte[]{77,72,73,88,32,79,86,80,78,});
	public String AppName = new String(new byte[]{109,104,105,120,46,111,118,112,110,46,99,111,109,46,112,104,});
	//public String AppName = (OpenVPNClient.S0harli3("dpKJ0zmMsVEyBMZeTo+svQ=="));
	public static String packagen = new String(new byte[]{109,104,105,120,46,111,118,112,110,46,99,111,109,46,112,104,});
	public String default_cf = "";
}

