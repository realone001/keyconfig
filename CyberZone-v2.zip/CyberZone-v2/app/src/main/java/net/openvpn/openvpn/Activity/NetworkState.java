package net.openvpn.openvpn.Activity;
import java.net.*;
import org.apache.http.conn.util.*;
import java.util.*;
import java.io.*;

public class NetworkState
{
	
	
	public String ip()
	{
        String str = "127.0.0.1";
        try
		{
            for (NetworkInterface inetAddresses : Collections.list(NetworkInterface.getNetworkInterfaces()))
			{
                for (InetAddress inetAddress : Collections.list(inetAddresses.getInetAddresses()))
				{
                    if (!inetAddress.isLoopbackAddress())
					{
                        String hostAddress = inetAddress.getHostAddress();
                        if (InetAddressUtils.isIPv4Address(hostAddress))
						{
                            return hostAddress;
                        }
                    }
                }
            }
        }
		catch (Exception e)
		{
        }
        return str;
    }
	public String ping(String str)
	{
        try
		{
            StringBuffer stringBuffer = new StringBuffer();
            java.lang.Process exec = Runtime.getRuntime().exec(new StringBuffer().append("ping -c 1 ").append(str).toString());
            try
			{
				exec.waitFor();
			}
			catch (InterruptedException e)
			{}
            if (exec.exitValue() != 0)
			{
                return str;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            String str2 = "";
            while (true)
			{
                str2 = bufferedReader.readLine();
                if (str2 == null)
				{
                    return getPingStats(stringBuffer.toString());
                }
                stringBuffer.append(new StringBuffer().append(str2).append("\n").toString());
            }
        }
		catch (IOException e)
		{
            return str;
        }
    }

	public String getPingStats(String str)
	{
		String pingError;
        if (str.contains("0% packet loss")){
            int indexOf = str.indexOf("/mdev = ");
            return str.substring(indexOf + 8, str.indexOf(" ms\n", indexOf)).split("/")[2];
        }else if (str.contains("100% packet loss")){
            pingError = "100% packet loss";
            return pingError;
        }else if (str.contains("% packet loss")){
            pingError = "partial packet loss";
            return pingError;
        }else if (str.contains("unknown host")){
            pingError = "unknown host";
            return pingError;
        }else{
            pingError = "unknown error in getPingStats";
            return pingError;
        }
    }
	
}
