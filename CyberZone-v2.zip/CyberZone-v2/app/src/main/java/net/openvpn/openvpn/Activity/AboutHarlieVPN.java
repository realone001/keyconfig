package net.openvpn.openvpn.Activity;
import android.support.v7.app.*;
import android.os.*;
import harlies.paid.ovpn.com.ph.*;
import couk.jenxsol.parallaxscrollview.views.*;

public class AboutHarlieVPN extends AppCompatActivity
{

	private ParallaxScrollView mScrollView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_vpn);
		mScrollView = (ParallaxScrollView) findViewById(R.id.scroll_view);
	}
}
