package net.openvpn.openvpn;

import android.app.Activity;
import android.support.v7.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import net.openvpn.openvpn.OpenVPNService.Challenge;
import net.openvpn.openvpn.OpenVPNService.ConnectionStats;
import net.openvpn.openvpn.OpenVPNService.EventMsg;
import net.openvpn.openvpn.OpenVPNService.LogMsg;
import net.openvpn.openvpn.OpenVPNService.Profile;
import net.openvpn.openvpn.OpenVPNService.ProfileList;
import android.support.v4.view.*;
import android.text.method.ScrollingMovementMethod;
import java.util.*;
import android.view.*;
import android.support.v7.app.*;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.ActionBar.*;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v4.app.*;
import android.support.v4.widget.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import android.support.design.widget.*;
import android.content.*;
import android.content.SharedPreferences.*;
import android.widget.*;
import android.graphics.*;
import java.text.*;
import android.os.*;
import android.content.pm.*;
import android.content.pm.PackageManager.*;
import android.telephony.*;
import android.net.*;
import android.animation.*;
import android.text.*;
import android.text.ClipboardManager;
import org.json.*;
import java.io.*;
import android.webkit.*;
import android.app.ProgressDialog;
import java.net.*;
import net.lingala.zip4j.core.*;
import android.app.AlarmManager;
import java.security.*;
import net.openvpn.openvpn.Utils.Util;
import net.openvpn.openvpn.myDB.*;
import net.openvpn.openvpn.Adapter.*;
import net.openvpn.openvpn.Activity.*;
import org.apache.commons.codec.net.*;
import harlies.paid.ovpn.com.ph.R;
import harlies.paid.ovpn.com.ph.*;
import com.github.mikephil.charting.charts.*;
import com.github.mikephil.charting.components.*;
import android.graphics.*;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.*;
import com.github.mikephil.charting.interfaces.datasets.*;
import com.github.mikephil.charting.interfaces.dataprovider.*;
import android.support.v4.content.*;
import android.text.method.*;

import android.Manifest; 
import android.os.Environment; 
import android.support.annotation.NonNull; 
import android.transition.Fade; 

import net.openvpn.openvpn.Utils.StartConfig;

import net.openvpn.openvpn.BottomNavigation.*;

import java.util.concurrent.*;
import cn.pedant.SweetAlert.SweetAlertDialog;
import com.github.angads25.filepicker.model.*;
import com.github.angads25.filepicker.view.*;
import com.github.angads25.filepicker.controller.*;
import android.media.RingtoneManager;

import couk.jenxsol.parallaxscrollview.views.*;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardedVideoAd;


import net.openvpn.openvpn.Logs.*;
import net.openvpn.openvpn.Utils.*;
import com.getkeepsafe.taptargetview.*;
import android.annotation.*;
import android.util.*;
import android.content.res.*;
import android.view.animation.*;
import com.google.android.gms.ads.reward.*;

public class OpenVPNClient extends OpenVPNClientBase implements OnTouchListener, OnItemSelectedListener, RewardedVideoAdListener
{

	private ImageView h_s_icon;
	private ImageView h_p_icon;
	private View harliesactivityRelativeLayout3;
	private View exit_dialog;
	private View option_dialog;
	private android.widget.Switch themeSwitch;
	private TextView VPN_Settings;
	private TextView ChangeLogs;
	private TextView Contact_Support;
	private TextView About_VPN;
	private TextView NigthMode;
	private TextView DayMode;
	private View updater_dialog;
	private TextView appdater;
	private TextView c_ofline;
	private TextView c_online;
	private View view_navigation;
	private LineChart mChart;
	private GraphHelper graph;
	private Thread dataUpdate;
	private Handler vHandler = new Handler();
	public static View graph_l;
	public static View image_l;
	private ImageView h_b_in;
	private ImageView h_b_out;
	private ImageView h_b_dur;
	private TextView FlipView;
	private ImageView h_acnt_icon;
	private ImageView h_pss_icon;
	private SweetAlertDialog pDialog;
    private static final int REQUEST_IMPORT_PKCS12 = 3;
    private static final int REQUEST_IMPORT_PROFILE = 2;
    private static final int REQUEST_VPN_ACTOR_RIGHTS = 1;
    private static final boolean RETAIN_AUTH = false;
    private static final int S_BIND_CALLED = 1;
    private static final int S_ONSTART_CALLED = 2;
    private static final String TAG = "OpenVPNClient";
    private static final int UIF_PROFILE_SETTING_FROM_SPINNER = 262144;
    private static final int UIF_REFLECTED = 131072;
    private static final int UIF_RESET = 65536;
    private static final boolean UI_OVERLOADED = false;
    private String autostart_profile_name;
    private TextView bytes_in_view;
    private TextView bytes_out_view;
    private Button connect_button;
    private TextView duration_view;
    private FinishOnConnect finish_on_connect = FinishOnConnect.DISABLED;
    private boolean last_active = RETAIN_AUTH;
    private TextView last_pkt_recv_view;
    private EditText password_edit;
    private PrefUtil prefs;
    public static Spinner profile_spin;
    private Spinner proxy_spin;
    private PasswordUtil pwds;
    private Spinner server_spin;
    private int startup_state = 0;
    private Handler stats_timer_handler = new Handler();
    private Runnable stats_timer_task = new Runnable() {
        public void run() {
            OpenVPNClient.this.show_stats();
            OpenVPNClient.this.schedule_stats();
        }
    };
	public static TextView status_view1;
    private boolean stop_service_on_client_exit = RETAIN_AUTH;
    private TextView[] textviews;
    private Handler ui_reset_timer_handler = new Handler();
    private Runnable ui_reset_timer_task = new Runnable() {
        public void run() {
            if (!OpenVPNClient.this.is_active()) {
                OpenVPNClient.this.ui_setup(OpenVPNClient.RETAIN_AUTH, OpenVPNClient.UIF_RESET, null);
            }
        }
    };
    private EditText username_edit;
	private SharedPreferences pref;
	private SharedPreferences.Editor editor;
	private ParallaxScrollView mScrollView;
	private networkAdapter networkAdapt;
	private Spinner cat_spin;
	private ServerAdapter.HarliesAdapter serverAdapt;
	public static List<String> ServerList;
    private enum FinishOnConnect {
        DISABLED,
        ENABLED,
        ENABLED_ACROSS_ONSTART
    }
    private enum ProfileSource {
        UNDEF,
        SERVICE,
        PRIORITY,
        PREFERENCES,
        SPINNER,
        LIST0
    }
	public static String selected_server = "";
	private String payloadInfo = "p_info";
	private View background_view;
	private ArrayList<HashMap<String, String>> networkList = new ArrayList<HashMap<String, String>>();
	public static DataBaseHelper db1;
	public static ConfigKey db;
    public static String hovpnKey = new String(new byte[]{109,104,105,120,46,111,118,112,110,46,99,111,109,46,112,104,});
	private FilePickerDialog dialog;
	private DialogProperties properties;
	private Spinner NetworkSpin;
	private ImageView iv1;
	private BottomSheetBehavior<View> bottomSheetBehavior;
	private View bshl;
	
	private AdView mAdView;
	private InterstitialAd mInterstitialAd;
	private RewardedVideoAd mRewardedVideoAd;
	
	private String[] torrentList = new String[] {
		"com.termux",
		"com.tdo.showbox",
		"com.nitroxenon.terrarium",
		"com.pklbox.translatorspro",
		"com.xunlei.downloadprovider",
		"com.epic.app.iTorrent",
		"hu.bute.daai.amorg.drtorrent",
		"com.mobilityflow.torrent.prof",
		"com.brute.torrentolite",
		"com.nebula.swift",
		"tv.bitx.media",
		"com.DroiDownloader",
		"bitking.torrent.downloader",
		"org.transdroid.lite",
		"com.mobilityflow.tvp",
		"com.gabordemko.torrnado",
		"com.frostwire.android",
		"com.vuze.android.remote",
		"com.akingi.torrent",
		"com.utorrent.web",
		"com.paolod.torrentsearch2",
		"com.delphicoder.flud.paid",
		"com.teeonsoft.ztorrent",
		"megabyte.tdm",
		"com.bittorrent.client.pro",
		"com.mobilityflow.torrent",
		"com.utorrent.client",
		"com.utorrent.client.pro",
		"com.bittorrent.client",
		"torrent",
		"com.AndroidA.DroiDownloader",
		"com.indris.yifytorrents",
		"com.delphicoder.flud",
		"com.oidapps.bittorrent",
		"dwleee.torrentsearch",
		"com.vuze.torrent.downloader",
		"megabyte.dm",
		"com.fgrouptech.kickasstorrents",
		"com.jrummyapps.rootbrowser.classic",
		"com.bittorrent.client",
		"hu.tagsoft.ttorrent.lite",
		"co.we.torrent"};
	public boolean isInstalled(String uri)
	{
        PackageManager pm = OpenVPNClient.this.getPackageManager();
        boolean app_installed = false;
        try
		{
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        }
		catch (PackageManager.NameNotFoundException e)
		{
            app_installed = false;
        }
        return app_installed;
    }
	
	private BottomNavigationViewNew.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
	= new BottomNavigationViewNew.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
			Animation anim = AnimationUtils.loadAnimation(OpenVPNClient.this, R.animator.slide_in);
            switch (item.getItemId()) {

   				case R.id.n_panel:
					String url2 = pref.getString(Util.WEB_PANEL,"");
					MainActivityWebView.Title = "WebPanel";
					if(url2.toString().contains("https://")){
						MainActivityWebView.url_key = pref.getString(Util.WEB_PANEL,"").toString();
					}else{
						MainActivityWebView.url_key = "https://"+pref.getString(Util.WEB_PANEL,"").toString();
					}startActivity(new Intent(OpenVPNClient.this, MainActivityWebView.class));
					harliesactivityRelativeLayout3.setVisibility(8);
					
					
					if (mInterstitialAd.isLoaded()) {
						mInterstitialAd.show();
					} else {
						Log.d("TAG", "The interstitial wasn't loaded yet.");
					}
					if (mRewardedVideoAd.isLoaded()) {
						mRewardedVideoAd.show();
					}
					return true;
					
				case R.id.n_duration:
					new AccountDuration(OpenVPNClient.this);
					harliesactivityRelativeLayout3.setVisibility(8);
					
					
					if (mInterstitialAd.isLoaded()) {
						mInterstitialAd.show();
					} else {
						Log.d("TAG", "The interstitial wasn't loaded yet.");
					}
					if (mRewardedVideoAd.isLoaded()) {
						mRewardedVideoAd.show();
					}
					return true;
					
				case R.id.n_update:
					if (harliesactivityRelativeLayout3.getVisibility() == 8) {
						harliesactivityRelativeLayout3.setVisibility(0);
						updater_dialog.setVisibility(0);
						updater_dialog.startAnimation(anim);
					}else{
						harliesactivityRelativeLayout3.setVisibility(8);
						updater_dialog.setVisibility(8);
					}
					option_dialog.setVisibility(8);
					exit_dialog.setVisibility(8);
					
					
					if (mInterstitialAd.isLoaded()) {
						mInterstitialAd.show();
					} else {
						Log.d("TAG", "The interstitial wasn't loaded yet.");
					}
					if (mRewardedVideoAd.isLoaded()) {
						mRewardedVideoAd.show();
					}
					return true;

				case R.id.n_options:
					
					if (harliesactivityRelativeLayout3.getVisibility() == 8) {
						harliesactivityRelativeLayout3.setVisibility(0);
						option_dialog.setVisibility(0);
						option_dialog.startAnimation(anim);
					}else{
						harliesactivityRelativeLayout3.setVisibility(8);
						option_dialog.setVisibility(8);
					}
					exit_dialog.setVisibility(8);
					updater_dialog.setVisibility(8);
					
					
					if (mInterstitialAd.isLoaded()) {
						mInterstitialAd.show();
					} else {
						Log.d("TAG", "The interstitial wasn't loaded yet.");
					}
					if (mRewardedVideoAd.isLoaded()) {
						mRewardedVideoAd.show();
					}
					return true;

				case R.id.n_exit:
					if (harliesactivityRelativeLayout3.getVisibility() == 8) {
						harliesactivityRelativeLayout3.setVisibility(0);
						exit_dialog.setVisibility(0);
						exit_dialog.startAnimation(anim);
					}else{
						harliesactivityRelativeLayout3.setVisibility(8);
						exit_dialog.setVisibility(8);
					}
					option_dialog.setVisibility(8);
					updater_dialog.setVisibility(8);
					
					
					if (mInterstitialAd.isLoaded()) {
						mInterstitialAd.show();
					} else {
						Log.d("TAG", "The interstitial wasn't loaded yet.");
					}
					if (mRewardedVideoAd.isLoaded()) {
						mRewardedVideoAd.show();
					}
					return true;

            }
            return false;
        }

    };
	public void support(View v){
		String url1 = pref.getString(Util.CONTACTSUPORT,"");
		MainActivityWebView.Title = "ContactSupport";
		if(url1.toString().contains("https://")){
			MainActivityWebView.url_key = pref.getString(Util.CONTACTSUPORT,"").toString();
		}else{
			MainActivityWebView.url_key = "https://"+pref.getString(Util.CONTACTSUPORT,"").toString();
		}startActivity(new Intent(OpenVPNClient.this, MainActivityWebView.class));
		harliesactivityRelativeLayout3.setVisibility(8);
	}
	
public void hide_alert(View v){
	harliesactivityRelativeLayout3.setVisibility(8);
}
	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void updateSystemBar() {
        if (isLollipop()) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme = getTheme();
            theme.resolveAttribute(R.attr.colorPrimaryDark, typedValue, true);
            int color = typedValue.data;
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(color);
        }

    }
	private boolean isLollipop() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }
	public void recreateActivity(final Class h,final Bundle b) {
        SleepyTime(new Runnable() {
				@Override
				public void run() {
					Intent i = new Intent(OpenVPNClient.this,h);
					i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
					if(b!=null){
						i.putExtra(getString(R.string.recreate_key),b);
					}
					finish();
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
					startActivity(i);
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				}
			},200);
    }
    public static void SleepyTime(final Runnable run,final int SleepyTime){
        final Handler h = new Handler();
        Thread sleepyTime = new Thread(){
            public void run() {
                try {
                    Thread.sleep(SleepyTime);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                h.post(run);
            }
        };
        sleepyTime.start();
    }
	
	private void splash(){
		startActivity(new Intent(OpenVPNClient.this, SplashScreen.class));
	}
	
	public void appdater(View v){
		harliesactivityRelativeLayout3.setVisibility(8);
		ApplicationUpdater.appUpdaterManual(this);
	}
	
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		splash();
		Intent intent = getIntent();
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
		this.prefs = new PrefUtil(PreferenceManager.getDefaultSharedPreferences(this));
        this.pwds = new PasswordUtil(PreferenceManager.getDefaultSharedPreferences(this));
		init_default_preferences(this.prefs);
		pref = PreferenceManager.getDefaultSharedPreferences(this);
		editor = pref.edit();
		setContentView(R.layout.h_m);
		load_ui_elements();
		this.db = new ConfigKey(this);
		if (new Boolean(pref.getBoolean("firstStart", true)).booleanValue())
        {
			db.insertData(new StartConfig().default_cf);
			try
			{
				JSONObject obj = new JSONObject(db.getData());
				pref.edit().putString(Util.CHANGELOGS,obj.getString("ReleaseNotes")).commit();
				pref.edit().putInt(Util.CurrentConfigVersion, obj.getInt("UpdateVersion")).commit();
				pref.edit().putString(Util.custom_update_url, obj.getString("DefUpdateURL")).commit();
				pref.edit().putString(Util.CONFIG_V_INFO,obj.getString("UpdateVersion")).commit();
				pref.edit().putString(Util.CONTACTSUPORT,obj.getString("ContactSupport")).commit();
				pref.edit().putString(Util.FACEBOOK_GROUP,obj.getString("facebookGroup")).commit();
				pref.edit().putString(Util.WEB_PANEL,obj.getString("WebPanel")).commit();
				editor.putBoolean("firstStart", false).apply();
			}
			catch (JSONException e)
			{}
			pref.edit().putBoolean("firstStart", false).commit();
		}else{
			new SMSuPdater(this);
		}
		loadProfiles();
		autoUpdateC();
		if (net.openvpn.openvpn.Utils.ThemeUtils.getTheme(getApplicationContext()) == R.style.AppTheme) {
            setTheme(R.style.AppTheme);
			background_view.setBackgroundColor(Color.WHITE);
			view_navigation.setBackgroundColor(Color.WHITE);
			h_b_in.setColorFilter(Color.BLACK);
			h_b_out.setColorFilter(Color.BLACK);
			h_b_dur.setColorFilter(Color.BLACK);
			username_edit.setTextColor(Color.BLACK);
			password_edit.setTextColor(Color.BLACK);
			bytes_in_view.setTextColor(Color.BLACK);
			bytes_out_view.setTextColor(Color.BLACK);
			duration_view.setTextColor(Color.BLACK);
			last_pkt_recv_view.setTextColor(Color.BLACK);
			About_VPN.setTextColor(Color.BLACK);
			Contact_Support.setTextColor(Color.BLACK);
			ChangeLogs.setTextColor(Color.BLACK);
			VPN_Settings.setTextColor(Color.BLACK);
			DayMode.setTextColor(Color.BLACK);
			NigthMode.setTextColor(Color.BLACK);
			appdater.setTextColor(Color.BLACK);
			c_ofline.setTextColor(Color.BLACK);
			c_online.setTextColor(Color.BLACK);
			FlipView.setTextColor(Color.BLACK);
			cat_spin.setPopupBackgroundResource(R.drawable.h_t_sp_ligth);
			profile_spin.setPopupBackgroundResource(R.drawable.h_t_sp_ligth);
			NetworkSpin.setPopupBackgroundResource(R.drawable.h_t_sp_ligth);
			exit_dialog.setBackgroundResource(R.drawable.h_alert_x_l);
			option_dialog.setBackgroundResource(R.drawable.h_alert_x_l);
			updater_dialog.setBackgroundResource(R.drawable.h_alert_x_l);
        } else if (net.openvpn.openvpn.Utils.ThemeUtils.getTheme(getApplicationContext()) == R.style.AppTheme_Dark) {
            setTheme(R.style.AppTheme_Dark);
			background_view.setBackgroundColor(this.getResources().getColor(R.color.grey_800));
			view_navigation.setBackgroundColor(this.getResources().getColor(R.color.grey_800));
			h_b_in.setColorFilter(Color.WHITE);
			h_b_out.setColorFilter(Color.WHITE);
			h_b_dur.setColorFilter(Color.WHITE);
			username_edit.setTextColor(Color.WHITE);
			password_edit.setTextColor(Color.WHITE);
			bytes_in_view.setTextColor(Color.WHITE);
			bytes_out_view.setTextColor(Color.WHITE);
			duration_view.setTextColor(Color.WHITE);
			last_pkt_recv_view.setTextColor(Color.WHITE);
			About_VPN.setTextColor(Color.WHITE);
			Contact_Support.setTextColor(Color.WHITE);
			ChangeLogs.setTextColor(Color.WHITE);
			VPN_Settings.setTextColor(Color.WHITE);
			DayMode.setTextColor(Color.WHITE);
			NigthMode.setTextColor(Color.WHITE);
			appdater.setTextColor(Color.WHITE);
			c_ofline.setTextColor(Color.WHITE);
			c_online.setTextColor(Color.WHITE);
			FlipView.setTextColor(Color.WHITE);
			cat_spin.setPopupBackgroundResource(R.drawable.h_t_sp_dark);
			profile_spin.setPopupBackgroundResource(R.drawable.h_t_sp_dark);
			NetworkSpin.setPopupBackgroundResource(R.drawable.h_t_sp_dark);
			exit_dialog.setBackgroundResource(R.drawable.h_alert_x_d);
			option_dialog.setBackgroundResource(R.drawable.h_alert_x_d);
			updater_dialog.setBackgroundResource(R.drawable.h_alert_x_d);
        } 
        updateSystemBar();
		new ApplicationUpdater(this);
		new DataTrans().reaData(this);
		this.liveData();
		
		mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
		
		MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
     
        mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(OpenVPNClient.this);
        mRewardedVideoAd.setRewardedVideoAdListener(this);
		
		mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
		mInterstitialAd.loadAd(new AdRequest.Builder().build());
		
		loadRewardedVideoAd();
        
		//mScrollView = (ParallaxScrollView) findViewById(R.id.scroll_view);
		String[] categories = {"Premium","VIP","Private"};
		CatSpinAdapter h_cat_adt = new CatSpinAdapter<>(this, categories);
        cat_spin.setAdapter(h_cat_adt);
		cat_spin.setSelection(pref.getInt("CategorySpin", cat_spin.getSelectedItemPosition()));
        cat_spin.setOnItemSelectedListener(this);
		
		ServerList = new ArrayList<String>();
		serverAdapt = new ServerAdapter.HarliesAdapter(this, ServerList);
		profile_spin.setAdapter(serverAdapt);
		
		networkList = Util.parseNetwork(networkList, db.getData());
		networkAdapt = new networkAdapter(this,networkList);
		NetworkSpin.setAdapter(networkAdapt);
		NetworkSpin.setSelection(pref.getInt("NetworkSpin", NetworkSpin.getSelectedItemPosition()));
		NetworkSpin.setOnItemSelectedListener(this);
		
		doBindService();
        warn_app_expiration(this.prefs);
		
		themeSwitch.setChecked(pref.getBoolean("SeTheme", false));
		themeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					Bundle b = new Bundle();
					if(themeSwitch.isChecked())
					{
						ThemeUtils.setTheme(getApplicationContext(), R.style.AppTheme_Dark);
						recreateActivity(OpenVPNClient.class,b);
						editor.putBoolean("SeTheme", true).apply();
					}else {
						ThemeUtils.setTheme(getApplicationContext(), R.style.AppTheme);
						recreateActivity(OpenVPNClient.class,b);
						editor.putBoolean("SeTheme", false).apply();
					}
				}
			});
		connect_button.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p1){
					if (is_active()) {
						submitDisconnectIntent(RETAIN_AUTH);
						status_view1.setText("Disconnected");
					}else{
						if(payloadInfo.isEmpty()){
							start_connect();
						}else{
							if(pref.getString("username", "").startsWith("Torrent")){
								promoAlert();
							}else{
								for (int i=0;i < torrentList.length ;i++)
								{
									if(isInstalled(torrentList[i])){
										pDialog = new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE);
										pDialog.setTitleText("Not Torrent Server");
										pDialog.setContentText("Detected Torrent App\n" + torrentList[i]);
										pDialog.setConfirmText("Exit");
										pDialog.showCancelButton(false);
										pDialog.setCancelable(false);
										pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
												@Override
												public void onClick(SweetAlertDialog sDialog) {
													// reuse previous dialog instance
													if (android.os.Build.VERSION.SDK_INT >= 21) {
														finishAndRemoveTask();
													} else {
														android.os.Process.killProcess(android.os.Process.myPid());
													}
													System.exit(0);
												}
											});
										pDialog.show();
										break;
									}else{
										promoAlert();
										break;
									}
								}
							}
						}
						
					}
				}
			});
		this.properties=new DialogProperties();
        properties.selection_mode = DialogConfigs.SINGLE_MODE;
        properties.selection_type = DialogConfigs.FILE_SELECT;
		properties.extensions = new String[] {".hovpn", ".hovpn"};
		properties.root = Environment.getExternalStorageDirectory();
        dialog = new FilePickerDialog(this, properties);
        dialog.setTitle("Select a File");
        dialog.setPositiveBtnName("Select");
        dialog.setNegativeBtnName("Cancel");
		dialog.setDialogSelectionListener(new DialogSelectionListener() {
                @Override
                public void onSelectedFilePaths(final String[] files)
				{
                    for (String path:files)
					{
                        File file=new File(path);
                        if (file.getName().endsWith(".hovpn") || file.getName().endsWith(".hovpn"))
						{
                            final String data = inet(file.getAbsolutePath());
                            if (TextUtils.isEmpty(data))
							{
								new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.ERROR_TYPE)
									.setTitleText("Oops...")
									.setContentText("Invalid File!")
									.show();
                            }
							else
							{
								try
								{
									StringBuilder buf = new StringBuilder();
									JSONObject obj = new JSONObject(harlieKey(data));
									{
										buf.append(obj.getString("ReleaseNotes"));

									}
									if (obj.getInt("UpdateVersion") == pref.getInt(Util.CurrentConfigVersion, 0))
									{
										new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
											.setTitleText("NO UPDATE")
											.setContentText("No new update available. Please try again soon.")
											.show();
									}
									else
									{
										auto_delete();
										new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
											.setTitleText("CyberZone")
											.setContentText(buf.toString())
											.setConfirmText("UPDATE NOW")
											.showCancelButton(true)
											.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
												@Override
												public void onClick(SweetAlertDialog sDialog) {
													// reuse previous dialog instance
													try
													{
														JSONObject obj = new JSONObject(harlieKey(data));
														db.updateData("1", data);
														pref.edit().putString(Util.CHANGELOGS,obj.getString("ReleaseNotes")).commit();
														pref.edit().putInt(Util.CurrentConfigVersion, obj.getInt("UpdateVersion")).commit();
														pref.edit().putString(Util.custom_update_url, obj.getString("DefUpdateURL")).commit();
														pref.edit().putString(Util.CONFIG_V_INFO,obj.getString("UpdateVersion")).commit();
														pref.edit().putString(Util.CONTACTSUPORT,obj.getString("ContactSupport")).commit();
														pref.edit().putString(Util.WEB_PANEL,obj.getString("WebPanel")).commit();
														auto_delete();
														mRestart();
													}
													catch (Exception e)
													{
														new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
															.setTitleText("CyberZone")
															.setContentText(e.getMessage())
															.show();
													}sDialog.dismiss();
												}
											})
											.show();
									}
								}
								catch (Exception e)
								{
									new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
										.setTitleText("CyberZone")
										.setContentText(e.getMessage())
										.show();
								}
                            }
                        }
						else
						{
							new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
								.setTitleText("CyberZone")
								.setContentText("Something went wrong, Please try again.")
								.show();
                        }
                    }
                }
			});
		bshl.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
						bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
						iv1.animate().setDuration(500).rotation(180);
					} 
					if(bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED){
						bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
						iv1.animate().setDuration(500).rotation(0);
					}
				}
			});
		bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() { 
				@Override 
				public void onStateChanged(@NonNull View view, int i) { 
					switch (i){ 
						case BottomSheetBehavior.STATE_COLLAPSED: 
							bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
							iv1.animate().setDuration(500).rotation(0);
							break; 
						case BottomSheetBehavior.STATE_EXPANDED: 
							bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
							iv1.animate().setDuration(300).rotation(180);
							break; 
						case BottomSheetBehavior.STATE_HIDDEN: 
							bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
							if (iv1.getRotation() == 0) {
								iv1.animate().setDuration(500).rotation(180);
							} else {
								iv1.animate().setDuration(500).rotation(0);
							}
							break;
					} 
				} 
				@Override 
				public void onSlide(@NonNull View view, float v) { 
					//textView.setText("sliding..."); 
				} 
			});
		
		
			BottomNavigationViewNew navigation = (BottomNavigationViewNew) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
		
    }
	private void liveData()
	{
        dataUpdate = new Thread(new Runnable() {
				@Override
				public void run()
				{

					while (!dataUpdate.getName().equals("stopped"))
					{

						vHandler.post(new Runnable() {

								//private static final long xup = 0;

								@Override
								public void run()
								{
									if(status_view1.getText().toString().equals("Connected")){
										graph.start();
									}
								}
							});

						try
						{
							Thread.sleep(1000);
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
						//  progressStatus--;
					}

				}
			});

        dataUpdate.setName("started");
        dataUpdate.start();
    }
	
	public void OnTouch_icon(View v){
		if (image_l.getVisibility() == 0) {
			new Image_Switcher(OpenVPNClient.this, "start");
		}else{
			new Image_Switcher(OpenVPNClient.this, "stop");
		}
	}
	
	private void promoAlert(){
		Animation anim = AnimationUtils.loadAnimation(this, R.animator.pop_in);
		LayoutInflater inflater = LayoutInflater.from(this);
        final View v = inflater.inflate(R.layout.h_promo_alrt, null);
        AlertDialog.Builder builer = new AlertDialog.Builder(this);
        builer.setView(v);
		final ImageView p_icon = (ImageView) v.findViewById(R.id.p_icon);
		final ImageView p_iv = (ImageView) v.findViewById(R.id.p_iv);
		final TextView showPromoTitle = (TextView) v.findViewById(R.id.showPromoTitle);
        final TextView showPromoSms = (TextView) v.findViewById(R.id.showPromoSms);
		final Button cancel = (Button) v.findViewById(R.id.dismiss);
		final Button cont = (Button) v.findViewById(R.id.cont);
		showPromoTitle.setText("Read me first!");
		try {
			JSONObject obj = getNetworksArray().getJSONObject(NetworkSpin.getSelectedItemPosition());
			showPromoSms.setText(obj.getString("Info"));
			if (obj.getString("Network").contains(("GTM")))
		{
			p_iv.setImageResource(R.drawable.ic_globe);
		}
			else if (obj.getString("Network").contains(("TM")))
		{
			p_iv.setImageResource(R.drawable.ic_tm);
		}
			else if (obj.getString("Network").contains(("GLOBE")))
		{
			p_iv.setImageResource(R.drawable.ic_globe);
		}
			else if (obj.getString("Network").contains(("TNT")))
		{
			p_iv.setImageResource(R.drawable.ic_tnt);
		}
			else if (obj.getString("Network").contains(("SMART")))
		{
			p_iv.setImageResource(R.drawable.ic_smart);
		}
			else if (obj.getString("Network").contains(("SUN")))
		{
			p_iv.setImageResource(R.drawable.ic_sun);
		}
			else if (obj.getString("Network").contains(("Default")))
		{
			p_iv.setImageResource(R.drawable.harlie_icon);
		}
		} catch (Exception e) {
			Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
		}
        builer.setCancelable(false);
        final AlertDialog alert = builer.create();
        alert.getWindow().setGravity(Gravity.CENTER);
        alert.show();
        cancel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					alert.cancel();
				}

			});
		cont.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					start_connect();
					graph.start();
					alert.cancel();
				}
			});
		p_icon.startAnimation(anim);
			}
			
	private void pckgName(){
		if (!(((String) getPackageManager().getApplicationLabel(getApplicationInfo())).equals(new StartConfig().appName) && getPackageName().equals(new StartConfig().packagen))) {
			pDialog = new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE);
			pDialog.setTitleText("OOPS APP MODIFIED");
			pDialog.setContentText("Please install the original application version.");
			pDialog.setConfirmText("OK");
			pDialog.showCancelButton(false);
			pDialog.setCancelable(false);
			pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
					@Override
					public void onClick(SweetAlertDialog sDialog) {
						// reuse previous dialog instance
						if (android.os.Build.VERSION.SDK_INT >= 21) {
							finishAndRemoveTask();
						} else {
							android.os.Process.killProcess(android.os.Process.myPid());
						}
						System.exit(0);
					}
				});
			pDialog.show();
	  }
	}
	
	public void exit(View v){
		if(is_active()){
			OpenVPNClient.this.stopService(new Intent(OpenVPNClient.this, OpenVPNService.class));
		}
		System.exit(0);
	}
	public void minimize(View v){
		Intent intent = new Intent("android.intent.action.MAIN"); 
		Intent intent3 = intent; 
		intent = intent3.addCategory("android.intent.category.HOME"); 
		intent = intent3.setFlags(268435456); 
		startActivity(intent3); 
		harliesactivityRelativeLayout3.setVisibility(8);
		exit_dialog.setVisibility(8);
	}
	public void cancel(View v){
		harliesactivityRelativeLayout3.setVisibility(8);
		exit_dialog.setVisibility(8);
	}
	
	@Override
	public void onBackPressed() {
		new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE)
			.setTitleText("CyberZone")
			.setContentText("Do you want to minimize or exit?")
			.setCancelText("MINIMIZE")
			.setConfirmText("EXIT")
			.showCancelButton(true)
			.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
				@Override
				public void onClick(SweetAlertDialog sDialog) {
					Intent intent = new Intent("android.intent.action.MAIN"); 
					Intent intent3 = intent; 
					intent = intent3.addCategory("android.intent.category.HOME"); 
					intent = intent3.setFlags(268435456); 
					startActivity(intent3); 
					sDialog.dismiss();
				}
			})
			.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
				@Override
				public void onClick(SweetAlertDialog sDialog) {
					if(is_active()){
						OpenVPNClient.this.stopService(new Intent(OpenVPNClient.this, OpenVPNService.class));
					}
					System.exit(0);
				}
			})
			.show();
	}
	@Override
	protected void onResume(){
		mRewardedVideoAd.resume(this);
		super.onResume();
		loadProfiles();
	}
	public void about(View v){
		harliesactivityRelativeLayout3.setVisibility(8);
		startActivity(new Intent(OpenVPNClient.this, AboutHarlieVPN.class));
	}
	
	public void private_log(View v){
		startActivity(new Intent(OpenVPNClient.this, OpenVPNLog.class));
	}
	public void vpnsetting(View v){
		harliesactivityRelativeLayout3.setVisibility(8);
		startActivity(new Intent(this, SettingsActivity.class));
	}
	
	
	private void loadRewardedVideoAd() {
	mRewardedVideoAd.loadAd("ca-app-pub-3940256099942544/5224354917",
	new AdRequest.Builder().build());
	
	}
	
	@Override
	public void onRewarded(RewardItem reward) {
		Toast.makeText(this, "onRewarded! currency: " + reward.getType() + "  amount: " +
					   reward.getAmount(), Toast.LENGTH_SHORT).show();
		// Reward the user.
	}

	@Override
	public void onRewardedVideoAdLeftApplication() {
		Toast.makeText(this, "onRewardedVideoAdLeftApplication",
					   Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onRewardedVideoAdClosed() {
		Toast.makeText(this, "onRewardedVideoAdClosed", Toast.LENGTH_SHORT).show();
		loadRewardedVideoAd();
	}

	@Override
	public void onRewardedVideoAdFailedToLoad(int errorCode) {
		Toast.makeText(this, "onRewardedVideoAdFailedToLoad", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onRewardedVideoAdLoaded() {
		Toast.makeText(this, "onRewardedVideoAdLoaded", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onRewardedVideoAdOpened() {
		Toast.makeText(this, "onRewardedVideoAdOpened", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onRewardedVideoStarted() {
		Toast.makeText(this, "onRewardedVideoStarted", Toast.LENGTH_SHORT).show();
	}
	

	@Override
	public void onPause() {
		mRewardedVideoAd.pause(this);
		super.onPause();
	}
	
	
    protected void onNewIntent(Intent intent) {
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onNewIntent intent=%s", objArr));
        setIntent(intent);
    }

    protected void post_bind() {
        Log.d(TAG, "CLI: post bind");
        this.startup_state |= S_BIND_CALLED;
        process_autostart_intent(is_active());
        render_last_event();
        refresh_log_view();
    }

    public void event(EventMsg ev) {
        render_event(ev, RETAIN_AUTH, is_active(), RETAIN_AUTH);
    }

    private void render_last_event() {
        boolean active = is_active();
        EventMsg ev = get_last_event();
        if (ev != null) {
            render_event(ev, true, active, true);
        } else if (n_profiles_loaded() > 0) {
            render_event(EventMsg.disconnected(), true, active, true);
        } else {
            hide_status();
            ui_setup(active, UIF_RESET, null);
        }
        EventMsg pev = get_last_event_prof_manage();
        if (pev != null) {
            render_event(pev, true, active, true);
        }
    }


    private void reset_conn_info() {
        show_conn_info(new ClientAPI_ConnectionInfo());
    }

    private void show_conn_info(ClientAPI_ConnectionInfo ci) {
        set_visibility_stats_expansion_group();
    }

    private void set_visibility_stats_expansion_group() {
        int i = 0;
        boolean expand_stats = this.prefs.get_boolean("expand_stats", RETAIN_AUTH);
        if (!expand_stats) {
            i = 8;
        }
    }

    private void render_event(EventMsg ev, boolean reset, boolean active, boolean cached) {
        int flags = ev.flags;
        if (ev.is_reflected(this)) {
            flags |= UIF_REFLECTED;
        }
        if (reset || (flags & 8) != 0 || ev.profile_override != null) {
            ui_setup(active, UIF_RESET | flags, ev.profile_override);
        } else if (ev.res_id == R.string.core_thread_active) {
            active = true;
            ui_setup(true, flags, null);
        } else if (ev.res_id == R.string.core_thread_inactive) {
            active = RETAIN_AUTH;
            ui_setup(RETAIN_AUTH, flags, null);
        }
        switch (ev.res_id) {
            case R.string.connected /*2131099673*/:
				bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
				iv1.animate().setDuration(500).rotation(0);
                break;
            case R.string.tun_iface_create /*2131099693*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tun_ko_title), resString(R.string.tun_ko_error));
                    break;
                }
                break;
            case R.string.tap_not_supported /*2131099694*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tap_unsupported_title), resString(R.string.tap_unsupported_error));
                    break;
                }
                break;
        }
        if (ev.priority >= S_BIND_CALLED) {
            
            if (ev.res_id == R.string.connected) {
                show_status(ev.res_id);
                if (ev.conn_info != null) {
                    show_conn_info(ev.conn_info);
                }
            } else if (ev.info.length() > 0) {
                Object[] objArr = new Object[S_ONSTART_CALLED];
                objArr[0] = resString(ev.res_id);
                objArr[S_BIND_CALLED] = ev.info;
                show_status(String.format("%s : %s", objArr));
            } else {
                show_status(ev.res_id);
            }
        }
        show_stats();
        if (ev.res_id == R.string.connected && this.finish_on_connect != FinishOnConnect.DISABLED) {
            if (this.prefs.get_boolean("autostart_finish_on_connect", RETAIN_AUTH)) {
                final Activity self = this;
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        if (OpenVPNClient.this.finish_on_connect != FinishOnConnect.DISABLED) {
                            self.finish();
                        }
                    }
                }, 1000);
                return;
            }
            this.finish_on_connect = FinishOnConnect.DISABLED;
        }
    }

    private void stop_service() {
        submitDisconnectIntent(true);
    }

    private void stop() {
        cancel_stats();
        doUnbindService();
        if (this.stop_service_on_client_exit) {
            Log.d(TAG, "CLI: stopping service");
            stop_service();
        }
    }

    protected void onStop() {
        Log.d(TAG, "CLI: onStop");
        cancel_stats();
        super.onStop();
    }

    protected void onStart() {
        super.onStart();
        Log.d(TAG, "CLI: onStart");
        this.startup_state |= S_ONSTART_CALLED;
        if (this.finish_on_connect == FinishOnConnect.ENABLED) {
            this.finish_on_connect = FinishOnConnect.ENABLED_ACROSS_ONSTART;
        }
        boolean active = is_active();
        if (active) {
            schedule_stats();
        }
        if (process_autostart_intent(active)) {
            ui_setup(active, UIF_RESET, null);
        }
    }

    protected void onDestroy() {
        stop();
		mRewardedVideoAd.destroy(this);
        Log.d(TAG, "CLI: onDestroy called");
        super.onDestroy();
    }

    private boolean process_autostart_intent(boolean active) {
        if ((this.startup_state & REQUEST_IMPORT_PKCS12) == REQUEST_IMPORT_PKCS12) {
            Intent intent = getIntent();
            String apn_key = "net.openvpn.openvpn.AUTOSTART_PROFILE_NAME";
            String apn = intent.getStringExtra(apn_key);
            if (apn != null) {
                this.autostart_profile_name = null;
                String str = TAG;
                Object[] objArr = new Object[S_BIND_CALLED];
                objArr[0] = apn;
                Log.d(str, String.format("CLI: autostart: %s", objArr));
                intent.removeExtra(apn_key);
                if (!active) {
                    ProfileList proflist = profile_list();
                    if (proflist == null || proflist.get_profile_by_name(apn) == null) {
                        ok_dialog(resString(R.string.profile_not_found), apn);
                    } else {
                        this.autostart_profile_name = apn;
                        return true;
                    }
                } else if (!current_profile().get_name().equals(apn)) {
                    this.autostart_profile_name = apn;
                    submitDisconnectIntent(RETAIN_AUTH);
                }
            }
        }
        return RETAIN_AUTH;
    }

    private void cancel_ui_reset() {
        this.ui_reset_timer_handler.removeCallbacks(this.ui_reset_timer_task);
    }

    

    private void hide_status() {
		this.status_view1.setVisibility(8);
    }

    private void show_status(String text) {
		this.status_view1.setVisibility(0);
		if(text.contains(getString(R.string.proxy_error))){
			status_view1.setText("proxy_error");
		}else if(text.contains("Transport error on")){
			status_view1.setText("Transport error");
		}else{
			this.status_view1.setText(text);
		}
    }

    private void show_status(int res_id) {
		this.status_view1.setVisibility(0);
        this.status_view1.setText(res_id);
    }

    private void cancel_stats() {
        this.stats_timer_handler.removeCallbacks(this.stats_timer_task);
    }

    private void schedule_stats() {
        cancel_stats();
        this.stats_timer_handler.postDelayed(this.stats_timer_task, 1000);
    }

    private static String render_bandwidth(long bw) {
        String postfix;
        float div;
        Object[] objArr;
        float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            postfix = "TB";
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            postfix = "GB";
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            postfix = "MB";
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            postfix = "KB";
            div = 1024.0f;
        } else {
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Float.valueOf(bwf);
            return String.format("%.0f", objArr);
        }
        objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Float.valueOf(bwf / div);
        objArr[S_BIND_CALLED] = postfix;
        return String.format("%.2f %s", objArr);
    }

    private String render_last_pkt_recv(int sec) {
        if (sec >= 3600) {
            return resString(R.string.lpr_gt_1_hour_ago);
        }
        String resString;
        Object[] objArr;
        if (sec >= 120) {
            resString = resString(R.string.lpr_gt_n_min_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec / 60);
            return String.format(resString, objArr);
        } else if (sec >= S_ONSTART_CALLED) {
            resString = resString(R.string.lpr_n_sec_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec);
            return String.format(resString, objArr);
        } else if (sec == S_BIND_CALLED) {
            return resString(R.string.lpr_1_sec_ago);
        } else {
            if (sec == 0) {
                return resString(R.string.lpr_lt_1_sec_ago);
            }
            return "";
        }
    }

    private void show_stats() {
        if (is_active()) {
            ConnectionStats stats = get_connection_stats();
            DataTransferGraph.addBytesReceived(manage(stats.bytes_in));
			this.last_pkt_recv_view.setText(render_last_pkt_recv(stats.last_packet_received));
            this.duration_view.setText(OpenVPNClientBase.render_duration(stats.duration));
            this.bytes_in_view.setText(render_bandwidth(stats.bytes_in));
            this.bytes_out_view.setText(render_bandwidth(stats.bytes_out));
        }
    }
	private long manage(long bw)
	{
		float div = 0;
		float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            div = 1024.0f;
        } else {
            return bw;
        }
        
		return (long)div;
	}

    private void clear_stats() {
        this.last_pkt_recv_view.setText("");
        this.duration_view.setText("");
        this.bytes_in_view.setText("");
        this.bytes_out_view.setText("");
        reset_conn_info();
    }

    private int n_profiles_loaded() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.size();
        }
        return 0;
    }

    private String selected_profile_name() {
        selected_server = null;
        ProfileList proflist = profile_list();
        if (proflist != null && proflist.size() > 0) {
            selected_server = proflist.size() == S_BIND_CALLED ? ((Profile) proflist.get(0)).get_name() : ServerAdapter.get_spinner_selected_item(this.profile_spin);
        }
        if (selected_server == null) {
            return "UNDEFINED_PROFILE";
        }
        return selected_server;
    }
    private Profile selected_profile() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.get_profile_by_name(selected_profile_name());
        }
        return null;
    }

    private void h_setup(boolean active, int flags, String profile_override) {
        boolean orig_active = active;
        boolean autostart = RETAIN_AUTH;
        cancel_ui_reset();
        if (!((UIF_RESET & flags) == 0 && orig_active == this.last_active)) {
            if (!(active || this.autostart_profile_name == null)) {
                autostart = true;
                profile_override = this.autostart_profile_name;
                this.autostart_profile_name = null;
            }
            ProfileList proflist = profile_list();
            Profile prof = null;
            if (proflist == null || proflist.size() <= 0) {
            } else {
                ProfileSource ps = ProfileSource.UNDEF;
                if (active) {
                    ps = ProfileSource.SERVICE;
                    prof = current_profile();
                }
                if (prof == null && profile_override != null) {
                    ps = ProfileSource.PRIORITY;
                    prof = proflist.get_profile_by_name(profile_override);
                    if (prof == null) {
                        Log.d(TAG, "CLI: profile override not found");
                        autostart = RETAIN_AUTH;
                    }
                }
                if (prof == null) {
                    if ((UIF_PROFILE_SETTING_FROM_SPINNER & flags) != 0) {
                        ps = ProfileSource.SPINNER;
                        prof = proflist.get_profile_by_name(ServerAdapter.get_spinner_selected_item(this.profile_spin));
                    } else {
                        ps = ProfileSource.PREFERENCES;
                        prof = proflist.get_profile_by_name(this.prefs.get_string("profile"));
                    }
                }
                if (prof == null) {
                    ps = ProfileSource.LIST0;
                    prof = (Profile) proflist.get(0);
                }
                if (ps != ProfileSource.PREFERENCES && (UIF_REFLECTED & flags) == 0) {
                    this.prefs.set_string("profile", prof.get_name());
                    gen_ui_reset_event(true);
                }
                if (ps != ProfileSource.SPINNER) {
                    ServerAdapter.set_spinner_selected_item(this.profile_spin, prof.get_name());
                }
                this.profile_spin.setEnabled(!active ? true : RETAIN_AUTH);
            }
            if (prof != null) {
                if ((UIF_RESET & flags) != 0) {
                    prof.reset_dynamic_challenge();
                }
                EditText focus = null;
                if (!active && (flags & 32) != 0) {
                } else if (active) {
                }
                ProxyList proxy_list = get_proxy_list();
                if (active || proxy_list.size() <= 0) {
                } else {
					ServerAdapter.show_spinner(this, this.proxy_spin, proxy_list.get_name_list(true));
                    String name = proxy_list.get_enabled(true);
                    if (name != null) {
						ServerAdapter.set_spinner_selected_item(this.proxy_spin, name);
                    }
                }
                if (active || !prof.server_list_defined()) {
                } else {
					ServerAdapter.show_spinner(this, this.server_spin, prof.get_server_list().display_names());
                    String server = this.prefs.get_string_by_profile(prof.get_name(), "server");
                    if (server != null) {
						ServerAdapter.set_spinner_selected_item(this.server_spin, server);
                    }
                }
                if (active) {
                } else {
                    boolean is_pwd_save;
                    String saved_pwd;
                    boolean udef = prof.userlocked_username_defined();
                    boolean autologin = prof.get_autologin();
                    boolean pk_pwd_req = prof.get_private_key_password_required();
                    boolean dynamic_challenge = prof.is_dynamic_challenge();
                    if ((!autologin || (autologin && udef)) && !dynamic_challenge) {
                        if (udef) {
                            this.username_edit.setText(prof.get_userlocked_username());
                            set_enabled(this.username_edit, RETAIN_AUTH);
                        } else {
                            set_enabled(this.username_edit, true);
                            String pref_username = this.prefs.get_string_by_profile(prof.get_name(), "username");
                            if (pref_username != null) {
                                this.username_edit.setText(pref_username);
                            } else if (null == null) {
                                focus = this.username_edit;
                            }
                        }
                    }
                    if (pk_pwd_req) {
                        is_pwd_save = this.prefs.get_boolean_by_profile(prof.get_name(), "pk_password_save", RETAIN_AUTH);
                        saved_pwd = null;
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("pk", prof.get_name());
                        }
                    } 
                    if (autologin || dynamic_challenge) {
                    } else {
                        boolean is_auth_pw_save = prof.get_allow_password_save();
                        is_pwd_save = (is_auth_pw_save && this.prefs.get_boolean_by_profile(prof.get_name(), "auth_password_save", true)) ? true : RETAIN_AUTH;
                        saved_pwd = null;
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("auth", prof.get_name());
                        }
                        if (saved_pwd != null) {
                            this.password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.password_edit;
                        }
                    }
                }
                if (orig_active) {
					connect_button.setText("Disconnect");
					cat_spin.setEnabled(false);
					NetworkSpin.setEnabled(false);
					username_edit.setEnabled(false);
					password_edit.setEnabled(false);
                } else {
					connect_button.setText("Connect");
					graph.stop();
					username_edit.setEnabled(true);
					password_edit.setEnabled(true);
					cat_spin.setEnabled(true);
					NetworkSpin.setEnabled(true);
                }
                if (focus != null) {
                    autostart = RETAIN_AUTH;
                }

            } else {

            }
            if (orig_active) {
                schedule_stats();
            } else {
                cancel_stats();
            }
        }
        this.last_active = orig_active;
        if (autostart && !this.last_active) {
            this.finish_on_connect = FinishOnConnect.ENABLED;
            start_connect();
		}
	}
    private void ui_setup(boolean active, int flags, String profile_override) {
        boolean orig_active = active;
        boolean autostart = RETAIN_AUTH;
        cancel_ui_reset();
        if (!((UIF_RESET & flags) == 0 && orig_active == this.last_active)) {
            if (!(active || this.autostart_profile_name == null)) {
                autostart = true;
                profile_override = this.autostart_profile_name;
                this.autostart_profile_name = null;
            }
            ProfileList proflist = profile_list();
            Profile prof = null;
            if (proflist == null || proflist.size() <= 0) {
            } else {
                ProfileSource ps = ProfileSource.UNDEF;
                if (active) {
                    ps = ProfileSource.SERVICE;
                    prof = current_profile();
                }
                if (prof == null && profile_override != null) {
                    ps = ProfileSource.PRIORITY;
                    prof = proflist.get_profile_by_name(profile_override);
                    if (prof == null) {
                        Log.d(TAG, "CLI: profile override not found");
                        autostart = RETAIN_AUTH;
                    }
                }
                if (prof == null) {
                    if ((UIF_PROFILE_SETTING_FROM_SPINNER & flags) != 0) {
                        ps = ProfileSource.SPINNER;
                        prof = proflist.get_profile_by_name(ServerAdapter.get_spinner_selected_item(this.profile_spin));
                    } else {
                        ps = ProfileSource.PREFERENCES;
                        prof = proflist.get_profile_by_name(this.prefs.get_string("profile"));
                    }
                }
                if (prof == null) {
                    ps = ProfileSource.LIST0;
                    prof = (Profile) proflist.get(0);
                }
                if (ps != ProfileSource.PREFERENCES && (UIF_REFLECTED & flags) == 0) {
                    this.prefs.set_string("profile", prof.get_name());
                    gen_ui_reset_event(true);
                }
                if (ps != ProfileSource.SPINNER) {
                    ServerAdapter.set_spinner_selected_item(this.profile_spin, prof.get_name());
                }
                this.profile_spin.setEnabled(!active ? true : RETAIN_AUTH);
            }
            if (prof != null) {
                if ((UIF_RESET & flags) != 0) {
                    prof.reset_dynamic_challenge();
                }
                EditText focus = null;
                if (!active && (flags & 32) != 0) {
                } else if (active) {
                }
                ProxyList proxy_list = get_proxy_list();
                if (active || proxy_list.size() <= 0) {
                } else {
					ServerAdapter.show_spinner(this, this.proxy_spin, proxy_list.get_name_list(true));
                    String name = proxy_list.get_enabled(true);
                    if (name != null) {
						ServerAdapter.set_spinner_selected_item(this.proxy_spin, name);
                    }
                }
                if (active || !prof.server_list_defined()) {
                } else {
					ServerAdapter.show_spinner(this, this.server_spin, prof.get_server_list().display_names());
                    String server = this.prefs.get_string_by_profile(prof.get_name(), "server");
                    if (server != null) {
						ServerAdapter.set_spinner_selected_item(this.server_spin, server);
                    }
                }
                if (active) {
                } else {
                    boolean is_pwd_save;
                    String saved_pwd;
                    boolean udef = prof.userlocked_username_defined();
                    boolean autologin = prof.get_autologin();
                    boolean pk_pwd_req = prof.get_private_key_password_required();
                    boolean dynamic_challenge = prof.is_dynamic_challenge();
                    if ((!autologin || (autologin && udef)) && !dynamic_challenge) {
                        if (udef) {
                            this.username_edit.setText(prof.get_userlocked_username());
                            set_enabled(this.username_edit, RETAIN_AUTH);
                        } else {
                            set_enabled(this.username_edit, true);
                            String pref_username = this.prefs.get_string_by_profile(prof.get_name(), "username");
                            if (pref_username != null) {
                                this.username_edit.setText(pref_username);
                            } else if (null == null) {
                                focus = this.username_edit;
                            }
                        }
                    }
                    if (pk_pwd_req) {
                        is_pwd_save = this.prefs.get_boolean_by_profile(prof.get_name(), "pk_password_save", RETAIN_AUTH);
                        saved_pwd = null;
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("pk", prof.get_name());
                        }
                    } 
                    if (autologin || dynamic_challenge) {
                    } else {
                        boolean is_auth_pw_save = prof.get_allow_password_save();
                        is_pwd_save = (is_auth_pw_save && this.prefs.get_boolean_by_profile(prof.get_name(), "auth_password_save", true)) ? true : RETAIN_AUTH;
                        saved_pwd = null;
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("auth", prof.get_name());
                        }
                        if (saved_pwd != null) {
                            this.password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.password_edit;
                        }
                    }
                }
                if (orig_active) {
					connect_button.setText("Disconnect");
					new Image_Switcher(OpenVPNClient.this, "start");
					graph.start();
					cat_spin.setEnabled(false);
					NetworkSpin.setEnabled(false);
					username_edit.setEnabled(false);
					password_edit.setEnabled(false);
                } else {
					connect_button.setText("Connect");
					new Image_Switcher(OpenVPNClient.this, "stop");
					graph.stop();
					username_edit.setEnabled(true);
					password_edit.setEnabled(true);
					cat_spin.setEnabled(true);
					NetworkSpin.setEnabled(true);
                }
                if (focus != null) {
                    autostart = RETAIN_AUTH;
                }

            } else {
				
            }
            if (orig_active) {
                schedule_stats();
            } else {
                cancel_stats();
            }
        }
        this.last_active = orig_active;
        if (autostart && !this.last_active) {
            this.finish_on_connect = FinishOnConnect.ENABLED;
            start_connect();
			}
	}
	
    private void set_enabled(EditText editText, boolean state) {
        editText.setEnabled(state);
        editText.setFocusable(state);
        editText.setFocusableInTouchMode(state);
    }

	private void start_connect() {
		cancel_ui_reset();
        this.autostart_profile_name = null;
        this.finish_on_connect = FinishOnConnect.DISABLED;
		if(NoInternetConnection()){
			LogFragment.clear();
			Intent intent = VpnService.prepare(this);
			if (intent != null) {
				try {
					Log.d(TAG, "CLI: requesting VPN actor rights");
					startActivityForResult(intent, S_BIND_CALLED);
					return;
				} catch (ActivityNotFoundException e) {
					Log.e(TAG, "CLI: requesting VPN actor rights failed", e);
					ok_dialog(resString(R.string.vpn_permission_dialog_missing_title), resString(R.string.vpn_permission_dialog_missing_text));
					return;
				}
			}
			Log.d(TAG, "CLI: app is already authorized as VPN actor");
			resolve_epki_alias_then_connect();
		}
    }
	
    public boolean onTouch(View v, MotionEvent event) {
        boolean new_expand_stats = RETAIN_AUTH;
        if (!this.prefs.get_boolean("expand_stats", RETAIN_AUTH)) {
            new_expand_stats = true;
        }
        this.prefs.set_boolean("expand_stats", new_expand_stats);
        set_visibility_stats_expansion_group();
        return true;
    }
	private String addServer(String name)
	{
		ServerList.add(name);
		ArrayAdapter<String> addSer = serverAdapt;
		addSer.notifyDataSetChanged();
		return name;
	}
	private boolean isPremium(String str)
	{
		if (str.contains("Premium")) {
			return true;
		}
		return false;
	}
	private boolean isVIP(String str)
	{
		if (str.contains("VIP")) {
			return true;
		}
		return false;
	}
	private boolean isPrivate(String str)
	{
		if (str.contains("Private")) {
			return true;
		}
		return false;
	}
	
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        cancel_ui_reset();
		String str = "";
        int viewid = parent.getId();
		if (viewid == R.id.profile) {
            h_setup(is_active(), 327680, null);
			editor.putInt("SERVER", position).apply();
			if (h_s_icon.getRotation() == 0) {
				h_s_icon.animate().setDuration(200).rotation(180);
			} else {
				h_s_icon.animate().setDuration(200).rotation(0);
			}
        }else if (viewid == R.id.cat_spin){
			ArrayAdapter<String> addSer = serverAdapt;
			if (ServerList.size() > 0) {
				ServerList.clear();
				addSer.notifyDataSetChanged();
			}
			ProfileList proflist = profile_list();
			Profile prof = null;
			try {
				for (int i = 0; i < proflist.size(); i++) {
					prof = proflist.get(i);
					String fn = prof.get_name() + ".ovpn";

					try {
						str = debug(read_file(prof.get_location(), fn));
					} catch (Exception e) {
						Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
					}
					switch (position) {
						case 0:
							if (isPremium(str)) {
								addServer(prof.get_name());
							}
							break;
						case 1:
							if (isVIP(str)) {
								addServer(prof.get_name());
							}
							break;
						case 2:
							if (isPrivate(str)) {
								addServer(prof.get_name());
							}
							break;
						default:
					}
				}
			}catch (Exception e){
			}
			editor.putInt("CategorySpin", position).apply();
		}else if (viewid == R.id.proxy) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_list.set_enabled(ServerAdapter.get_spinner_list_item(this.proxy_spin, position));
                proxy_list.save();
                gen_ui_reset_event(true);
            }
        } else if (viewid == R.id.server) {
            String server = ServerAdapter.get_spinner_list_item(this.server_spin, position);
            this.prefs.set_string_by_profile(ServerAdapter.get_spinner_selected_item(this.profile_spin), "server", server);
            gen_ui_reset_event(true);
        } else if (viewid == R.id.promo_spinner) {
			try {
				JSONObject obj = getNetworksArray().getJSONObject(position);
				payloadInfo = obj.getString("Info").toString();
			} catch (Exception e) {
			}
			editor.putInt("NetworkSpin", position).apply();
			if (h_p_icon.getRotation() == 0) {
				h_p_icon.animate().setDuration(200).rotation(180);
			} else {
				h_p_icon.animate().setDuration(200).rotation(0);
			}
		
		}
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

	protected boolean NoInternetConnection(){
		boolean enabled = true;
		ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = connectivityManager.getActiveNetworkInfo();

		if ((info == null || !info.isConnected() || !info.isAvailable())) {
			enabled = false;
			new SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
				.setTitleText("Oops...")
				.setContentText("No Internet Connection 📵")
				.show();
		}
		return enabled;	
	}
	

    public PendingIntent get_configure_intent(int requestCode) {
        return PendingIntent.getActivity(this, requestCode, getIntent(), 268435456);
    }

    private void resolve_epki_alias_then_connect() {
        resolveExternalPkiAlias(selected_profile(), new EpkiPost() {
            public void post_dispatch(String alias) {
                OpenVPNClient.this.do_connect(alias);
            }
        });
    }

    private void do_connect(String epki_alias) {
        String app_name = "net.openvpn.connect.android";
        String proxy_name = null;
        String server = null;
        String username = null;
        String password = null;
        String pk_password = null;
        String response = null;
        boolean is_auth_pwd_save = RETAIN_AUTH;
        String profile_name = selected_profile_name();
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_name = proxy_list.get_enabled(RETAIN_AUTH);
            }
            server = ServerAdapter.get_spinner_selected_item(this.server_spin);
		username = username_edit.getText().toString();
            if (username.length() > 0) {
                this.prefs.set_string_by_profile(profile_name, "username", username);
            }
            boolean is_pk_pwd_save = true;
            this.prefs.set_boolean_by_profile(profile_name, "pk_password_save", true);
            if (is_pk_pwd_save) {
                this.pwds.set("pk", profile_name, pk_password);
				this.prefs.set_boolean_by_profile(profile_name, "pk_password_save", true);

            }
		password = password_edit.getText().toString();
            this.prefs.set_boolean_by_profile(profile_name, "auth_password_save", true);
            if (is_auth_pwd_save) {
				this.prefs.set_boolean_by_profile(profile_name, "auth_password_save", true);
                this.pwds.set("auth", profile_name, password);

            }
        String vpn_proto = this.prefs.get_string("vpn_proto");
        String conn_timeout = this.prefs.get_string("conn_timeout");
        String compression_mode = this.prefs.get_string("compression_mode");
        clear_stats();
		int promo_index = NetworkSpin.getSelectedItemPosition();
		String profile_index = (String) profile_spin.getSelectedItem();
		String Selected_Configuration = aE23fg(promo_index, profile_index);
		//String Selected_Configuration = aE23fg(NetworkSpin.getSelectedItemPosition(), (String) profile_spin.getSelectedItem());
		submitConnectIntent(profile_name, server, vpn_proto, conn_timeout, Selected_Configuration, username, password, is_auth_pwd_save, pk_password, response, epki_alias, compression_mode, proxy_name, null, null, true, get_gui_version(app_name));
    }
    private void import_profile(String path)
	{
        submitImportProfileViaPathIntent(path);
    }

    protected void onActivityResult(int request, int result, Intent data) {
        String str = TAG;
        Object[] objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Integer.valueOf(request);
        objArr[S_BIND_CALLED] = Integer.valueOf(result);
        Log.d(str, String.format("CLI: onActivityResult request=%d result=%d", objArr));
        String path;
        switch (request) {
            case S_BIND_CALLED /*1*/:
                if (result == -1) {
                    resolve_epki_alias_then_connect();
                    return;
                } else if (result != 0) {
                    return;
                } else {
                    if (this.finish_on_connect == FinishOnConnect.ENABLED) {
                        finish();
                        return;
                    } else if (this.finish_on_connect == FinishOnConnect.ENABLED_ACROSS_ONSTART) {
                        this.finish_on_connect = FinishOnConnect.ENABLED;
                        start_connect();
						if (mInterstitialAd.isLoaded()) {
							mInterstitialAd.show();
						} else {
							Log.d("TAG", "The interstitial wasn't loaded yet.");
						}
                        return;
                    } else {
                        return;
                    }
                }
            case S_ONSTART_CALLED /*2*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PROFILE: %s", objArr));
                    import_profile(path);
                    return;
                }
                return;
            case REQUEST_IMPORT_PKCS12 /*3*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PKCS12: %s", objArr));
                    import_pkcs12(path);
                    return;
                }
                return;
            default:
                super.onActivityResult(request, result, data);
                return;
        }
    }
	
    private void load_ui_elements() {
		this.graph_l = findViewById(R.id.graph_l);
		this.h_b_in = (ImageView) findViewById(R.id.h_b_in);
		this.h_b_out = (ImageView) findViewById(R.id.h_b_out);
		this.h_b_dur = (ImageView) findViewById(R.id.h_b_dur);
		this.mChart = (LineChart) findViewById(R.id.chart1);
		this.graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.amber_A700))).chart(mChart);
		this.image_l = findViewById(R.id.image_l);
		this.harliesactivityRelativeLayout3 = findViewById(R.id.harliesactivityRelativeLayout3);
		this.harliesactivityRelativeLayout3.setVisibility(8);
		this.view_navigation = findViewById(R.id.view_navigation);
		View bottomSheet = findViewById(R.id.bottom_sheet); 
		this.bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
		this.iv1 = (ImageView)findViewById(R.id.ivLogsDown);
	    this.bshl = findViewById(R.id.bshl);
		this.exit_dialog = findViewById(R.id.exit_dialog); 
		this.updater_dialog = findViewById(R.id.updater_dialog);
		this.appdater = (TextView) findViewById(R.id.appdater);
		this.c_ofline = (TextView) findViewById(R.id.c_ofline);
		this.c_online = (TextView) findViewById(R.id.c_online);
		this.background_view = findViewById(R.id.background_view);
		this.h_s_icon = (ImageView) findViewById(R.id.h_s_icon);
		this.h_p_icon = (ImageView) findViewById(R.id.h_p_icon);
		this.h_acnt_icon = (ImageView) findViewById(R.id.h_acnt_icon);
		this.h_pss_icon = (ImageView) findViewById(R.id.h_pss_icon);
		this.About_VPN = (TextView) findViewById(R.id.About_VPN);
		this.Contact_Support = (TextView) findViewById(R.id.Contact_Support);
		this.ChangeLogs = (TextView) findViewById(R.id.ChangeLogs);
		this.VPN_Settings = (TextView) findViewById(R.id.VPN_Settings);
		this.DayMode = (TextView) findViewById(R.id.DayMode);
		this.NigthMode = (TextView) findViewById(R.id.NigthMode);
		this.option_dialog = findViewById(R.id.option_dialog);
		this.themeSwitch = (Switch) findViewById(R.id.themeSwitch);
		this.cat_spin = (Spinner) findViewById(R.id.cat_spin);
        this.profile_spin = (Spinner) findViewById(R.id.profile);
		this.NetworkSpin = (Spinner)findViewById(R.id.promo_spinner);
        this.proxy_spin = (Spinner) findViewById(R.id.proxy);
        this.server_spin = (Spinner) findViewById(R.id.server);
		this.status_view1 = (TextView) findViewById(R.id.status1);
		this.username_edit = (EditText) findViewById(R.id.HarlieUser);
        this.password_edit = (EditText) findViewById(R.id.HarliePass);
        this.connect_button = (Button) findViewById(R.id.connect);
        this.last_pkt_recv_view = (TextView) findViewById(R.id.last_pkt_recv);
        this.duration_view = (TextView) findViewById(R.id.duration_view);
        this.bytes_in_view = (TextView) findViewById(R.id.bytes_in);
        this.bytes_out_view = (TextView) findViewById(R.id.bytes_out);
        this.profile_spin.setOnItemSelectedListener(this);
        this.proxy_spin.setOnItemSelectedListener(this);
        this.server_spin.setOnItemSelectedListener(this);
		this.textviews = new EditText[]{this.username_edit, this.password_edit};
		this.username_edit.setText(pref.getString("username",""));
		this.FlipView = (TextView) findViewById(R.id.FlipView);
		this.username_edit.addTextChangedListener(new TextWatcher(){
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4){
					//h_acnt_icon.setImageResource(R.drawable.h_acnt);
				}
				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4){
					//h_acnt_icon.setImageResource(R.drawable.h_pncl);
				}
				@Override
				public void afterTextChanged(Editable p1){
					//h_acnt_icon.setImageResource(R.drawable.h_acnt);
					editor.putString("username", p1.toString()).apply();
				}
			});
		this.password_edit.setText(pref.getString("password",""));
		this.password_edit.addTextChangedListener(new TextWatcher(){
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4){
				}
				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4){
				}
				@Override
				public void afterTextChanged(Editable p1){
					editor.putString("password", p1.toString()).apply();
				}
			});
		if(FlipView.getText().toString().equals(EasyFlipView.EasyflipView)){
			FlipView.setVisibility(0);
			FlipView.setText(EasyFlipView.EasyflipView);
		}else{
			FlipView.setVisibility(0);
			FlipView.setText(EasyFlipView.EasyflipView);
		}
    }
	
	public void mRestart(){
        try{if (this != null){ PackageManager pm = this.getPackageManager();
                if (pm != null){Intent mStartActivity = pm.getLaunchIntentForPackage(
                        this.getPackageName());
                    if (mStartActivity != null){
                        mStartActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        int mPendingIntentId = android.os.Process.myPid();
                        PendingIntent mPendingIntent = PendingIntent
                            .getActivity(this, mPendingIntentId, mStartActivity,
                                         PendingIntent.FLAG_CANCEL_CURRENT);
                        AlarmManager mgr = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
                        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
                        if(is_active()){
							stopService(new Intent(OpenVPNClient.this, OpenVPNService.class));
						}
                        System.exit(0);
                    }else{Log.e(TAG, "Was not able to restart application, mStartActivity null");}}
				else{Log.e(TAG, "Was not able to restart application, PM null");
                }}else{Log.e(TAG, "Was not able to restart application, Context null");
            }}catch (Exception ex){Log.e(TAG, "Was not able to restart application");
        }}
	
		
		public void c_offline(View v){
			harliesactivityRelativeLayout3.setVisibility(8);
			dialog.show();
		}
		
	public void updateCF(View v){
		harliesactivityRelativeLayout3.setVisibility(8);
		if (NoInternetConnection()) {
			new UpdateAsync(OpenVPNClient.this, new UpdateAsync.Listener() {
					@Override
					public void onCompleted(final String config)
					{
						// TODO: Implement this method
						try
						{
							JSONObject obj = new JSONObject(harlieKey(config));
							StringBuffer sb = new StringBuffer();
							sb.append(obj.getString("ReleaseNotes"));
							if (obj.getInt("UpdateVersion") == pref.getInt(Util.CurrentConfigVersion, 0))
							{
								new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.SUCCESS_TYPE)
									.setTitleText("CyberZone")
									.setContentText("Your config is up to date 😃")
									.show();
							}
							else
							{
								auto_delete();
								new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
									.setTitleText("CyberZone")
									.setContentText(sb.toString())
									.setConfirmText("UPDATE NOW")
									.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
										@Override
										public void onClick(SweetAlertDialog sDialog) {
											// reuse previous dialog instance
											try
											{
												JSONObject obj = new JSONObject(harlieKey(config));
												db.updateData("1", config);
												pref.edit().putString(Util.CHANGELOGS,obj.getString("ReleaseNotes")).commit();
												pref.edit().putInt(Util.CurrentConfigVersion, obj.getInt("UpdateVersion")).commit();
												pref.edit().putString(Util.custom_update_url, obj.getString("DefUpdateURL")).commit();
												pref.edit().putString(Util.CONFIG_V_INFO,obj.getString("UpdateVersion")).commit();
												pref.edit().putString(Util.CONTACTSUPORT,obj.getString("ContactSupport")).commit();
												pref.edit().putString(Util.WEB_PANEL,obj.getString("WebPanel")).commit();
												auto_delete();
											}
											catch (Exception e)
											{
												new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
													.setTitleText("CyberZone")
													.setContentText("Update Fail...❎")
													.show();
											}
											mRestart();
										}
									})
									.show();
							}
						}
						catch (Exception e)
						{
							new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
								.setTitleText("CyberZone")
								.setContentText(e.getMessage())
								.show();
						}
					}

					@Override
					public void onCancelled()
					{
						// TODO: Implement this method
					}

					@Override
					public void onException(String ex)
					{
						new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
							.setTitleText("CyberZone")
							.setContentText("Something went wrong, Please try again.")
							.show();
					}
				}).execute();
		}
	}
	
	public String inet(String path){
        try
        {
            InputStream openRawResource = new FileInputStream(path);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            for (int read = openRawResource.read(); read != -1; read = openRawResource.read())
            {
                byteArrayOutputStream.write(read);
            }
            openRawResource.close();
            return byteArrayOutputStream.toString();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return "";
        }
    }
	
	private void autoUpdateC(){
		new AutoUpdateCF(OpenVPNClient.this, new AutoUpdateCF.Listener() {
				@Override
				public void onCompleted(final String config)
				{
					// TODO: Implement this method
					try
					{
						JSONObject obj = new JSONObject(harlieKey(config));
						if (obj.getInt("UpdateVersion") == pref.getInt(Util.CurrentConfigVersion, 0))
						{
							//spaceNavigationView.showBadgeAtIndex(0, "0", Color.BLACK);
						}
						else
						{
							//spaceNavigationView.showBadgeAtIndex(0, "+📩", Color.BLACK);
							auto_delete();
							TapTargetSequence intro_sequence =  
								new TapTargetSequence(OpenVPNClient.this).
								targets(TapTarget.forView(findViewById(R.id.n_update), "NEW UPDATE AVAILABLE", obj.getString("ReleaseNotes")).id(1)
										.outerCircleColor(R.color.h_c)
										.textColor(android.R.color.black));
							intro_sequence.start();
						}
					}
					catch (Exception e)
					{
					}
				}

				@Override
				public void onCancelled()
				{
					// TODO: Implement this method
				}

				@Override
				public void onException(String ex)
				{
					// TODO: Implement this method
				}
			}).execute();
	}
	
	
	
	public void onAdClosed() {
		// Load the next interstitial.
		mInterstitialAd.loadAd(new AdRequest.Builder().build());
	}
	
	
	public void changelogs(View v)
	{
		harliesactivityRelativeLayout3.setVisibility(8);
		try
		{
			StringBuilder buf = new StringBuilder();
			JSONObject obj = new JSONObject(db.getData());
			{
				buf.append(obj.getString("ReleaseNotes"));
			}
			new SweetAlertDialog(OpenVPNClient.this, SweetAlertDialog.WARNING_TYPE)
				.setTitleText("ChangeLogs")
				.setContentText(buf.toString())
				.show();
		}catch (Exception e){
		}
	}

	public void log(LogMsg lm) {
        if (lm.line.contains("\n")) {
			String[] split = lm.line.split("\n");
			for (String str: split) {
				
				if (str.contains("----- HARLIES OVPN START -----")) {
					LogFragment.addLog(str);
				}
				if (str.contains("SSL Handshake")) {
					LogFragment.addLog(str);
				}
				if (str.contains("RESOLVE")) {
					LogFragment.addLog(str);
				}
				if (str.contains("WAIT_PROXY")) {
					LogFragment.addLog(str);
				}
				if (str.contains("Contacting")) {
					LogFragment.addLog("Contacting ***,***,***,**:**** via HTTP Proxy ");
				}
				if (str.contains("cert. type")) {
					LogFragment.addLog(str);
				}
				if (str.contains("VERIFY OK: cert. type:")) {
					LogFragment.addLog(str);
				}
				if (str.contains("TO PROXY:")) {
					String name = profile_spin.getSelectedItem()+".ovpn";
					if (Util.config(this, name).contains("#Encrypt")) {
						LogFragment.addLog("<b> Payload (Locked)</b>");
					} else {
						//LogFragment.addLog(usePayload.isChecked() ? "Payload Format:"+"\n"+pref.getString(Util.C_Payload,"") : "Payload format : <b>Null</b>");
					}
					LogFragment.addLog("Injecting");
				}
				if (str.contains("Location")) {
					LogFragment.addLog("Please check your promo");
				}
				if (str.contains("Peer Info")) {
					LogFragment.addLog(str);
				}
				if (str.contains("Tunnel Options:")) {
					LogFragment.addLog(str);
				}

				if (str.contains("GET_CONFIG")) {
					LogFragment.addLog(str);
				}
				if (str.contains("PUSH_REQUEST")) {
					LogFragment.addLog(str);
				}
				if (str.contains("AUTH_FAILED")) {
					LogFragment.addLog(str);
				}
				if (str.contains("ASSIGN_IP")) {
					LogFragment.addLog(str);
				} if (str.contains("CONNECTION_TIMEOUT")) {
					LogFragment.addLog(str);
				}
				if (str.contains("EVENT: CONNECTED")) {
					LogFragment.addLog("CONNECTED");
					LogFragment.addLog("Tunnel core started");
				 }
				if (str.contains("DISCONNECTED")) {
					LogFragment.addLog(str);
				}
				if (str.contains("----- HARLIES OVPN STOP -----")) {
					LogFragment.addLog(str);
				}
				if (str.contains("ADD_ROUTES")) {
					LogFragment.addLog(str);
				}
				if (str.contains("PEM_PASSWORD_FAIL")) {
					LogFragment.addLog(str);
				}
				if (str.contains("CERT_VERIFY_FAIL")) {
					LogFragment.addLog(str);
				}
				if (str.contains("TLS_VERSION_MIN")) {
					LogFragment.addLog(str);
				}
				if (str.contains("TUN_SETUP_FAILED")) {
					LogFragment.addLog(str);
				}
				if (str.contains("PROFILE_NOT_FOUND")) {
					LogFragment.addLog(str);
				}
				if (str.contains("CONFIG_FILE_PARSE_ERROR")) {
					LogFragment.addLog(str);
				}
				if (str.contains("NEED_CREDS_ERROR")) {
					LogFragment.addLog(str);
				}
				if (str.contains("CREDS_ERROR")) {
					LogFragment.addLog(str);
				}
				if (str.contains("PROXY_NEED_CREDS")) {
					LogFragment.addLog(str);
				}
				if (str.contains("PROXY_ERROR")) {
					LogFragment.addLog("..........PROXY_ERROR...!..........");
				}
				if (str.contains("CORE_THREAD_ERROR")) {
					LogFragment.addLog(str);
				}
				if (str.contains("EPKI_ERROR")) {
					LogFragment.addLog(str);
				}
			}
		}
	}
	private void refresh_log_view() {
        ArrayDeque<LogMsg> hist = log_history();
        if (hist != null) {
            StringBuilder builder = new StringBuilder();
            Iterator it = hist.iterator();
            while (it.hasNext()) {
                builder.append(((LogMsg) it.next()).line);
            }
			if (builder.toString().contains("\n")) {
                String[] split = builder.toString().split("\n");
                for (String str: split) {
					if (str.contains("----- HARLIES OVPN START -----")) {
						LogFragment.addLog(str);
					}
					if (str.contains("RECONNECTING")) {
						LogFragment.addLog(str);
					}
					if (str.contains("SSL Handshake")) {
						LogFragment.addLog(str);
					}
					if (str.contains("RESOLVE")) {
						LogFragment.addLog(str);
					}
					if (str.contains("Contacting")) {
						LogFragment.addLog("Contacting ***,***,***,**:**** via HTTP Proxy ");
					}
					if (str.contains("cert. type")) {
						LogFragment.addLog(str);
					}
					if (str.contains("VERIFY OK: cert. type:")) {
						LogFragment.addLog(str);
					}
					if (str.contains("TO PROXY:")) {
						String name = profile_spin.getSelectedItem()+".ovpn";
						if (Util.config(this, name).contains("#Encrypt")) {
							LogFragment.addLog("<b> Payload (Locked)</b>");
						} else {
							//LogFragment.addLog(usePayload.isChecked() ? "Payload Format:"+"\n"+pref.getString(Util.C_Payload,"") : "Payload format : <b>Null</b>");
						}
						LogFragment.addLog("Injecting");
					}
					if (str.contains("Peer Info")) {
						LogFragment.addLog(str);
					}
					if (str.contains("Tunnel Options:")) {
						LogFragment.addLog(str);
					}

					if (str.contains("Location")) {
						LogFragment.addLog("Please check your promo");
					}
					if (str.contains("GET_CONFIG")) {
						LogFragment.addLog(str);
					}
					if (str.contains("PUSH_REQUEST")) {
						LogFragment.addLog(str);
					}
					if (str.contains("AUTH_FAILED")) {
						LogFragment.addLog(str);
					}
					if (str.contains("ASSIGN_IP")) {
						LogFragment.addLog(str);
					} if (str.contains("CONNECTION_TIMEOUT")) {
						LogFragment.addLog(str);
					}
					 if (str.contains("EVENT: CONNECTED")) {
						 LogFragment.addLog("CONNECTED");
						 LogFragment.addLog("Tunnel core started");
					 }
					if (str.contains("DISCONNECTED")) {
						LogFragment.addLog(str);
					}
					if (str.contains("----- HARLIES OVPN STOP -----")) {
						LogFragment.addLog(str);
					}
					if (str.contains("ADD_ROUTES")) {
						LogFragment.addLog(str);
					}
					if (str.contains("PEM_PASSWORD_FAIL")) {
						LogFragment.addLog(str);
					}
					if (str.contains("CERT_VERIFY_FAIL")) {
						LogFragment.addLog(str);
					}
					if (str.contains("TLS_VERSION_MIN")) {
						LogFragment.addLog(str);
					}
					if (str.contains("TUN_SETUP_FAILED")) {
						LogFragment.addLog(str);
					}
					if (str.contains("PROFILE_NOT_FOUND")) {
						LogFragment.addLog(str);
					}
					if (str.contains("CONFIG_FILE_PARSE_ERROR")) {
						LogFragment.addLog(str);
					}
					if (str.contains("NEED_CREDS_ERROR")) {
						LogFragment.addLog(str);
					}
					if (str.contains("CREDS_ERROR")) {
						LogFragment.addLog(str);
					}
					if (str.contains("PROXY_NEED_CREDS")) {
						LogFragment.addLog(str);
					}
					if (str.contains("PROXY_ERROR")) {
						LogFragment.addLog("..........PROXY_ERROR...!..........");
					}
					if (str.contains("CORE_THREAD_ERROR")) {
						LogFragment.addLog(str);
					}
					if (str.contains("EPKI_ERROR")) {
						LogFragment.addLog(str);
					}
				}
			}
		}
	}
	
	
	
	
}
