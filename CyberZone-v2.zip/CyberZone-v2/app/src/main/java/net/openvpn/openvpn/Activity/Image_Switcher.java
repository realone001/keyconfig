package net.openvpn.openvpn.Activity;
import android.view.animation.*;
import harlies.paid.ovpn.com.ph.*;
import net.openvpn.openvpn.*;
import android.view.*;

public class Image_Switcher
{
	public Image_Switcher(OpenVPNClient h,String str){
		Animation anim_in = AnimationUtils.loadAnimation(h, R.animator.pop_in);
		Animation anim_out = AnimationUtils.loadAnimation(h, R.animator.pop_out);
		if(str.contains("start")){
			h.graph_l.startAnimation(anim_in);
			h.graph_l.setVisibility(0);
			h.graph_l.startAnimation(anim_in);
			h.image_l.startAnimation(anim_out);
			h.image_l.setVisibility(8);
		}else if(str.contains("stop")){
			h.image_l.startAnimation(anim_in);
			h.image_l.setVisibility(0);
			h.image_l.startAnimation(anim_in);
			h.graph_l.startAnimation(anim_out);
			h.graph_l.setVisibility(8);
		}
	}
}
