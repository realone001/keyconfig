package net.openvpn.openvpn.Adapter;

import android.view.*;
import android.view.animation.*;
import android.widget.*;
import harlies.paid.ovpn.com.ph.*;
import net.openvpn.openvpn.*;
import android.graphics.*;

public class CatSpinAdapter extends ArrayAdapter<String>
{
	public CatSpinAdapter(OpenVPNClient h, String[] categories)
	{
		super(h, R.layout.h_cat_sp, categories);
	}

	@Override
	public String getItem(int position)
	{
		// TODO: Implement this method
		return super.getItem(position);
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent)
	{
		// TODO: Implement this method
		return view(position, convertView, parent);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		// TODO: Implement this method
		return view(position, convertView, parent);
	}
	public View view(int position, View convertView, ViewGroup parent)
	{
		Animation anim = AnimationUtils.loadAnimation(getContext(), R.animator.side_in);
		View v = LayoutInflater.from(getContext()).inflate(R.layout.h_cat_sp, parent, false);
		RelativeLayout CatLinearLayout = (RelativeLayout)v.findViewById(R.id.CatLinearLayout);
		RelativeLayout CatLinearLayout1 = (RelativeLayout)v.findViewById(R.id.hcatspRelativeLayout1);
		TextView tv = (TextView)v.findViewById(R.id.category_title);
		tv.setText(getItem(position));
		TextView ct = (TextView)v.findViewById(R.id.categoryitemTextView);
		ct.setText("P");
		ct.setTextColor(Color.WHITE);
		String cat = getItem(position);
		if (cat.contains("Premium")) {
			ct.setText("P");
			CatLinearLayout1.setBackgroundResource(R.drawable.h_c_p);
		} else if (cat.contains("VIP")) {
			ct.setText("V");
			CatLinearLayout1.setBackgroundResource(R.drawable.h_c_v);
		} else if (cat.contains("Private")) {
			ct.setText("P");
			CatLinearLayout1.setBackgroundResource(R.drawable.h_c_pv);
		}else{
			ct.setText("P");
		}
		CatLinearLayout.startAnimation(anim);
		return v;
	}
}
