package net.openvpn.openvpn.Logs;

import android.app.*;
import android.content.*;
import android.os.*;
import android.support.design.widget.*;
import android.view.*;
import android.widget.*;
import net.openvpn.openvpn.*;
import harlies.paid.ovpn.com.ph.*;
import android.preference.*;
import android.graphics.*;

public class LogFragment extends Fragment 
{

    private static LogView mLogView;
	private View mView;

	private ListView mLogListView;

	private SharedPreferences pref;

	@Override
    public void onCreate(Bundle bundle)
	{
        super.onCreate(bundle);
		pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        setHasOptionsMenu(true);
	}

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		mView = inflater.inflate(R.layout.fragment_log, container, false);

		mLogListView = (ListView) mView.findViewById(R.id.logView);
	 	mLogView = new LogView(getActivity(), mLogListView);
        mLogListView.setClickable(true);
        mLogListView.setFocusable(true);
		mLogListView.setStackFromBottom(false);
		mLogListView.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		if (net.openvpn.openvpn.Utils.ThemeUtils.getTheme(getActivity()) == R.style.AppTheme) {
			mLogListView.setBackgroundColor(Color.WHITE);
        } else if (net.openvpn.openvpn.Utils.ThemeUtils.getTheme(getActivity()) == R.style.AppTheme_Dark) {
			mLogListView.setBackgroundColor(this.getResources().getColor(R.color.grey_800));
        }

		((FloatingActionButton) mView.findViewById(R.id.clearLogs)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					LogView.arrayList.clear();
					addLog(new StringBuffer().append("Running on ").append(Build.BRAND).append(" ").append(Build.MODEL).append(" (").append(Build.PRODUCT).append(") ").append(Build.MANUFACTURER).append(", Android API ").append(Build.VERSION.SDK).toString());
					addLog("Log Cleared");
				}
			});
		return this.mView;
    }

    public static LogView getLogView()
	{
        return mLogView;
    }



	public static void copyToClipboard(Context context, String str)
	{
        if (android.os.Build.VERSION.SDK_INT >= 11)
		{
            ((android.content.ClipboardManager) context.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("CDCEVPN-log", str));
        }
		else
		{
            ((android.text.ClipboardManager) context.getSystemService("clipboard")).setText(str);
        }
        Toast.makeText(context, "Copy to Clipboard", 0).show();
    }

	public static void clear()
	{
		LogView.arrayList.clear();
		addLog(new StringBuffer().append("Running on ").append(Build.BRAND).append(" ").append(Build.MODEL).append(" (").append(Build.PRODUCT).append(") ").append(Build.MANUFACTURER).append(", Android API ").append(Build.VERSION.SDK).toString());
		addLog("Harlies OVPN Build 16 2.11.20");
		//addLog("Application version: " + Utils.vb());
	}

	public static void addLog(String str)
	{
		Log.i("EasySSH", str);
	}

	public static void addLog(String tag, String str)
	{
		Log.i(tag, str);
	}

	public void onStart()
	{
        super.onStart();
        LogWrapper logWrapper = new LogWrapper();
		Log.setLogNode(logWrapper);
		MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter();
		logWrapper.setNext(msgFilter);
		// this.logFragment = (LogFragment) getSupportFragmentManager().findFragmentById(R.id.log_window);
		msgFilter.setNext(getLogView());

	}

	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();

	}

}

