package net.openvpn.openvpn.Utils;

import android.content.*;
import java.io.*;
import org.json.*;
import android.widget.*;
import net.openvpn.openvpn.*;
import net.openvpn.openvpn.Activity.*;
import java.security.*;
import net.openvpn.openvpn.BottomNavigation.*;
import java.util.*;
public class Util{
	public static String C_Payload = "C_Payload_Key";
	public static String KeyGen_pref = "KeyGen_pref";
	public static String KeyGen = new String(new byte[]{68,101,102,97,117,108,116,95,75,101,121,71,101,110,});
	public static String DefaultKeyGen = HGen("Ub1QXMrsj1BdTxzBxeJkYHGcgVMG3fHIAuzLzVYm80A=");
	private static final char[] hexArray = "0123456789ABCDEF".toCharArray();
	public static String CONTACTSUPORT = "www.facebook.com/mhikkalomboy";
	public static String FACEBOOK_GROUP = "FACEBOOK_GROUP_KEY";
	public static String WEB_PANEL = "WEB_PANEL_KEY";
	public static String CONFIG_V_INFO = "config_version_info";
	public static String ROUTE = "ROUTE_KEY";
	public static String DNS = "DNS_KEY";
	public static String QUERY_M = "QueryMethod";
	public static String REQUEST_M = "RequestMethod";
	public static String INJECT_M = "InjectMethod";
	public static String CHANGELOGS = "CHANGELOGS_KEY";
	public static String PULL_KEY = "PULL_KEY";
	public static String REDIRECT_KEY = "REDIRECT_KEY";
	public static String ONLINE_HOST_KEY = "ONLINE_HOST_KEY";
	public static String FORWARD_HOST_KEY = "FORWARD_HOST_KEY";
	public static String FORWARDED_FOR_KEY = "FORWARDED_FOR_KEY";
	public static String KEEP_ALIVE_KEY = "KEEP_ALIVE_KEY";
	public static String HOST_KEY = "HOST_KEY";
	public static String URL_HOST_KEY = "URL_HOST_KEY";
	public static String PROXY_KEY = "REMOTE_PROXY_KEY";
	public static String PORT_KEY = "REMOTE_PORT_KEY";
	public static String h_c(String p0)
	{
		return XMLRPC.h_c_Parser.parseToString(p0);
	}
	public static String CurrentConfigVersion = "0";
	public static String CurrentSMSVersion = "00";
	public static String custom_update_url = "custom_update_url_key";
	/*
	public static ArrayList parseServer(ArrayList arraylist, String data)
	{
		// TODO: Implement this method
		try
		{
			JSONObject obj1 = new JSONObject(data);
			JSONArray obj2 = obj1.getJSONArray("Servers");
			for (int i = 0; i < obj2.length(); i++)
			{
				JSONObject obj3 = obj2.getJSONObject(i);
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("ser_name", obj3.getString("Name"));
				map.put("ser_iv", obj3.getString("Flag"));
				arraylist.add(map);
			}
			return arraylist;
		}
		catch (Exception e)
		{
			return arraylist;
		}
	}*/
	public static ArrayList parseNetwork(ArrayList arraylist, String data)
	{
		// TODO: Implement this method
		try
		{
			JSONObject obj1 = new JSONObject(data);
			JSONArray obj2 = obj1.getJSONArray("Networks");
			for (int i = 0; i < obj2.length(); i++)
			{
				JSONObject obj3 = obj2.getJSONObject(i);
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("net_pro", obj3.getString("Name"));
				map.put("net_iv", obj3.getString("Network"));
				arraylist.add(map);
			}
			return arraylist;
		}
		catch (Exception e)
		{
			return arraylist;
		}
	}
	public static String decodeHex(String str)
	{
		StringBuilder b = new StringBuilder();
		for (int i = 0; i < str.length() -1; i+=2) {
			b.append((char) Integer.parseInt(str.substring(i, i+2), 16));
		}
		return b.toString();
	}
	public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[(bytes.length * 2)];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 255;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[(j * 2) + 1] = hexArray[v & 15];
        }
        return new String(hexChars);
    }
	//private static String str01 = new String(new byte[]{80,114,105,110,99,101,83,111,104,97,114,108,101,101,50,48,50,48,});
	/*
	public static String getRp(Context con, String name)
	{
		StringBuilder str = new StringBuilder();
		String s = "";
		String a = "";
		String b = "";
		try
		{
			a = debug(FileUtil.read_file(con, "imported", name));
		}
		catch (IOException e)
		{}
		try
		{
			b = debug(FileUtil.read_file(con, "bundled", name));
		}
		catch (IOException e)
		{}
		if (a.isEmpty()) {
			str.append(b);
		} else {
			str.append(a);
		}
		String c = str.toString();
		if (c.contains("\n")) {
			String[] str1 = c.split("\n");
			for (int i = 0; i < str1.length; i++) {
				String s0 = str1[i];
				if (containsRp(s0)) {
					s = s0;
				}
			}
			if (s.contains("remote")) {
				s = s.replace("remote ","").replace(s.substring(s.lastIndexOf(" ")),"");
			}
		}
		return s;
	}
	*/
	public static String config(Context con,String name)
	{
		StringBuilder str = new StringBuilder();
		String a = "";
		String b = "";
		try
		{
			a = h_c(FileUtil.read_file(con, "imported", name));
		}
		catch (IOException e)
		{}
		try
		{
			b = h_c(FileUtil.read_file(con, "bundled", name));
		}
		catch (IOException e)
		{}
		if (a.isEmpty()) {
			str.append(b);
		} else {
			str.append(a);
		}
		return str.toString();
	}

	public static String HGen(String str){
		String result = "";
		try {
			result = NavigationView.decrypt(str);
			return result;
		}catch (GeneralSecurityException e){
		}
		return result;
	}/*
	private static boolean containsRp(String item)
	{
		if (item.startsWith("remote ")) {
			return true;
		}
		// TODO: Implement this method
		return false;
	}
	public static File zipFile(Context cont)
	{
		try {
			File file = new File(cont.getFilesDir(), "Configs.zip");
			InputStream in = cont.getAssets().open("Configs.zip");
			OutputStream out = new FileOutputStream(file);
			byte[] bits = new byte[1024];

			while (true) {
				int read = in.read(bits, 0, bits.length);
				if (read <= 0) {
					break;
				}
				out.write(bits, 0, read);
			}
			out.flush();
			out.close();
			in.close();
			return file;
		} catch (Exception e) {
			Toast.makeText(cont, e.getMessage(), Toast.LENGTH_LONG).show();
		}
		return null;
	}
	*/
}
