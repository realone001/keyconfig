package net.openvpn.openvpn.Activity;
import net.openvpn.openvpn.*;
import android.preference.*;
import android.content.*;
import net.openvpn.openvpn.Utils.*;
import android.app.*;
import android.media.*;
import harlies.paid.ovpn.com.ph.*;
import org.json.*;
import cn.pedant.SweetAlert.SweetAlertDialog;

public class SMSuPdater
{
	private SharedPreferences pref;
	private SweetAlertDialog pDialog;
	public SMSuPdater(final OpenVPNClient h){
		pref = PreferenceManager.getDefaultSharedPreferences(h);
		new SMS_Updater(h, new SMS_Updater.Listener() {
				@Override
				public void onCompleted(final String SMS)
				{
					// TODO: Implement this method
					try
					{
						JSONObject sms_js = new JSONObject(SMS);
						if (sms_js.getInt("SendMessage") == pref.getInt(Util.CurrentSMSVersion, 0))
						{
						}
						else
						{
							pref.edit().putBoolean("firstStartSMS", true).commit();
							if (new Boolean(pref.getBoolean("firstStartSMS", true)).booleanValue())
							{
								StringBuffer sb = new StringBuffer();
								sb.append(sms_js.getString("MyMessage"));

								NotificationManager notificationManager = (NotificationManager) h.getSystemService(Context.NOTIFICATION_SERVICE); 
								Notification notification = new Notification.Builder(h) 
									.setContentTitle("New Message From Admin") 
									.setSmallIcon(R.drawable.ic_message_text)
									.setContentText(sb.toString())
									.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
									.setOnlyAlertOnce(true)
									.setAutoCancel(true)
									.build(); 
								notificationManager.notify(4129,notification); 

								pDialog = new SweetAlertDialog(h, SweetAlertDialog.WARNING_TYPE);
								pDialog.setTitleText("NEW MESSAGE FROM ADMIN");
								pDialog.setContentText(sb.toString());
								pDialog.setConfirmText("Dont show again");
								pDialog.setCancelable(true);
								pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
										@Override
										public void onClick(SweetAlertDialog sDialog) {
											// reuse previous dialog instance
											try
											{
												JSONObject sms_obj = new JSONObject(SMS);
												pref.edit().putInt(Util.CurrentSMSVersion, sms_obj.getInt("SendMessage")).commit();
												pref.edit().putBoolean("firstStartSMS", false).commit();
											}
											catch (Exception e){
											}
											sDialog.dismiss();
										}
									});
									pDialog.show();
							}
						}
					}
					catch (Exception e)
					{
					}
				}

				@Override
				public void onCancelled()
				{
					// TODO: Implement this method
				}

				@Override
				public void onException(String ex)
				{
					// TODO: Implement this method
				}
			}).execute();
	}
}
