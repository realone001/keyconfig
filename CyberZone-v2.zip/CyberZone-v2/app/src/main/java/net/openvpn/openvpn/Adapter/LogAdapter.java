package net.openvpn.openvpn.Adapter;
import android.widget.*;
import android.content.*;
import java.util.*;
import android.text.*;
import android.view.*;
import harlies.paid.ovpn.com.ph.*;

public class LogAdapter extends ArrayAdapter<Spanned>
{
	public LogAdapter(Context con, ArrayList<Spanned> logMsg)
	{
		super(con, R.layout.log_item,logMsg);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		View v = LayoutInflater.from(getContext()).inflate(R.layout.log_item, parent, false);
		TextView tv = (TextView)v.findViewById(R.id.log_item_text);
		Spanned item = getItem(position);
		tv.setText(item);
		// TODO: Implement this method
		return v;
	}

}
