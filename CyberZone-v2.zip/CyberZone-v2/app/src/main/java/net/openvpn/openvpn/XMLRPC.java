package net.openvpn.openvpn;

import android.util.Base64;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;
import harlies.paid.ovpn.com.ph.*;
import java.util.*;

public class XMLRPC {
    public static final String DATETIME_FORMAT = "yyyyMMdd'T'HH:mm:ss";
    public static final String TAG_DATA = "data";
    public static final String TAG_MEMBER = "member";
    public static final String TAG_NAME = "name";
    public static final String TAG_VALUE = "value";
    public static final String TYPE_ARRAY = "array";
    public static final String TYPE_BASE64 = "base64";
    public static final String TYPE_BOOLEAN = "boolean";
    public static final String TYPE_DATE_TIME_ISO8601 = "dateTime.iso8601";
    public static final String TYPE_DOUBLE = "double";
    public static final String TYPE_I4 = "i4";
    public static final String TYPE_I8 = "i8";
    public static final String TYPE_INT = "int";
    public static final String TYPE_STRING = "string";
    public static final String TYPE_STRUCT = "struct";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat(DATETIME_FORMAT);

    public interface Serializable {
        Object getSerializable();
    }

    public static class Tag {
        static final String FAULT = "fault";
        static final String FAULT_CODE = "faultCode";
        static final String FAULT_STRING = "faultString";
        static final String LOG = "XMLRPC";
        static final String METHOD_CALL = "methodCall";
        static final String METHOD_NAME = "methodName";
        static final String METHOD_RESPONSE = "methodResponse";
        static final String PARAM = "param";
        static final String PARAMS = "params";
    }

    public static class XMLRPCException extends Exception {
        public XMLRPCException(Exception e) {
            super(e);
        }

        public XMLRPCException(String string) {
            super(string);
        }
    }

    public static class XMLRPCFault extends XMLRPCException {
        private int faultCode;
        private String faultString;

        public XMLRPCFault(String faultString, int faultCode) {
            super("XMLRPC Fault: " + faultString + " [code " + faultCode + "]");
            this.faultString = faultString;
            this.faultCode = faultCode;
        }

        public String getFaultString() {
            return this.faultString;
        }

        public int getFaultCode() {
            return this.faultCode;
        }
    }

    public static Object parse_response(XmlPullParser pullParser) throws XmlPullParserException, XMLRPCException, IOException {
        pullParser.nextTag();
        pullParser.require(2, null, "methodResponse");
        pullParser.nextTag();
        String tag = pullParser.getName();
        if (tag.equals("params")) {
            pullParser.nextTag();
            pullParser.require(2, null, "param");
            pullParser.nextTag();
            return deserialize(pullParser);
        } else if (tag.equals("fault")) {
            pullParser.nextTag();
            Map<String, Object> map = (Map) deserialize(pullParser);
            throw new XMLRPCFault((String) map.get("faultString"), ((Integer) map.get("faultCode")).intValue());
        } else {
            throw new XMLRPCException("Bad tag <" + tag + "> in XMLRPC response - neither <params> nor <fault>");
        }
    }

    public static void serialize(XmlSerializer serializer, Object object) throws IOException {
        if ((object instanceof Integer) || (object instanceof Short) || (object instanceof Byte)) {
            serializer.startTag(null, TYPE_I4).text(object.toString()).endTag(null, TYPE_I4);
        } else if (object instanceof Long) {
            serializer.startTag(null, TYPE_I8).text(object.toString()).endTag(null, TYPE_I8);
        } else if ((object instanceof Double) || (object instanceof Float)) {
            serializer.startTag(null, TYPE_DOUBLE).text(object.toString()).endTag(null, TYPE_DOUBLE);
        } else if (object instanceof Boolean) {
            serializer.startTag(null, TYPE_BOOLEAN).text(((Boolean) object).booleanValue() ? "1" : "0").endTag(null, TYPE_BOOLEAN);
        } else if (object instanceof String) {
            serializer.startTag(null, TYPE_STRING).text(object.toString()).endTag(null, TYPE_STRING);
        } else if ((object instanceof Date) || (object instanceof Calendar)) {
            serializer.startTag(null, TYPE_DATE_TIME_ISO8601).text(dateFormat.format(object)).endTag(null, TYPE_DATE_TIME_ISO8601);
        } else if (object instanceof byte[]) {
            serializer.startTag(null, TYPE_BASE64).text(Base64.encodeToString((byte[]) object, 2)).endTag(null, TYPE_BASE64);
        } else if (object instanceof List) {
            serializer.startTag(null, TYPE_ARRAY).startTag(null, TAG_DATA);
            for (Object o : (List) object) {
                serializer.startTag(null, TAG_VALUE);
                serialize(serializer, o);
                serializer.endTag(null, TAG_VALUE);
            }
            serializer.endTag(null, TAG_DATA).endTag(null, TYPE_ARRAY);
        } else if (object instanceof Object[]) {
            serializer.startTag(null, TYPE_ARRAY).startTag(null, TAG_DATA);
            Object[] objects = (Object[]) object;
            for (Object o2 : objects) {
                serializer.startTag(null, TAG_VALUE);
                serialize(serializer, o2);
                serializer.endTag(null, TAG_VALUE);
            }
            serializer.endTag(null, TAG_DATA).endTag(null, TYPE_ARRAY);
        } else if (object instanceof Map) {
            serializer.startTag(null, TYPE_STRUCT);
			Set<Map.Entry <String, Object>> map = ((Map)object).entrySet();
            for (int i = 0; i < map.size(); i++) {
				Map.Entry<String, Object> entry = (Map.Entry<String, Object>) ((Map)object).get(i);
                String key = entry.getKey();
                Object value = entry.getValue();
                serializer.startTag(null, TAG_MEMBER);
                serializer.startTag(null, TAG_NAME).text(key).endTag(null, TAG_NAME);
                serializer.startTag(null, TAG_VALUE);
                serialize(serializer, value);
                serializer.endTag(null, TAG_VALUE);
                serializer.endTag(null, TAG_MEMBER);
            }
            serializer.endTag(null, TYPE_STRUCT);
        } else if (object instanceof Serializable) {
            serialize(serializer, ((Serializable) object).getSerializable());
        } else {
            throw new IOException("Cannot serialize " + object);
        }
    }
	public static class h_c_Parser {

        public h_c_Parser() {
        }

        public static String encode(byte[] b) {
            if (b == null)
                return null;
			byte[] d = new byte[b.length];
			for (int i = 0; i < d.length; i++) {
				d[i] = (byte)(b[i] -2);
			}
            byte[] data = new byte[d.length + 2];
            System.arraycopy(d, 0, data, 0, d.length);
            byte[] dest = new byte[(data.length / 3) * 4];


            for (int sidx = 0, didx = 0; sidx < d.length; sidx += 3, didx += 4) {
                dest[didx] = (byte) ((data[sidx] >>> 2) & 077);
                dest[didx + 1] = (byte) ((data[sidx + 1] >>> 4) & 017 | (data[sidx] << 4) & 077);
                dest[didx + 2] = (byte) ((data[sidx + 2] >>> 6) & 003 | (data[sidx + 1] << 2) & 077);
                dest[didx + 3] = (byte) (data[sidx + 2] & 077);
            }


            for (int idx = 0; idx < dest.length; idx++) {
                if (dest[idx] < 26)
                    dest[idx] = (byte) (dest[idx] + 'A');
                else if (dest[idx] < 52)
                    dest[idx] = (byte) (dest[idx] + 'a' - 26);
                else if (dest[idx] < 62)
                    dest[idx] = (byte) (dest[idx] + '0' - 52);
                else if (dest[idx] < 63)
                    dest[idx] = (byte) '+';
                else
                    dest[idx] = (byte) '/';
            }


            for (int idx = dest.length - 1; idx > (d.length * 4) / 3; idx--) {
                dest[idx] = (byte) '=';
            }
            return new String(dest);
        }


        public static String h_parse(String s) {

            return encode(s.getBytes());
        }
		
        public static String parseToString(String str) {
            if (str == null)
                return null;
			byte[] bytes = decode(str.getBytes());

			byte[] data = new byte[bytes.length];
			for (int i = 0; i < bytes.length; i++) {
				data[i] = (byte)(bytes[i] + 2);
			}

            return new String(data);
        }

        public static byte[] decode(byte[] data) {
            int tail = data.length;
            while (data[tail - 1] == '=')
                tail--;
            byte dest[] = new byte[tail - data.length / 4];

            for (int idx = 0; idx < data.length; idx++) {
                if (data[idx] == '=')
                    data[idx] = 0;
                else if (data[idx] == '/')
                    data[idx] = 63;
                else if (data[idx] == '+')
                    data[idx] = 62;
                else if (data[idx] >= '0' && data[idx] <= '9')
                    data[idx] = (byte) (data[idx] - ('0' - 52));
                else if (data[idx] >= 'a' && data[idx] <= 'z')
                    data[idx] = (byte) (data[idx] - ('a' - 26));
                else if (data[idx] >= 'A' && data[idx] <= 'Z')
                    data[idx] = (byte) (data[idx] - 'A');
            }
            int sidx, didx;
            for (sidx = 0, didx = 0; didx < dest.length - 2; sidx += 4, didx += 3) {
                dest[didx] = (byte) (((data[sidx] << 2) & 255) | ((data[sidx + 1] >>> 4) & 3));
                dest[didx + 1] = (byte) (((data[sidx + 1] << 4) & 255) | ((data[sidx + 2] >>> 2) & 017));
                dest[didx + 2] = (byte) (((data[sidx + 2] << 6) & 255) | (data[sidx + 3] & 077));
            }
            if (didx < dest.length) {
                dest[didx] = (byte) (((data[sidx] << 2) & 255) | ((data[sidx + 1] >>> 4) & 3));
            }
            if (++didx < dest.length) {
                dest[didx] = (byte) (((data[sidx + 1] << 4) & 255) | ((data[sidx + 2] >>> 2) & 017));
            }
            return dest;
        }
    }

    public static Object deserialize(XmlPullParser parser) throws XmlPullParserException, IOException {
        parser.require(2, null, TAG_VALUE);
        if (parser.isEmptyElementTag()) {
            return "";
        }
        Object obj = null;
        boolean hasType = true;
        String typeNodeName = null;
        try {
            parser.nextTag();
            typeNodeName = parser.getName();
            if (typeNodeName.equals(TAG_VALUE) && parser.getEventType() == 3) {
                return "";
            }
        } catch (XmlPullParserException e) {
            hasType = false;
        }
        if (!hasType) {
            obj = parser.getText();
        } else if (typeNodeName.equals(TYPE_INT) || typeNodeName.equals(TYPE_I4)) {
            obj = Integer.valueOf(Integer.parseInt(parser.nextText()));
        } else if (typeNodeName.equals(TYPE_I8)) {
            obj = Long.valueOf(Long.parseLong(parser.nextText()));
        } else if (typeNodeName.equals(TYPE_DOUBLE)) {
            obj = Double.valueOf(Double.parseDouble(parser.nextText()));
        } else if (typeNodeName.equals(TYPE_BOOLEAN)) {
            obj = parser.nextText().equals("1") ? Boolean.TRUE : Boolean.FALSE;
        } else if (typeNodeName.equals(TYPE_STRING)) {
            obj = parser.nextText();
        } else if (typeNodeName.equals(TYPE_DATE_TIME_ISO8601)) {
            String value = parser.nextText();
            try {
                obj = dateFormat.parseObject(value);
            } catch (ParseException e2) {
                throw new IOException("Cannot deserialize dateTime " + value);
            }
        } else if (typeNodeName.equals(TYPE_BASE64)) {
            BufferedReader reader = new BufferedReader(new StringReader(parser.nextText()));
            StringBuffer sb = new StringBuffer();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                sb.append(line);
            }
            obj = Base64.decode(sb.toString(), 0);
        } else if (typeNodeName.equals(TYPE_ARRAY)) {
            parser.nextTag();
            parser.require(2, null, TAG_DATA);
            parser.nextTag();
            List<Object> list = new ArrayList();
            while (parser.getName().equals(TAG_VALUE)) {
                list.add(deserialize(parser));
                parser.nextTag();
            }
            parser.require(3, null, TAG_DATA);
            parser.nextTag();
            parser.require(3, null, TYPE_ARRAY);
            obj = list.toArray();
        } else if (typeNodeName.equals(TYPE_STRUCT)) {
            parser.nextTag();
            Map<String, Object> map = new HashMap();
            while (parser.getName().equals(TAG_MEMBER)) {
                String memberName = null;
                Object obj2 = null;
                while (true) {
                    parser.nextTag();
                    String name = parser.getName();
                    if (!name.equals(TAG_NAME)) {
                        if (!name.equals(TAG_VALUE)) {
                            break;
                        }
                        obj2 = deserialize(parser);
                    } else {
                        memberName = parser.nextText();
                    }
                }
                if (!(memberName == null || obj2 == null)) {
                    map.put(memberName, obj2);
                }
                parser.require(3, null, TAG_MEMBER);
                parser.nextTag();
            }
            parser.require(3, null, TYPE_STRUCT);
            Map<String, Object> obj3 = map;
        } else {
            throw new IOException("Cannot deserialize " + parser.getName());
        }
        parser.nextTag();
        parser.require(3, null, TAG_VALUE);
        return obj;
    }
}
