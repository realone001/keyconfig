package net.openvpn.openvpn.BottomNavigation;

import android.view.ViewGroup;

class BottomNavigationAnimationHelperBase {
    void beginDelayedTransition(ViewGroup view) {
        // Do nothing.
    }
}
