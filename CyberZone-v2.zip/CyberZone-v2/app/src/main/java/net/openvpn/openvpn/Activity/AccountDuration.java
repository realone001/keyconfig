package net.openvpn.openvpn.Activity;

import android.content.*;
import android.text.*;
//import com.shashank.sony.fancydialoglib.*;
import net.openvpn.openvpn.*;
import org.json.*;
import java.util.concurrent.*;
import android.preference.*;
import android.content.SharedPreferences.*;
import harlies.paid.ovpn.com.ph.*;
import cn.pedant.SweetAlert.*;

public class AccountDuration
{
	private SharedPreferences pref;
	public AccountDuration(final OpenVPNClient h) {
		this.pref = PreferenceManager.getDefaultSharedPreferences(h);
		//String url = "https://pastebin.com/raw/2MTuDyHD";
		String url = "https://radzvpn.tk/check_duration.php?username="+pref.getString("username", "");
		new DurationAsync(h, url, new DurationAsync.Listener() {
				@Override
				public void onCompleted(String config)
				{
					// TODO: Implement this method
					try{
						JSONObject obj = new JSONObject(config);
						if (Long.parseLong(obj.getString("premium")) != 0 || Long.parseLong(obj.getString("vip")) != 0 || Long.parseLong(obj.getString("private")) != 0) {
							Long secondsP = Long.valueOf(Long.parseLong(obj.getString("premium")));
							//http://stackoverflow.com/questions/11357945/java-convert-seconds-into-day-hour-minute-and-seconds-using-timeunit
							int dₐyₚ = (int) TimeUnit.SECONDS.toDays(secondsP);        
							long ₕₒᵤᵣₛₚ = TimeUnit.SECONDS.toHours(secondsP) - (dₐyₚ * 24);
							long ₘᵢₙᵤₜₑₚ = TimeUnit.SECONDS.toMinutes(secondsP) - (TimeUnit.SECONDS.toHours(secondsP)* 60);
							Long ₛₑcₒₙdₛᵥ;
							Long ₛₑcₒₙdₛₚᵣ;

							if (Long.parseLong(obj.getString("vip")) == 0) {
								ₛₑcₒₙdₛᵥ = Long.valueOf(0);
							} else {
								ₛₑcₒₙdₛᵥ = Long.valueOf(Long.parseLong(obj.getString("vip")));
							}
							if (Long.parseLong(obj.getString("private")) == 0) {
								ₛₑcₒₙdₛₚᵣ = Long.valueOf(0);
							} else {
								ₛₑcₒₙdₛₚᵣ = Long.valueOf(Long.parseLong(obj.getString("private")));
							}
							//http://stackoverflow.com/questions/11357945/java-convert-seconds-into-day-hour-minute-and-seconds-using-timeunit
							int dₐyᵥ = (int) TimeUnit.SECONDS.toDays(ₛₑcₒₙdₛᵥ);        
							long ₕₒᵤᵣₛᵥ = TimeUnit.SECONDS.toHours(ₛₑcₒₙdₛᵥ) - (dₐyᵥ * 24);
							long ₘᵢₙᵤₜₑᵥ = TimeUnit.SECONDS.toMinutes(ₛₑcₒₙdₛᵥ) - (TimeUnit.SECONDS.toHours(ₛₑcₒₙdₛᵥ)* 60);
							String ₚᵣₑₘᵢᵤₘ = "Premium " + "<br>" +" Days = " +String.valueOf(dₐyₚ)  + "<br>" + "Hours = " + String.valueOf(ₕₒᵤᵣₛₚ) + "<br>" + "Minutes = " + String.valueOf(ₘᵢₙᵤₜₑₚ) + "<br>" + "<br>";
							String ᵥᵢₚ = "VIP" +"<br>"+ " Days = "+String.valueOf(dₐyᵥ) + "<br>" + "Hours = " + String.valueOf(ₕₒᵤᵣₛᵥ) + "<br>" + "Minutes = " + String.valueOf(ₘᵢₙᵤₜₑᵥ)+ "<br>" +"<br>";
							if (secondsP == 0) {
								ₚᵣₑₘᵢᵤₘ = "";
							}
							if (ₛₑcₒₙdₛᵥ == 0) {
								ᵥᵢₚ = "";
							}
							//http://stackoverflow.com/questions/11357945/java-convert-seconds-into-day-hour-minute-and-seconds-using-timeunit
							int dₐyₚᵣ = (int) TimeUnit.SECONDS.toDays(ₛₑcₒₙdₛₚᵣ);        
							long ₕₒᵤᵣₛₚᵣ = TimeUnit.SECONDS.toHours(ₛₑcₒₙdₛₚᵣ) - (dₐyₚᵣ * 24);
							long ₘᵢₙᵤₜₑₚᵣ = TimeUnit.SECONDS.toMinutes(ₛₑcₒₙdₛₚᵣ) - (TimeUnit.SECONDS.toHours(ₛₑcₒₙdₛₚᵣ)* 60);
							String ₚᵣᵢᵥₐₜₑ = "Private " + "<br>" + " Days = " + String.valueOf(dₐyₚᵣ) + "<br>" + "Hours = " + String.valueOf(ₕₒᵤᵣₛₚᵣ) + "<br>" + "Minutes = " + String.valueOf(ₘᵢₙᵤₜₑₚᵣ);
							if (ₛₑcₒₙdₛₚᵣ == 0) {
								ₚᵣᵢᵥₐₜₑ = "";
							}
							new SweetAlertDialog(h, SweetAlertDialog.SUCCESS_TYPE)
								.setTitleText("DURATION")
								.setContentText("<strong>Account owner<strong> = "+pref.getString("username", "")+"<br>"+"<br>"+ₚᵣₑₘᵢᵤₘ + "  " + ᵥᵢₚ +"  " + ₚᵣᵢᵥₐₜₑ)
								.show();
						} else {
							new SweetAlertDialog(h, SweetAlertDialog.ERROR_TYPE)
								.setTitleText("CyberZone")
								.setContentText("Wrong username or password.❎")
								.show();
							
						}
					}catch(Exception e){
						new SweetAlertDialog(h, SweetAlertDialog.ERROR_TYPE)
							.setTitleText("Oops...")
							.setContentText(e.getMessage())
							.show();
					}
				}

				@Override
				public void onCancelled()
				{
					// TODO: Implement this method
				}

				@Override
				public void onException(String ex)
				{
					new SweetAlertDialog(h, SweetAlertDialog.ERROR_TYPE)
						.setTitleText("CyberZone")
						.setContentText("Something went wrong, Please try again.🔄")
						.show();
				}
			}).execute();

	}
}
