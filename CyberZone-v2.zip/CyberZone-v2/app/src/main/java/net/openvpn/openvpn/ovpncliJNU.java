package net.openvpn.openvpn;

public interface ovpncliJNU
{
	void onCliJNU(String jnu);
}
