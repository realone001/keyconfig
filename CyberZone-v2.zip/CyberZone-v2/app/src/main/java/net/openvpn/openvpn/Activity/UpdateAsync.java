package net.openvpn.openvpn.Activity;

import android.app.*;
import android.content.*;
import android.os.*;
import android.util.*;
import java.io.*;
import java.net.*;
import android.preference.*;
import android.content.SharedPreferences.*;
import net.openvpn.openvpn.*;
import net.openvpn.openvpn.Utils.*;
import cn.pedant.SweetAlert.*;

public class UpdateAsync extends AsyncTask<String, String, String> {
    private static final String TAG = "NetGuard.Download";
    private Context context;
    private Listener listener;
    private PowerManager.WakeLock wakeLock;
	private HttpURLConnection uRLConnection;
	private InputStream is;
	private BufferedReader buffer;
	private SweetAlertDialog pDialog;
	private SharedPreferences pref;
	private SharedPreferences.Editor editor;

    public interface Listener {
        void onCompleted(String config);

        void onCancelled();

        void onException(String ex);
    }

    public UpdateAsync(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
		pref = PreferenceManager.getDefaultSharedPreferences(context);
		editor = pref.edit();
    }

    @Override
    protected void onPreExecute() {
		pDialog = new SweetAlertDialog(context, SweetAlertDialog.PROGRESS_TYPE)
			.setTitleText("Checking Please Wait...");
		pDialog.show();
		pDialog.setCancelable(true);
    }

    @Override
    protected String doInBackground(String... args) {
		try {
			String api = pref.getString(Util.custom_update_url, "");
			if(!api.startsWith("http")){
				api = new StringBuilder().append("http://").append(pref.getString(Util.custom_update_url, "")).toString();
			}
            URL url = new URL(api);
            uRLConnection = (HttpURLConnection) url.openConnection();
            uRLConnection.setRequestMethod("POST");
            is = uRLConnection.getInputStream();
            buffer = new BufferedReader(new InputStreamReader(is));
            StringBuilder strBuilder = new StringBuilder();
            String line;
            while ((line = buffer.readLine()) != null) {
                strBuilder.append(line);
            }
            return strBuilder.toString();
        } catch (Exception e) {
            return "error";
        } finally {
            if (buffer != null) {
                try {
                    buffer.close();
                } catch (IOException ignored) {
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException ignored) {

                }
            }
            if (uRLConnection != null) {
                uRLConnection.disconnect();
            }
        }
	}

    @Override
    protected void onCancelled() {
        super.onCancelled();
        Log.i(TAG, "Cancelled");
		pDialog.dismiss();
        listener.onCancelled();
    }

    @Override
    protected void onPostExecute(String result) {
		// wakeLock.release();
        //nm.cancel(1);
		pDialog.dismiss();
        if (result.equals("error")) {
            listener.onException(result);
        } else
            listener.onCompleted(result);
    }

}

