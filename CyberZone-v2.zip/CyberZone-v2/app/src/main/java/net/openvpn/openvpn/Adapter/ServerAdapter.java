package net.openvpn.openvpn.Adapter;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.Arrays;
import android.widget.*;
import android.view.*;
import harlies.paid.ovpn.com.ph.*;
import android.graphics.*;
import net.openvpn.openvpn.*;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import java.util.*;

public class ServerAdapter {
    public static String[] get_spinner_list(Spinner spin) {
        ArrayAdapter<String> HarliesList = (ArrayAdapter) spin.getAdapter();
        if (HarliesList == null) {
            return null;
        }
        int len = HarliesList.getCount();
        String[] ret = new String[len];
        for (int i = 0; i < len; i++) {
            ret[i] = (String) HarliesList.getItem(i);
        }
        return ret;
    }
    public static int get_spinner_count(Spinner spin) {
        ArrayAdapter<String> HarliesList = (ArrayAdapter) spin.getAdapter();
        if (HarliesList == null) {
            return 0;
        }
        return HarliesList.getCount();
    }
    public static String get_spinner_list_item(Spinner spin, int position) {
        ArrayAdapter<String> HarliesList = (ArrayAdapter) spin.getAdapter();
        if (HarliesList == null) {
            return null;
        }
        return (String) HarliesList.getItem(position);
    }
    public static String get_spinner_selected_item(Spinner spin) {
        return (String) spin.getSelectedItem();
    }

    public static void set_spinner_selected_item(Spinner spin, String selected_item) {
        if (selected_item != null) {
            String sel = get_spinner_selected_item(spin);
            if (sel == null || !selected_item.equals(sel)) {
                ArrayAdapter<String> HarliesList = (ArrayAdapter) spin.getAdapter();
                int len = HarliesList.getCount();
                for (int pos = 0; pos < len; pos++) {
                    if (selected_item.equals(HarliesList.getItem(pos))) {
                        spin.setSelection(pos);
                    }
                }
            }
        }
    }
	public static void show_spinner(Context context, Spinner spin, String[] content) {
        if (content != null) {
            String[] live_content = get_spinner_list(spin);
            if (live_content == null || !Arrays.equals(content, live_content)) {
                SpinnerAdapter aa = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, content);
                spin.setAdapter(aa);
            }
        }
    }
	
	
	
	
	public static class HarliesAdapter extends ArrayAdapter<String>
	{
		public HarliesAdapter(OpenVPNClient h, List<String> names)
		{
			super(h, R.layout.spinner_item, names);

		}

		@Override
		public String getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}
		public View getCustomView(int position, View convertView, ViewGroup parent)
		{
			Animation anim = AnimationUtils.loadAnimation(getContext(), R.animator.side_in);
			View v = LayoutInflater.from(getContext()).inflate(R.layout.spinner_item, parent, false);
			LinearLayout ServerLinearLayout = (LinearLayout)v.findViewById(R.id.ServerLinearLayout);
			TextView tv = (TextView)v.findViewById(R.id.spinner_item_txt);
			ImageView iv = (ImageView)v.findViewById(R.id.spinner_item_image);

			String config = getItem(position);
			tv.setText(config);
			//String v1 = ja.getString(tagJSON).replace(",",".");
			iv.setImageResource(R.drawable.harlie_icon);
			if (config.contains("AM_")) {
				iv.setImageResource(R.drawable.am);
			} else if (config.contains("AL_")) {
				iv.setImageResource(R.drawable.al);
			} else if (config.contains("AO_")) {
				iv.setImageResource(R.drawable.ao);
			} else if (config.contains("AG_")) {
				iv.setImageResource(R.drawable.ag);
			} else if (config.contains("AF_")) {
				iv.setImageResource(R.drawable.af);
			} else if (config.contains("AE_")) {
				iv.setImageResource(R.drawable.ae);
			} else if (config.contains("AD_")) {
				iv.setImageResource(R.drawable.ad);
			} else if (config.contains("AQ")) {
				iv.setImageResource(R.drawable.aq);
			} else if (config.contains("AR_")) {
				iv.setImageResource(R.drawable.ar);
			} else if (config.contains("AT_")) {
				iv.setImageResource(R.drawable.at);
			} else if (config.contains("AU_")) {
				iv.setImageResource(R.drawable.au);
			} else if (config.contains("AW_")) {
				iv.setImageResource(R.drawable.aw);
			} else if (config.contains("AZ_")) {
				iv.setImageResource(R.drawable.az);
			} else if (config.contains("BA_")) {
				iv.setImageResource(R.drawable.ba);
			} else if (config.contains("BB_")) {
				iv.setImageResource(R.drawable.bb);
			} else if (config.contains("BD_")) {
				iv.setImageResource(R.drawable.bd);
			} else if (config.contains("BE_")) {
				iv.setImageResource(R.drawable.be);
			} else if (config.contains("BF_")) {
				iv.setImageResource(R.drawable.bf);
			} else if (config.contains("BG_")) {
				iv.setImageResource(R.drawable.bg);
			} else if (config.contains("BH_")) {
				iv.setImageResource(R.drawable.bh);
		    } else if (config.contains("BI_")) {
				iv.setImageResource(R.drawable.bi);
			} else if (config.contains("BJ_")) {
				iv.setImageResource(R.drawable.bj);
			} else if (config.contains("BN_")) {
				iv.setImageResource(R.drawable.bn);
			} else if (config.contains("BO_")) {
				iv.setImageResource(R.drawable.bo);
			} else if (config.contains("BR_")) {
				iv.setImageResource(R.drawable.br);
			} else if(config.contains("BS_")) {
				iv.setImageResource(R.drawable.bs);
			} else if (config.contains("BT_")) {
				iv.setImageResource(R.drawable.bt);
			} else if (config.contains("BW_")) {
				iv.setImageResource(R.drawable.bw);
			} else if (config.contains("BY_")) {
				iv.setImageResource(R.drawable.by);
			} else if (config.contains("BZ_")) {
				iv.setImageResource(R.drawable.bz);
			} else if (config.contains("CA_")) {
				iv.setImageResource(R.drawable.ca);
			} else if (config.contains("CD_")) {
				iv.setImageResource(R.drawable.cd);
			} else if (config.contains("CF_")) {
				iv.setImageResource(R.drawable.cf);
			} else if (config.contains("CG_")) {
				iv.setImageResource(R.drawable.cg);
			} else if (config.contains("CH_")) {
				iv.setImageResource(R.drawable.ch);
			} else if (config.contains("CI_")) {
				iv.setImageResource(R.drawable.ci);
			} else if (config.contains("CL_")) {
				iv.setImageResource(R.drawable.cl);
			} else if (config.contains("CM_")) {
				iv.setImageResource(R.drawable.cm);
			} else if (config.contains("CN_")) {
				iv.setImageResource(R.drawable.cn);
			} else if (config.contains("CO_")) {
				iv.setImageResource(R.drawable.co);
			} else if (config.contains("CR_")) {
				iv.setImageResource(R.drawable.cr);
			} else if (config.contains("CU_")) {
				iv.setImageResource(R.drawable.cu);
			} else if (config.contains("CV_")) {
				iv.setImageResource(R.drawable.cv);
			} else if (config.contains("CY_")) {
				iv.setImageResource(R.drawable.cy);
			} else if (config.contains("CZ_")) {
				iv.setImageResource(R.drawable.cz);
			} else if (config.contains("DE_")) {
				iv.setImageResource(R.drawable.de);
			} else if (config.contains("DJ_")) {
				iv.setImageResource(R.drawable.dj);
			} else if (config.contains("DK_")) {
				iv.setImageResource(R.drawable.dk);
			} else if (config.contains("DM_")) {
				iv.setImageResource(R.drawable.dm);
			} else if(config.contains("DZ_")) {
				iv.setImageResource(R.drawable.dz);
			} else if (config.contains("EC_")) {
				iv.setImageResource(R.drawable.ec);
			} else if (config.contains("EE_")) {
				iv.setImageResource(R.drawable.ee);
			} else if (config.contains("EG_")) {
				iv.setImageResource(R.drawable.eg);
			} else if (config.contains("EH_")) {
				iv.setImageResource(R.drawable.eh);
			} else if (config.contains("ER_")) {
				iv.setImageResource(R.drawable.er);
			} else if (config.contains("ES_")) {
				iv.setImageResource(R.drawable.es);
			} else if (config.contains("ET_")) {
				iv.setImageResource(R.drawable.et);
			} else if (config.contains("FI_")) {
				iv.setImageResource(R.drawable.fi);
			} else if (config.contains("FJ_")) {
				iv.setImageResource(R.drawable.fj);
			} else if (config.contains("FM_")) {
				iv.setImageResource(R.drawable.fm);
			} else if (config.contains("FO_")) {
				iv.setImageResource(R.drawable.fo);
			} else if (config.contains("FR_")) {
				iv.setImageResource(R.drawable.fr);
			} else if (config.contains("GA_")) {
				iv.setImageResource(R.drawable.ga);
			} else if (config.contains("GB_")) {
				iv.setImageResource(R.drawable.gb);
			} else if (config.contains("GD_")) {
				iv.setImageResource(R.drawable.gd);
			} else if (config.contains("GE_")) {
				iv.setImageResource(R.drawable.ge);
			} else if (config.contains("GH_")) {
				iv.setImageResource(R.drawable.gh);
			} else if (config.contains("GI_")) {
				iv.setImageResource(R.drawable.gi);
			} else if (config.contains("GL_")) {
				iv.setImageResource(R.drawable.gl);
			} else if (config.contains("GM_")) {
				iv.setImageResource(R.drawable.gm);
			} else if (config.contains("GN_")) {
				iv.setImageResource(R.drawable.gn);
			} else if (config.contains("GQ_")) {
				iv.setImageResource(R.drawable.gq);
			} else if (config.contains("GR_")) {
				iv.setImageResource(R.drawable.gr);
			} else if(config.contains("GT_")) {
				iv.setImageResource(R.drawable.gt);
			} else if (config.contains("GW_")) {
				iv.setImageResource(R.drawable.gw);
			} else if (config.contains("GY_")) {
				iv.setImageResource(R.drawable.gy);
			} else if (config.contains("HK_")) {
				iv.setImageResource(R.drawable.hk);
			} else if (config.contains("HN_")) {
				iv.setImageResource(R.drawable.hn);
			} else if (config.contains("HR_")) {
				iv.setImageResource(R.drawable.hr);
			} else if (config.contains("HT_")) {
				iv.setImageResource(R.drawable.ht);
			} else if (config.contains("HU_")) {
				iv.setImageResource(R.drawable.hu);
			} else if (config.contains("ID_")) {
				iv.setImageResource(R.drawable.id);
			} else if (config.contains("IE_")) {
				iv.setImageResource(R.drawable.ie);
			} else if (config.contains("IL_")) {
				iv.setImageResource(R.drawable.il);
			} else if (config.contains("IN_")) {
				iv.setImageResource(R.drawable.in);
			} else if (config.contains("IQ_")) {
				iv.setImageResource(R.drawable.iq);
			} else if (config.contains("IR_")) {
				iv.setImageResource(R.drawable.ir);
			} else if (config.contains("IS_")) {
				iv.setImageResource(R.drawable.is);
			} else if (config.contains("IT_")) {
				iv.setImageResource(R.drawable.it);
			} else if (config.contains("JM_")) {
				iv.setImageResource(R.drawable.jm);
			} else if (config.contains("JO_")) {
				iv.setImageResource(R.drawable.jo);
			} else if (config.contains("JP_")) {
				iv.setImageResource(R.drawable.jp);
			} else if (config.contains("JK_")) {
				iv.setImageResource(R.drawable.jk);
			} else if (config.contains("KG_")) {
				iv.setImageResource(R.drawable.kg);
			} else if (config.contains("KH_")) {
				iv.setImageResource(R.drawable.kh);
			} else if (config.contains("KI_")) {
				iv.setImageResource(R.drawable.ki);
			} else if (config.contains("KM_")) {
				iv.setImageResource(R.drawable.km);
			}else if(config.contains("KN_")) {
				iv.setImageResource(R.drawable.kn);
			} else if (config.contains("KP_")) {
				iv.setImageResource(R.drawable.kp);
			} else if (config.contains("KR_")) {
				iv.setImageResource(R.drawable.kr);
			} else if (config.contains("KW_")) {
				iv.setImageResource(R.drawable.kw);
			} else if (config.contains("KZ_")) {
				iv.setImageResource(R.drawable.kz);
			} else if (config.contains("LA_")) {
				iv.setImageResource(R.drawable.la);
			} else if (config.contains("LB_")) {
				iv.setImageResource(R.drawable.lb);
			} else if (config.contains("LC_")) {
				iv.setImageResource(R.drawable.lc);
			} else if (config.contains("LI_")) {
				iv.setImageResource(R.drawable.li);
			} else if (config.contains("LK_")) {
				iv.setImageResource(R.drawable.lk);
			} else if (config.contains("LR_")) {
				iv.setImageResource(R.drawable.lr);
			} else if (config.contains("LS_")) {
				iv.setImageResource(R.drawable.ls);
			} else if (config.contains("LT_")) {
				iv.setImageResource(R.drawable.lt);
			} else if (config.contains("LU_")) {
				iv.setImageResource(R.drawable.lu);
			} else if (config.contains("LV_")) {
				iv.setImageResource(R.drawable.lv);
			} else if (config.contains("LY_")) {
				iv.setImageResource(R.drawable.ly);
			} else if (config.contains("MA_")) {
				iv.setImageResource(R.drawable.ma);
			} else if (config.contains("MC_")) {
				iv.setImageResource(R.drawable.mc);
			} else if (config.contains("MD_")) {
				iv.setImageResource(R.drawable.md);
			} else if (config.contains("ME_")) {
				iv.setImageResource(R.drawable.me);
			} else if (config.contains("MG_")) {
				iv.setImageResource(R.drawable.mg);
			} else if (config.contains("MH_")) {
				iv.setImageResource(R.drawable.mh);
			} else if (config.contains("MK_")) {
				iv.setImageResource(R.drawable.mk);
			} else if (config.contains("ML_")) {
				iv.setImageResource(R.drawable.ml);
			}else if(config.contains("MM_")) {
				iv.setImageResource(R.drawable.mm);
			} else if (config.contains("MN_")) {
				iv.setImageResource(R.drawable.mn);
			} else if (config.contains("MO_")) {
				iv.setImageResource(R.drawable.mo);
			} else if (config.contains("MR_")) {
				iv.setImageResource(R.drawable.mr);
			} else if (config.contains("MT_")) {
				iv.setImageResource(R.drawable.mt);
			} else if (config.contains("MU_")) {
				iv.setImageResource(R.drawable.mu);
			} else if (config.contains("MV_")) {
				iv.setImageResource(R.drawable.mv);
			} else if (config.contains("MW_")) {
				iv.setImageResource(R.drawable.mw);
			} else if (config.contains("MX_")) {
				iv.setImageResource(R.drawable.mx);
			} else if (config.contains("MY_")) {
				iv.setImageResource(R.drawable.my);
			} else if (config.contains("MZ_")) {
				iv.setImageResource(R.drawable.mz);
			} else if (config.contains("NA_")) {
				iv.setImageResource(R.drawable.na);
			} else if (config.contains("NE_")) {
				iv.setImageResource(R.drawable.ne);
			} else if (config.contains("NG_")) {
				iv.setImageResource(R.drawable.ng);
			} else if (config.contains("NI_")) {
				iv.setImageResource(R.drawable.ni);
			} else if (config.contains("NL_")) {
				iv.setImageResource(R.drawable.nl);
			} else if (config.contains("NO_")) {
				iv.setImageResource(R.drawable.no);
			} else if (config.contains("NP_")) {
				iv.setImageResource(R.drawable.np);
			} else if (config.contains("NR_")) {
				iv.setImageResource(R.drawable.nr);
			} else if (config.contains("NZ_")) {
				iv.setImageResource(R.drawable.nz);
			} else if (config.contains("OM_")) {
				iv.setImageResource(R.drawable.om);
			} else if (config.contains("PA_")) {
				iv.setImageResource(R.drawable.pa);
			} else if (config.contains("PE_")) {
				iv.setImageResource(R.drawable.pe);
			} else if (config.contains("PG_")) {
				iv.setImageResource(R.drawable.pg);
			} else if(config.contains("PH_")) {
				iv.setImageResource(R.drawable.ph);
			} else if (config.contains("PK_")) {
				iv.setImageResource(R.drawable.pk);
			} else if (config.contains("PL_")) {
				iv.setImageResource(R.drawable.pl);
			} else if (config.contains("PR_")) {
				iv.setImageResource(R.drawable.pr);
			} else if (config.contains("PS_")) {
				iv.setImageResource(R.drawable.ps);
			} else if (config.contains("PT_")) {
				iv.setImageResource(R.drawable.pt);
			} else if (config.contains("PW_")) {
				iv.setImageResource(R.drawable.pw);
			} else if (config.contains("PY_")) {
				iv.setImageResource(R.drawable.py);
			} else if (config.contains("QA_")) {
				iv.setImageResource(R.drawable.qa);
			} else if (config.contains("RO_")) {
				iv.setImageResource(R.drawable.ro);
			} else if (config.contains("RS_")) {
				iv.setImageResource(R.drawable.rs);
			} else if (config.contains("RU_")) {
				iv.setImageResource(R.drawable.ru);
			} else if (config.contains("RW_")) {
				iv.setImageResource(R.drawable.rw);
			} else if (config.contains("SA_")) {
				iv.setImageResource(R.drawable.sa);
			} else if (config.contains("SB_")) {
				iv.setImageResource(R.drawable.sb);
			} else if (config.contains("SC_")) {
				iv.setImageResource(R.drawable.sc);
			} else if (config.contains("SD_")) {
				iv.setImageResource(R.drawable.sd);
			} else if (config.contains("SE_")) {
				iv.setImageResource(R.drawable.se);
			} else if (config.contains("SG_")) {
				iv.setImageResource(R.drawable.sg);
			} else if (config.contains("SI_")) {
				iv.setImageResource(R.drawable.si);
			} else if (config.contains("SK_")) {
				iv.setImageResource(R.drawable.sk);
			} else if (config.contains("SM_")) {
				iv.setImageResource(R.drawable.sm);
			} else if (config.contains("SN_")) {
				iv.setImageResource(R.drawable.sn);
			} else if (config.contains("SO_")) {
				iv.setImageResource(R.drawable.so);
			} else if(config.contains("SR_")) {
				iv.setImageResource(R.drawable.sr);
			} else if (config.contains("ST_")) {
				iv.setImageResource(R.drawable.st);
			} else if (config.contains("SV_")) {
				iv.setImageResource(R.drawable.sv);
			} else if (config.contains("SX_")) {
				iv.setImageResource(R.drawable.sx);
			} else if (config.contains("SY_")) {
				iv.setImageResource(R.drawable.sy);
			} else if (config.contains("SZ_")) {
				iv.setImageResource(R.drawable.sz);
			} else if (config.contains("TD_")) {
				iv.setImageResource(R.drawable.td);
			} else if (config.contains("TG_")) {
				iv.setImageResource(R.drawable.tg);
			} else if (config.contains("TH_")) {
				iv.setImageResource(R.drawable.th);
			} else if (config.contains("TJ_")) {
				iv.setImageResource(R.drawable.tj);
			} else if (config.contains("TL_")) {
				iv.setImageResource(R.drawable.tl);
			} else if (config.contains("TM_")) {
				iv.setImageResource(R.drawable.tm);
			} else if (config.contains("TN_")) {
				iv.setImageResource(R.drawable.tn);
			} else if (config.contains("TO_")) {
				iv.setImageResource(R.drawable.to);
			} else if (config.contains("TR_")) {
				iv.setImageResource(R.drawable.tr);
			} else if (config.contains("TT_")) {
				iv.setImageResource(R.drawable.tt);
			} else if (config.contains("TV_")) {
				iv.setImageResource(R.drawable.tv);
			} else if (config.contains("TZ_")) {
				iv.setImageResource(R.drawable.tz);
			} else if (config.contains("UA_")) {
				iv.setImageResource(R.drawable.ua);
			} else if (config.contains("UG_")) {
				iv.setImageResource(R.drawable.ug);
			} else if (config.contains("US_")) {
				iv.setImageResource(R.drawable.us);
			} else if (config.contains("UY_")) {
				iv.setImageResource(R.drawable.uy);
			} else if (config.contains("UZ_")) {
				iv.setImageResource(R.drawable.uz);
			} else if (config.contains("VA_")) {
				iv.setImageResource(R.drawable.va);
			} else if(config.contains("VC_")) {
				iv.setImageResource(R.drawable.vc);
			} else if (config.contains("VE_")) {
				iv.setImageResource(R.drawable.ve);
			} else if (config.contains("VN_")) {
				iv.setImageResource(R.drawable.vn);
			} else if (config.contains("VU_")) {
				iv.setImageResource(R.drawable.vu);
			} else if (config.contains("WS_")) {
				iv.setImageResource(R.drawable.ws);
			} else if (config.contains("YE_")) {
				iv.setImageResource(R.drawable.ye);
			} else if (config.contains("ZA_")) {
				iv.setImageResource(R.drawable.za);
			} else if (config.contains("ZM_")) {
				iv.setImageResource(R.drawable.zm);
			} else if (config.contains("ZW_")) {
				iv.setImageResource(R.drawable.zw);
			} else {
				iv.setImageResource(R.drawable.harlie_icon);
			}
			ServerLinearLayout.startAnimation(anim);
			return v;

		}

	}
}


