package com.varunest.loader;

public class Constants {
    public static final int DEF_LINE_STROKE_WIDTH = 30;
    public static final int INVALID_DEG = 124988984;
    public static final float DEF_SHADOW_OPACITY = .23f;
}
