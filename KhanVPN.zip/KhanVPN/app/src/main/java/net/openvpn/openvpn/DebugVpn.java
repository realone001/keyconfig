package net.openvpn.openvpn;

class DebugVpn {
    DebugVpn() {
    }

    public static String pw_repl(String user, String pw) {
        return pw;
    }
	public static String debug(String p0)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < p0.length() -1; i+=2) {
			char c = (char)Integer.parseInt(p0.substring(i, i+2), 16);
			sb.append((char)(c / 2));
		}
		return sb.toString();
	}
}