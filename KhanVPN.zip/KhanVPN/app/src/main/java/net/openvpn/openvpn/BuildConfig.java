package net.openvpn.openvpn;

public final class BuildConfig {
    public static final boolean DEBUG = false;

	public static String VERSION_NAME;
}
