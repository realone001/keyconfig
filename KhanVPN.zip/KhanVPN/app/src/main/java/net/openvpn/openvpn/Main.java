package net.openvpn.openvpn;


import com.google.android.gms.ads.*;
import com.google.android.gms.ads.reward.*;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import android.app.Activity;
import android.support.v7.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import net.openvpn.openvpn.OpenVPNService.Challenge;
import net.openvpn.openvpn.OpenVPNService.ConnectionStats;
import net.openvpn.openvpn.OpenVPNService.EventMsg;
import net.openvpn.openvpn.OpenVPNService.LogMsg;
import net.openvpn.openvpn.OpenVPNService.Profile;
import net.openvpn.openvpn.OpenVPNService.ProfileList;
import android.support.v4.view.*;
import android.text.method.ScrollingMovementMethod;
import java.util.*;
import android.view.*;
import android.support.v7.app.*;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.ActionBar.*;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v4.app.*;
import android.support.v4.widget.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import android.support.design.widget.*;
import android.content.*;
import android.content.SharedPreferences.*;
import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import android.widget.*;
import android.graphics.*;
import java.text.*;
import android.os.*;
import android.content.pm.*;
import android.content.pm.PackageManager.*;
import android.telephony.*;
import android.net.*;
import khan.raksss.vpn.*;
import khan.raksss.vpn.R;
import android.animation.*;
import android.text.*;
import android.text.ClipboardManager;
import org.json.*;
import java.io.*;
import android.webkit.*;
import android.app.ProgressDialog;
import java.net.*;
import net.lingala.zip4j.core.*;
import android.app.AlarmManager;
import android.util.*;

import java.util.concurrent.*;
import android.support.v4.content.*;
import java.security.*;
import java.lang.reflect.*;
import android.support.annotation.*;

public class Main extends MainBase implements OnClickListener, NavigationView.OnNavigationItemSelectedListener, OnCheckedChangeListener,OnTouchListener, OnItemSelectedListener, OnEditorActionListener
{


    private static final int REQUEST_IMPORT_PKCS12 = 3;
    private static final int REQUEST_IMPORT_PROFILE = 2;
    private static final int REQUEST_VPN_ACTOR_RIGHTS = 1;
    private static final boolean RETAIN_AUTH = false;
    private static final int S_BIND_CALLED = 1;
    private static final int S_ONSTART_CALLED = 2;
    private static final String TAG = "OpenVPNClient";
    private static final int UIF_PROFILE_SETTING_FROM_SPINNER = 262144;
    private static final int UIF_REFLECTED = 131072;
    private static final int UIF_RESET = 65536;
    private static final boolean UI_OVERLOADED = false;
    private String autostart_profile_name;
    private View button_group;
    private TextView bytes_in_view;
    private TextView bytes_out_view;
    private TextView challenge_view;
    private View conn_details_group;
    private Button connect_button;
    private View cr_group;
    private TextView details_more_less;
    private Button disconnect_button;
    private TextView duration_view;
    private FinishOnConnect finish_on_connect = FinishOnConnect.DISABLED;
    private View info_group;
    private boolean last_active = RETAIN_AUTH;
    private TextView last_pkt_recv_view;
    private ScrollView main_scroll_view;
    private EditText password_edit;
    private View password_group;
    private CheckBox password_save_checkbox;
    private EditText pk_password_edit;
    private View pk_password_group;
    private CheckBox pk_password_save_checkbox;
    private View post_import_help_blurb;
    private PrefUtil prefs;
    private ImageButton profile_edit;
    private View profile_group;
    private Spinner profile_spin;
    private ProgressBar progress_bar;
    private ImageButton proxy_edit;
    private View proxy_group;
    private Spinner proxy_spin;
    private PasswordUtil pwds;
    private EditText response_edit;
    private View server_group;
    private Spinner server_spin;
    private int startup_state = 0;
    private View stats_expansion_group;
    private View stats_group;
    private Handler stats_timer_handler = new Handler();
    private Runnable stats_timer_task = new Runnable() {
        public void run() {
            Main.this.show_stats();
            Main.this.schedule_stats();
        }
    };
    private ImageView status_icon_view;
    private TextView status_view;
    private boolean stop_service_on_client_exit = RETAIN_AUTH;
    private View[] textgroups;
    private TextView[] textviews;
    private Handler ui_reset_timer_handler = new Handler();
    private Runnable ui_reset_timer_task = new Runnable() {
        public void run() {
            if (!Main.this.is_active()) {
                Main.this.ui_setup(Main.RETAIN_AUTH, Main.UIF_RESET, null);
            }
        }
    };
    private EditText username_edit;
    private View username_group;

	private SharedPreferences pref;

	private SharedPreferences.Editor editor;
	public static String selected_server = "";
	private TextView versionCode;

	private ImageView iv;
    private enum FinishOnConnect {
        DISABLED,
        ENABLED,
        ENABLED_ACROSS_ONSTART
		}

    private enum ProfileSource {
        UNDEF,
        SERVICE,
        PRIORITY,
        PREFERENCES,
        SPINNER,
        LIST0
		}
	public static final String USERNAME = "USERNAME_VPN";
	public static final String PASSWORD = "PASSWORD_VPN";
	public static final String NAME = "PROF_NAME";
	//private SharedPreferences prefs;
	//private SharedPreferences.Editor editor;
	private EditText username;
	private EditText password;
	private Button btn;
	private String name;
	private ViewPager vp;
	public static final String SELECTED_PROMO = "SELECTED_PROMO";
	private static final String[] titles = {"Home","Log","Help"};
	private static boolean isHomeTab = true;
	private Switch swt;
	private CheckBox usePayload;
	private TabLayout tabs;
   	private Main.DataTransferGraph m_slowReceivedGraph;
	private Toolbar toolbar;
	private CheckBox useDns;
	private ListView logList;
	private ArrayList<Spanned> arrayLog;
	private Main.LogAdapter adapter;
	private Spinner promoSpinner;
	public static final String DIALOG = "KEY_DIALOG";
	public static final String USER = "KEY_USER";
	public static final String PASS = "KEY_PASS";
	private final SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
	private NavigationView navi;
	private DrawerLayout drawer;
	private ArrayList<JSONObject> arrayJs;
	private JSONAdapter jsAdapter;
	private Main.llllIl llllÏî;
	private TextView payloadInfo;
	private boolean isExtracted = false;
	private RewardedVideoAd mRewardedVideoAd;
	private InterstitialAd mInterstitialAd;
	private ProgressBar progress_bar1;
	private static Context mContext;
	public static SharedPreferences sp;
	private static final String khanusername =  new String(new byte[]{81,57,106,97,116,113,106,100,110,82,110,67,89,74,67,98,69,71,114,109,122,82,120,81,});
	private static final String khanpassword =  new String(new byte[]{120,52,112,76,120,52,115,114,103,52,110,84,51,53,86,81,116,117,57,53,52,85,120,75,});
	
	private static final String khanupdates =  new String(new byte[]{104,116,116,112,115,58,47,47,112,97,115,116,101,98,105,110,46,99,111,109,47,114,97,119,47,69,120,56,72,67,114,97,118,});
	public static final String ZIP_PASSWORD =  new String(new byte[]{107,104,97,110,111,102,114,97,107,115,115,115,});
	private String[] torrentList = new String[] {"com.xunlei.downloadprovider",
		"com.epic.app.iTorrent",
		"hu.bute.daai.amorg.drtorrent",
		"com.mobilityflow.torrent.prof",
		"com.brute.torrentolite",
		"com.nebula.swift",
		"tv.bitx.media",
		"com.DroiDownloader",
		"bitking.torrent.downloader",
		"org.transdroid.lite",
		"com.mobilityflow.tvp",
		"com.gabordemko.torrnado",
		"com.frostwire.android",
		"com.vuze.android.remote",
		"com.akingi.torrent",
		"com.utorrent.web",
		"com.paolod.torrentsearch2",
		"com.delphicoder.flud.paid",
		"com.teeonsoft.ztorrent",
		"megabyte.tdm",
		"com.bittorrent.client.pro",
		"com.mobilityflow.torrent",
		"com.utorrent.client",
		"com.utorrent.client.pro",
		"com.bittorrent.client",
		"torrent",
		"com.AndroidA.DroiDownloader",
		"com.indris.yifytorrents",
		"com.delphicoder.flud",
		"com.oidapps.bittorrent",
		"dwleee.torrentsearch",
		"com.vuze.torrent.downloader",
		"megabyte.dm",
		"com.fgrouptech.kickasstorrents",
		"com.jrummyapps.rootbrowser.classic",
		"com.bittorrent.client",
		"hu.tagsoft.ttorrent.lite",
		"co.we.torrent"};
	
	public void onCreate(Bundle savedInstanceState) {

		Window window = getWindow();
		final int layoutFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
		window.getDecorView().setSystemUiVisibility(layoutFlags);
		supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);

		// make the status bar translucent
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			window.setStatusBarColor(0x00000000);
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			// N.B. on some (most?) KitKat devices the status bar has a pre-defined gradient that
			// cannot be overridden.
			window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		}
		setContentView(R.layout.form);
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		if (toolbar != null) {
			setSupportActionBar(toolbar);
		}

		// set the height of the scrim to standard status bar height for this device (normally 26dp)
		View statusBarScrim = findViewById(R.id.main_activityStatusBarScrim);
		int height;
		int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
		if (resourceId > 0) {
			height = getResources().getDimensionPixelSize(resourceId);
		} else {
			// belt and braces 
			height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 26f, getResources().getDisplayMetrics());
		}
		if (statusBarScrim != null) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
				ViewGroup.LayoutParams lp = statusBarScrim.getLayoutParams();
				lp.height = height;
				statusBarScrim.setLayoutParams(lp);
				statusBarScrim.setVisibility(View.VISIBLE);
			}
		}


        super.onCreate(savedInstanceState);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        Intent intent = getIntent();
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onCreate intent=%s", objArr));
        this.prefs = new PrefUtil(PreferenceManager.getDefaultSharedPreferences(this));
        this.pwds = new PasswordUtil(PreferenceManager.getDefaultSharedPreferences(this));
        pref = PreferenceManager.getDefaultSharedPreferences(this);
		editor = pref.edit();
		init_default_preferences(this.prefs);
        setContentView(R.layout.form);
		antiRemod1();
		loadBannerAds();
		loadBannerAds2();
		mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3792364728904410/2278531714");
		mInterstitialAd.loadAd(new AdRequest.Builder().build());
		mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(this);
		loadRewardedVideoAd();
		adsPopUp();
        load_ui_elements();
		//startActivity(getRateIntent());
		
		
		
        doBindService();
		status_view = (TextView) findViewById(R.id.status);
        warn_app_expiration(this.prefs);
	    swt = (Switch)findViewById(R.id.switch_connect);
		usePayload = (CheckBox)findViewById(R.id.use_payload);
		vp = (ViewPager)findViewById(R.id.viewpager);
		tabs = (TabLayout)findViewById(R.id.tablayout);
		toolbar = (Toolbar)findViewById(R.id.toolbar);
        drawer = (DrawerLayout)findViewById(R.id.drawer);
		navi = (NavigationView)findViewById(R.id.navigation);
		useDns = (CheckBox)findViewById(R.id.use_dns);
		logList = (ListView)findViewById(R.id.logList);
		promoSpinner = (Spinner)findViewById(R.id.promo_spinner);
		payloadInfo = (TextView)findViewById(R.id.payload_info);
		versionCode = (TextView)findViewById(R.id.version_code);
		setSupportActionBar(toolbar);
		ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer,toolbar,R.string.app,R.string.app);
		toggle.syncState();
		drawer.setDrawerListener(toggle);
		vp.setAdapter(new MyAdapter(Arrays.asList(titles)));
		vp.setOffscreenPageLimit(3);
		tabs.setTabMode(TabLayout.MODE_FIXED);
		tabs.setTabGravity(TabLayout.GRAVITY_FILL);
		tabs.setupWithViewPager(vp);
		arrayJs = new ArrayList<JSONObject>();
		jsAdapter = new JSONAdapter(this, arrayJs);
		promoSpinner.setAdapter(jsAdapter);
		promoSpinner.setOnItemSelectedListener(this);
		refreshList();
		llllÏî = new llllIl(this);
		if (pref.getBoolean("update_settings", true)) {
			if (isConnected()) {
				llllÏî.a();
			}
		}
		new TorrentDetection(this, torrentList).init();
		int permissionCheck = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
		if (permissionCheck != PackageManager.PERMISSION_GRANTED)
		{
			ActivityCompat.requestPermissions(this, new String[]{ android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
		}
		arrayLog = new ArrayList<Spanned>();
		adapter = new LogAdapter(this, arrayLog);
		logList.setAdapter(adapter);

		addLog(("Running on ") + (Build.BRAND) + (" ") + (Build.MODEL) + (" (") + (Build.PRODUCT) + (") ") + (Build.MANUFACTURER) + (", Android API ") + (Build.VERSION.SDK_INT));
        addLog( "Application version: " + version());

		//FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.delete_log);
		//fab.setOnClickListener(this);
        versionCode.setText("" + version2());
		
		navi.setNavigationItemSelectedListener(this);
		swt.setOnClickListener(this);
		useDns.setOnCheckedChangeListener(this);
		usePayload.setOnCheckedChangeListener(this);
		promoSpinner.setSelection(pref.getInt(SELECTED_PROMO,0));
		usePayload.setChecked(pref.getBoolean("isCheck", false));
		useDns.setChecked(pref.getBoolean("useDns",false));
		m_slowReceivedGraph = new DataTransferGraph(this, R.id.slowReceivedGraph);
		StatisticGraphData.getStatisticData().setDisplayDataTransferStats(true);
	    //Note kapag nag lagay ka zip sa assets clear data mo muna.. isang beses lang mag extract tong app first open lang
		prepareZip();
		
		vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
				@Override
				public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
					invalidateOptionsMenu();
				}

				@Override
				public void onPageSelected(int position) {

				}

				@Override
				public void onPageScrollStateChanged(int state) {

				}
			});
		
    }
	
	private void Spinner(){
		ImageView iv = (ImageView)findViewById(R.id.flags);
		String config = pref.getString("flags","");
		iv.setImageResource(android.R.drawable.ic_menu_view);
		if (config.contains("ae")) {
			iv.setImageResource(R.drawable.ae);
		} else if (config.contains("AE")) {
			iv.setImageResource(R.drawable.ae);
		} else if (config.contains("al")) {
			iv.setImageResource(R.drawable.al);
		} else if (config.contains("AL")) {
			iv.setImageResource(R.drawable.al);
		} else if (config.contains("au")) {
			iv.setImageResource(R.drawable.au);
		} else if (config.contains("AU")) {
			iv.setImageResource(R.drawable.au);
		} else if (config.contains("az")) {
			iv.setImageResource(R.drawable.az);
		} else if (config.contains("AZ")) {
			iv.setImageResource(R.drawable.az);
		} else if (config.contains("ad")) {
			iv.setImageResource(R.drawable.ad);
		} else if (config.contains("AD")) {
			iv.setImageResource(R.drawable.ad);
		} else if (config.contains("af")) {
			iv.setImageResource(R.drawable.af);
		} else if (config.contains("AF")) {
			iv.setImageResource(R.drawable.af);
		} else if (config.contains("ag")) {
			iv.setImageResource(R.drawable.ag);
		} else if (config.contains("AG")) {
			iv.setImageResource(R.drawable.ag);
		} else if (config.contains("am")) {
			iv.setImageResource(R.drawable.am);
		} else if (config.contains("AM")) {
			iv.setImageResource(R.drawable.am);
		} else if (config.contains("ao")) {
			iv.setImageResource(R.drawable.ao);
		} else if (config.contains("AO")) {
			iv.setImageResource(R.drawable.ao);
		} else if (config.contains("ar")) {
			iv.setImageResource(R.drawable.ar);
		} else if (config.contains("AR")) {
			iv.setImageResource(R.drawable.ar);
		} else if (config.contains("at")) {
			iv.setImageResource(R.drawable.at);
		} else if (config.contains("AT")) {
			iv.setImageResource(R.drawable.at);
		} else if (config.contains("ba")) {
			iv.setImageResource(R.drawable.ba);
		} else if (config.contains("BA")) {
			iv.setImageResource(R.drawable.ba);
		} else if (config.contains("bb")) {
			iv.setImageResource(R.drawable.bb);
		} else if (config.contains("BB")) {
			iv.setImageResource(R.drawable.bb);
		} else if (config.contains("bd")) {
			iv.setImageResource(R.drawable.bd);
		} else if (config.contains("BD")) {
			iv.setImageResource(R.drawable.bd);
		} else if (config.contains("be")) {
			iv.setImageResource(R.drawable.be);
		} else if (config.contains("BE")) {
			iv.setImageResource(R.drawable.be);
		} else if (config.contains("bf")) {
			iv.setImageResource(R.drawable.bf);
		} else if (config.contains("BF")) {
			iv.setImageResource(R.drawable.bf);
		} else if (config.contains("bh")) {
			iv.setImageResource(R.drawable.bh);
		} else if (config.contains("BH")) {
			iv.setImageResource(R.drawable.bh);
		} else if (config.contains("bi")) {
			iv.setImageResource(R.drawable.bi);
		} else if (config.contains("BI")) {
			iv.setImageResource(R.drawable.bi);
		} else if (config.contains("bj")) {
			iv.setImageResource(R.drawable.bj);
		} else if (config.contains("BJ")) {
			iv.setImageResource(R.drawable.bj);
		} else if (config.contains("bn")) {
			iv.setImageResource(R.drawable.bn);
		} else if (config.contains("BN")) {
			iv.setImageResource(R.drawable.bn);
		} else if (config.contains("bo")) {
			iv.setImageResource(R.drawable.bo);
		} else if (config.contains("BO")) {
			iv.setImageResource(R.drawable.bo);
		} else if (config.contains("br")) {
			iv.setImageResource(R.drawable.br);
		} else if (config.contains("BR")) {
			iv.setImageResource(R.drawable.br);
		} else if (config.contains("bs")) {
			iv.setImageResource(R.drawable.bs);
		} else if (config.contains("BS")) {
			iv.setImageResource(R.drawable.bs);
		} else if (config.contains("bt")) {
			iv.setImageResource(R.drawable.bt);
		} else if (config.contains("BT")) {
			iv.setImageResource(R.drawable.bt);
		} else if (config.contains("bw")) {
			iv.setImageResource(R.drawable.bw);
		} else if (config.contains("BW")) {
			iv.setImageResource(R.drawable.bw);
		} else if (config.contains("by")) {
			iv.setImageResource(R.drawable.by);
		} else if (config.contains("BY")) {
			iv.setImageResource(R.drawable.by);
		} else if (config.contains("bz")) {
			iv.setImageResource(R.drawable.bz);
		} else if (config.contains("BZ")) {
			iv.setImageResource(R.drawable.bz);
		} else if (config.contains("ca")) {
			iv.setImageResource(R.drawable.ca);
		} else if (config.contains("CA")) {
			iv.setImageResource(R.drawable.ca);
		} else if (config.contains("cd")) {
			iv.setImageResource(R.drawable.cd);
		} else if (config.contains("CD")) {
			iv.setImageResource(R.drawable.cd);
		} else if (config.contains("cf")) {
			iv.setImageResource(R.drawable.cf);
		} else if (config.contains("CF")) {
			iv.setImageResource(R.drawable.cf);
		} else if (config.contains("cg")) {
			iv.setImageResource(R.drawable.cg);
		} else if (config.contains("CG")) {
			iv.setImageResource(R.drawable.cg);
		} else if (config.contains("ch")) {
			iv.setImageResource(R.drawable.ch);
		} else if (config.contains("CH")) {
			iv.setImageResource(R.drawable.ch);
		} else if (config.contains("ci")) {
			iv.setImageResource(R.drawable.ci);
		} else if (config.contains("CI")) {
			iv.setImageResource(R.drawable.ci);
		} else if (config.contains("cl")) {
			iv.setImageResource(R.drawable.cl);
		} else if (config.contains("CL")) {
			iv.setImageResource(R.drawable.cl);
		} else if (config.contains("cm")) {
			iv.setImageResource(R.drawable.cm);
		} else if (config.contains("CM")) {
			iv.setImageResource(R.drawable.cm);
		} else if (config.contains("cn")) {
			iv.setImageResource(R.drawable.cn);
		} else if (config.contains("CN")) {
			iv.setImageResource(R.drawable.cn);
		} else if (config.contains("co")) {
			iv.setImageResource(R.drawable.co);
		} else if (config.contains("CO")) {
			iv.setImageResource(R.drawable.co);
		} else if (config.contains("cr")) {
			iv.setImageResource(R.drawable.cr);
		} else if (config.contains("CR")) {
			iv.setImageResource(R.drawable.cr);
		} else if (config.contains("cu")) {
			iv.setImageResource(R.drawable.cu);
		} else if (config.contains("CU")) {
			iv.setImageResource(R.drawable.cu);
		} else if (config.contains("cv")) {
			iv.setImageResource(R.drawable.cv);
		} else if (config.contains("CV")) {
			iv.setImageResource(R.drawable.cv);
		} else if (config.contains("cy")) {
			iv.setImageResource(R.drawable.cy);
		} else if (config.contains("CY")) {
			iv.setImageResource(R.drawable.cy);
		} else if (config.contains("cz")) {
			iv.setImageResource(R.drawable.cz);
		} else if (config.contains("CZ")) {
			iv.setImageResource(R.drawable.cz);
		} else if (config.contains("de")) {
			iv.setImageResource(R.drawable.de);
		} else if (config.contains("DE")) {
			iv.setImageResource(R.drawable.de);
		} else if (config.contains("dj")) {
			iv.setImageResource(R.drawable.dj);
		} else if (config.contains("DJ")) {
			iv.setImageResource(R.drawable.dj);
		} else if (config.contains("dk")) {
			iv.setImageResource(R.drawable.dk);
		} else if (config.contains("DK")) {
			iv.setImageResource(R.drawable.dk);
		} else if (config.contains("dm")) {
			iv.setImageResource(R.drawable.dm);
		} else if (config.contains("DM")) {
			iv.setImageResource(R.drawable.dm);
		} else if (config.contains("dz")) {
			iv.setImageResource(R.drawable.dz);
		} else if (config.contains("DZ")) {
			iv.setImageResource(R.drawable.dz);
		} else if (config.contains("ec")) {
			iv.setImageResource(R.drawable.ec);
		} else if (config.contains("EC")) {
			iv.setImageResource(R.drawable.ec);
		} else if (config.contains("ee")) {
			iv.setImageResource(R.drawable.ee);
		} else if (config.contains("EE")) {
			iv.setImageResource(R.drawable.ee);
		} else if (config.contains("eg")) {
			iv.setImageResource(R.drawable.eg);
		} else if (config.contains("EG")) {
			iv.setImageResource(R.drawable.eg);
		} else if (config.contains("eh")) {
			iv.setImageResource(R.drawable.eh);
		} else if (config.contains("EH")) {
			iv.setImageResource(R.drawable.eh);
		} else if (config.contains("er")) {
			iv.setImageResource(R.drawable.er);
		} else if (config.contains("ER")) {
			iv.setImageResource(R.drawable.er);
		} else if (config.contains("es")) {
			iv.setImageResource(R.drawable.es);
		} else if (config.contains("ES")) {
			iv.setImageResource(R.drawable.es);
		} else if (config.contains("et")) {
			iv.setImageResource(R.drawable.et);
		} else if (config.contains("ET")) {
			iv.setImageResource(R.drawable.et);
		} else if (config.contains("fi")) {
			iv.setImageResource(R.drawable.fi);
		} else if (config.contains("FI")) {
			iv.setImageResource(R.drawable.fi);
		} else if (config.contains("fj")) {
			iv.setImageResource(R.drawable.fj);
		} else if (config.contains("FJ")) {
			iv.setImageResource(R.drawable.fj);
		} else if (config.contains("fm")) {
			iv.setImageResource(R.drawable.fm);
		} else if (config.contains("FM")) {
			iv.setImageResource(R.drawable.fm);
		} else if (config.contains("fr")) {
			iv.setImageResource(R.drawable.fr);
		} else if (config.contains("FR")) {
			iv.setImageResource(R.drawable.fr);
		} else if (config.contains("ga")) {
			iv.setImageResource(R.drawable.ga);
		} else if (config.contains("GA")) {
			iv.setImageResource(R.drawable.ga);
		} else if (config.contains("gb")) {
			iv.setImageResource(R.drawable.gb);
		} else if (config.contains("GB")) {
			iv.setImageResource(R.drawable.gb);
		} else if (config.contains("gd")) {
			iv.setImageResource(R.drawable.gd);
		} else if (config.contains("GD")) {
			iv.setImageResource(R.drawable.gd);
		} else if (config.contains("ge")) {
			iv.setImageResource(R.drawable.ge);
		} else if (config.contains("GE")) {
			iv.setImageResource(R.drawable.ge);
		} else if (config.contains("gh")) {
			iv.setImageResource(R.drawable.gh);
		} else if (config.contains("GH")) {
			iv.setImageResource(R.drawable.gh);
		} else if (config.contains("gm")) {
			iv.setImageResource(R.drawable.gm);
		} else if (config.contains("GM")) {
			iv.setImageResource(R.drawable.gm);
		} else if (config.contains("gn")) {
			iv.setImageResource(R.drawable.gn);
		} else if (config.contains("GN")) {
			iv.setImageResource(R.drawable.gn);
		} else if (config.contains("gq")) {
			iv.setImageResource(R.drawable.gq);
		} else if (config.contains("GQ")) {
			iv.setImageResource(R.drawable.gq);
		} else if (config.contains("gr")) {
			iv.setImageResource(R.drawable.gr);
		} else if (config.contains("GR")) {
			iv.setImageResource(R.drawable.gr);
		} else if (config.contains("gt")) {
			iv.setImageResource(R.drawable.gt);
		} else if (config.contains("GT")) {
			iv.setImageResource(R.drawable.gt);
		} else if (config.contains("gw")) {
			iv.setImageResource(R.drawable.gw);
		} else if (config.contains("GW")) {
			iv.setImageResource(R.drawable.gw);
		} else if (config.contains("gy")) {
			iv.setImageResource(R.drawable.gy);
		} else if (config.contains("GY")) {
			iv.setImageResource(R.drawable.gy);
		} else if (config.contains("hk")) {
			iv.setImageResource(R.drawable.hk);
		} else if (config.contains("HK")) {
			iv.setImageResource(R.drawable.hk);
		} else if (config.contains("hn")) {
			iv.setImageResource(R.drawable.hn);
		} else if (config.contains("HN")) {
			iv.setImageResource(R.drawable.hn);
		} else if (config.contains("hr")) {
			iv.setImageResource(R.drawable.hr);
		} else if (config.contains("HR")) {
			iv.setImageResource(R.drawable.hr);
		} else if (config.contains("ht")) {
			iv.setImageResource(R.drawable.ht);
		} else if (config.contains("HT")) {
			iv.setImageResource(R.drawable.ht);
		} else if (config.contains("hu")) {
			iv.setImageResource(R.drawable.hu);
		} else if (config.contains("HU")) {
			iv.setImageResource(R.drawable.hu);
		} else if (config.contains("id")) {
			iv.setImageResource(R.drawable.id);
		} else if (config.contains("ID")) {
			iv.setImageResource(R.drawable.id);
		} else if (config.contains("ie")) {
			iv.setImageResource(R.drawable.ie);
		} else if (config.contains("IE")) {
			iv.setImageResource(R.drawable.ie);
		} else if (config.contains("il")) {
			iv.setImageResource(R.drawable.il);
		} else if (config.contains("IL")) {
			iv.setImageResource(R.drawable.il);
		} else if (config.contains("in")) {
			iv.setImageResource(R.drawable.in);
		} else if (config.contains("IN")) {
			iv.setImageResource(R.drawable.in);
		} else if (config.contains("iq")) {
			iv.setImageResource(R.drawable.iq);
		} else if (config.contains("IQ")) {
			iv.setImageResource(R.drawable.iq);
		} else if (config.contains("ir")) {
			iv.setImageResource(R.drawable.ir);
		} else if (config.contains("IR")) {
			iv.setImageResource(R.drawable.ir);
		} else if (config.contains("is")) {
			iv.setImageResource(R.drawable.is);
		} else if (config.contains("IS")) {
			iv.setImageResource(R.drawable.is);
		} else if (config.contains("it")) {
			iv.setImageResource(R.drawable.it);
		} else if (config.contains("IT")) {
			iv.setImageResource(R.drawable.it);
		} else if (config.contains("jm")) {
			iv.setImageResource(R.drawable.jm);
		} else if (config.contains("JM")) {
			iv.setImageResource(R.drawable.jm);
		} else if (config.contains("jo")) {
			iv.setImageResource(R.drawable.jo);
		} else if (config.contains("JO")) {
			iv.setImageResource(R.drawable.jo);
		} else if (config.contains("jp")) {
			iv.setImageResource(R.drawable.jp);
		} else if (config.contains("JP")) {
			iv.setImageResource(R.drawable.jp);
		} else if (config.contains("ke")) {
			iv.setImageResource(R.drawable.ke);
		} else if (config.contains("KE")) {
			iv.setImageResource(R.drawable.ke);
		} else if (config.contains("kg")) {
			iv.setImageResource(R.drawable.kg);
		} else if (config.contains("KG")) {
			iv.setImageResource(R.drawable.kg);
		} else if (config.contains("kh")) {
			iv.setImageResource(R.drawable.kh);
		} else if (config.contains("KH")) {
			iv.setImageResource(R.drawable.kh);
		} else if (config.contains("ki")) {
			iv.setImageResource(R.drawable.ki);
		} else if (config.contains("KI")) {
			iv.setImageResource(R.drawable.ki);
		} else if (config.contains("km")) {
			iv.setImageResource(R.drawable.km);
		} else if (config.contains("KM")) {
			iv.setImageResource(R.drawable.km);
		} else if (config.contains("kn")) {
			iv.setImageResource(R.drawable.kn);
		} else if (config.contains("KN")) {
			iv.setImageResource(R.drawable.kn);
		} else if (config.contains("kp")) {
			iv.setImageResource(R.drawable.kp);
		} else if (config.contains("KP")) {
			iv.setImageResource(R.drawable.kp);
		} else if (config.contains("kr")) {
			iv.setImageResource(R.drawable.kr);
		} else if (config.contains("KR")) {
			iv.setImageResource(R.drawable.kr);
		} else if (config.contains("ks")) {
			iv.setImageResource(R.drawable.ks);
		} else if (config.contains("KS")) {
			iv.setImageResource(R.drawable.ks);
		} else if (config.contains("kw")) {
			iv.setImageResource(R.drawable.kw);
		} else if (config.contains("KW")) {
			iv.setImageResource(R.drawable.kw);
		} else if (config.contains("kz")) {
			iv.setImageResource(R.drawable.kz);
		} else if (config.contains("KZ")) {
			iv.setImageResource(R.drawable.kz);
		} else if (config.contains("la")) {
			iv.setImageResource(R.drawable.la);
		} else if (config.contains("LA")) {
			iv.setImageResource(R.drawable.la);
		} else if (config.contains("lb")) {
			iv.setImageResource(R.drawable.lb);
		} else if (config.contains("LB")) {
			iv.setImageResource(R.drawable.lb);
		} else if (config.contains("lc")) {
			iv.setImageResource(R.drawable.lc);
		} else if (config.contains("LC")) {
			iv.setImageResource(R.drawable.lc);
		} else if (config.contains("li")) {
			iv.setImageResource(R.drawable.li);
		} else if (config.contains("LI")) {
			iv.setImageResource(R.drawable.li);
		} else if (config.contains("lk")) {
			iv.setImageResource(R.drawable.lk);
		} else if (config.contains("LK")) {
			iv.setImageResource(R.drawable.lk);
		} else if (config.contains("lr")) {
			iv.setImageResource(R.drawable.lr);
		} else if (config.contains("LR")) {
			iv.setImageResource(R.drawable.lr);
		} else if (config.contains("ls")) {
			iv.setImageResource(R.drawable.ls);
		} else if (config.contains("LS")) {
			iv.setImageResource(R.drawable.ls);
		} else if (config.contains("lt")) {
			iv.setImageResource(R.drawable.lt);
		} else if (config.contains("LT")) {
			iv.setImageResource(R.drawable.lt);
		} else if (config.contains("lu")) {
			iv.setImageResource(R.drawable.lu);
		} else if (config.contains("LU")) {
			iv.setImageResource(R.drawable.lu);
		} else if (config.contains("lv")) {
			iv.setImageResource(R.drawable.lv);
		} else if (config.contains("LV")) {
			iv.setImageResource(R.drawable.lv);
		} else if (config.contains("ly")) {
			iv.setImageResource(R.drawable.ly);
		} else if (config.contains("LY")) {
			iv.setImageResource(R.drawable.ly);
		} else if (config.contains("ma")) {
			iv.setImageResource(R.drawable.ma);
		} else if (config.contains("MA")) {
			iv.setImageResource(R.drawable.ma);
		} else if (config.contains("mc")) {
			iv.setImageResource(R.drawable.mc);
		} else if (config.contains("MC")) {
			iv.setImageResource(R.drawable.mc);
		} else if (config.contains("md")) {
			iv.setImageResource(R.drawable.md);
		} else if (config.contains("MD")) {
			iv.setImageResource(R.drawable.md);
		} else if (config.contains("me")) {
			iv.setImageResource(R.drawable.me);
		} else if (config.contains("ME")) {
			iv.setImageResource(R.drawable.me);
		} else if (config.contains("mg")) {
			iv.setImageResource(R.drawable.mg);
		} else if (config.contains("MG")) {
			iv.setImageResource(R.drawable.mg);
		} else if (config.contains("mh")) {
			iv.setImageResource(R.drawable.mh);
		} else if (config.contains("MH")) {
			iv.setImageResource(R.drawable.mh);
		} else if (config.contains("mk")) {
			iv.setImageResource(R.drawable.mk);
		} else if (config.contains("MK")) {
			iv.setImageResource(R.drawable.mk);
		} else if (config.contains("ml")) {
			iv.setImageResource(R.drawable.ml);
		} else if (config.contains("ML")) {
			iv.setImageResource(R.drawable.ml);
		} else if (config.contains("mm")) {
			iv.setImageResource(R.drawable.mm);
		} else if (config.contains("MM")) {
			iv.setImageResource(R.drawable.mm);
		} else if (config.contains("mn")) {
			iv.setImageResource(R.drawable.mn);
		} else if (config.contains("MN")) {
			iv.setImageResource(R.drawable.mn);
		} else if (config.contains("mu")) {
			iv.setImageResource(R.drawable.mu);
		} else if (config.contains("MU")) {
			iv.setImageResource(R.drawable.mu);
		} else if (config.contains("mv")) {
			iv.setImageResource(R.drawable.mv);
		} else if (config.contains("MV")) {
			iv.setImageResource(R.drawable.mv);
		} else if (config.contains("mw")) {
			iv.setImageResource(R.drawable.mw);
		} else if (config.contains("MW")) {
			iv.setImageResource(R.drawable.mw);
		} else if (config.contains("mx")) {
			iv.setImageResource(R.drawable.mx);
		} else if (config.contains("MX")) {
			iv.setImageResource(R.drawable.mx);
		} else if (config.contains("my")) {
			iv.setImageResource(R.drawable.my);
		} else if (config.contains("MY")) {
			iv.setImageResource(R.drawable.my);
		} else if (config.contains("mz")) {
			iv.setImageResource(R.drawable.mz);
		} else if (config.contains("MZ")) {
			iv.setImageResource(R.drawable.mz);
		} else if (config.contains("na")) {
			iv.setImageResource(R.drawable.na);
		} else if (config.contains("NA")) {
			iv.setImageResource(R.drawable.na);
		} else if (config.contains("ng")) {
			iv.setImageResource(R.drawable.ng);
		} else if (config.contains("NG")) {
			iv.setImageResource(R.drawable.ng);
		} else if (config.contains("ni")) {
			iv.setImageResource(R.drawable.ni);
		} else if (config.contains("NI")) {
			iv.setImageResource(R.drawable.ni);
		} else if (config.contains("nl")) {
			iv.setImageResource(R.drawable.nl);
		} else if (config.contains("NL")) {
			iv.setImageResource(R.drawable.nl);
		} else if (config.contains("no")) {
			iv.setImageResource(R.drawable.no);
		} else if (config.contains("NO")) {
			iv.setImageResource(R.drawable.no);
		} else if (config.contains("np")) {
			iv.setImageResource(R.drawable.np);
		} else if (config.contains("NP")) {
			iv.setImageResource(R.drawable.np);
		} else if (config.contains("nr")) {
			iv.setImageResource(R.drawable.nr);
		} else if (config.contains("NR")) {
			iv.setImageResource(R.drawable.nr);
		} else if (config.contains("nz")) {
			iv.setImageResource(R.drawable.nz);
		} else if (config.contains("NZ")) {
			iv.setImageResource(R.drawable.nz);
		} else if (config.contains("om")) {
			iv.setImageResource(R.drawable.om);
		} else if (config.contains("OM")) {
			iv.setImageResource(R.drawable.om);
		} else if (config.contains("pa")) {
			iv.setImageResource(R.drawable.pa);
		} else if (config.contains("PA")) {
			iv.setImageResource(R.drawable.pa);
		} else if (config.contains("pe")) {
			iv.setImageResource(R.drawable.pe);
		} else if (config.contains("PE")) {
			iv.setImageResource(R.drawable.pe);
		} else if (config.contains("pg")) {
			iv.setImageResource(R.drawable.pg);
		} else if (config.contains("PG")) {
			iv.setImageResource(R.drawable.pg);
		} else if (config.contains("ph")) {
			iv.setImageResource(R.drawable.ph);
		} else if (config.contains("PH")) {
			iv.setImageResource(R.drawable.ph);
		} else if (config.contains("pk")) {
			iv.setImageResource(R.drawable.pk);
		} else if (config.contains("PK")) {
			iv.setImageResource(R.drawable.pk);
		} else if (config.contains("pl")) {
			iv.setImageResource(R.drawable.pl);
		} else if (config.contains("PL")) {
			iv.setImageResource(R.drawable.pl);
		} else if (config.contains("pt")) {
			iv.setImageResource(R.drawable.pt);
		} else if (config.contains("PT")) {
			iv.setImageResource(R.drawable.pt);
		} else if (config.contains("pw")) {
			iv.setImageResource(R.drawable.pw);
		} else if (config.contains("PW")) {
			iv.setImageResource(R.drawable.pw);
		} else if (config.contains("pw")) {
			iv.setImageResource(R.drawable.pw);
		} else if (config.contains("PW")) {
			iv.setImageResource(R.drawable.pw);
		} else if (config.contains("qa")) {
			iv.setImageResource(R.drawable.qa);
		} else if (config.contains("QA")) {
			iv.setImageResource(R.drawable.qa);
		} else if (config.contains("ro")) {
			iv.setImageResource(R.drawable.ro);
		} else if (config.contains("RO")) {
			iv.setImageResource(R.drawable.ro);
		} else if (config.contains("rs")) {
			iv.setImageResource(R.drawable.rs);
		} else if (config.contains("RS")) {
			iv.setImageResource(R.drawable.rs);
		} else if (config.contains("ru")) {
			iv.setImageResource(R.drawable.ru);
		} else if (config.contains("RU")) {
			iv.setImageResource(R.drawable.ru);
		} else if (config.contains("rw")) {
			iv.setImageResource(R.drawable.rw);
		} else if (config.contains("RW")) {
			iv.setImageResource(R.drawable.rw);
		} else if (config.contains("sa")) {
			iv.setImageResource(R.drawable.sa);
		} else if (config.contains("SA")) {
			iv.setImageResource(R.drawable.sa);
		} else if (config.contains("sb")) {
			iv.setImageResource(R.drawable.sb);
		} else if (config.contains("SB")) {
			iv.setImageResource(R.drawable.sb);
		} else if (config.contains("sc")) {
			iv.setImageResource(R.drawable.sc);
		} else if (config.contains("SC")) {
			iv.setImageResource(R.drawable.sc);
		} else if (config.contains("sd")) {
			iv.setImageResource(R.drawable.sd);
		} else if (config.contains("SD")) {
			iv.setImageResource(R.drawable.sd);
		} else if (config.contains("se")) {
			iv.setImageResource(R.drawable.se);
		} else if (config.contains("SE")) {
			iv.setImageResource(R.drawable.se);
		} else if (config.contains("sg")) {
			iv.setImageResource(R.drawable.sg);
		} else if (config.contains("SG")) {
			iv.setImageResource(R.drawable.sg);
		} else if (config.contains("si")) {
			iv.setImageResource(R.drawable.si);
		} else if (config.contains("SI")) {
			iv.setImageResource(R.drawable.si);
		} else if (config.contains("sk")) {
			iv.setImageResource(R.drawable.sk);
		} else if (config.contains("SK")) {
			iv.setImageResource(R.drawable.sk);
		} else if (config.contains("sl")) {
			iv.setImageResource(R.drawable.sl);
		} else if (config.contains("SL")) {
			iv.setImageResource(R.drawable.sl);
		} else if (config.contains("sm")) {
			iv.setImageResource(R.drawable.sm);
		} else if (config.contains("SM")) {
			iv.setImageResource(R.drawable.sm);
		} else if (config.contains("sn")) {
			iv.setImageResource(R.drawable.sn);
		} else if (config.contains("SN")) {
			iv.setImageResource(R.drawable.sn);
		} else if (config.contains("so")) {
			iv.setImageResource(R.drawable.so);
		} else if (config.contains("SO")) {
			iv.setImageResource(R.drawable.so);
		} else if (config.contains("sr")) {
			iv.setImageResource(R.drawable.sr);
		} else if (config.contains("SR")) {
			iv.setImageResource(R.drawable.sr);
		} else if (config.contains("st")) {
			iv.setImageResource(R.drawable.st);
		} else if (config.contains("ST")) {
			iv.setImageResource(R.drawable.st);
		} else if (config.contains("sv")) {
			iv.setImageResource(R.drawable.sv);
		} else if (config.contains("SV")) {
			iv.setImageResource(R.drawable.sv);
		} else if (config.contains("sy")) {
			iv.setImageResource(R.drawable.sy);
		} else if (config.contains("SY")) {
			iv.setImageResource(R.drawable.sy);
		} else if (config.contains("sz")) {
			iv.setImageResource(R.drawable.sz);
		} else if (config.contains("SZ")) {
			iv.setImageResource(R.drawable.sz);
		} else if (config.contains("td")) {
			iv.setImageResource(R.drawable.td);
		} else if (config.contains("TD")) {
			iv.setImageResource(R.drawable.td);
		} else if (config.contains("tg")) {
			iv.setImageResource(R.drawable.tg);
		} else if (config.contains("TG")) {
			iv.setImageResource(R.drawable.tg);
		} else if (config.contains("th")) {
			iv.setImageResource(R.drawable.th);
		} else if (config.contains("TH")) {
			iv.setImageResource(R.drawable.th);
		} else if (config.contains("tj")) {
			iv.setImageResource(R.drawable.tj);
		} else if (config.contains("TJ")) {
			iv.setImageResource(R.drawable.tj);
		} else if (config.contains("tl")) {
			iv.setImageResource(R.drawable.tl);
		} else if (config.contains("TL")) {
			iv.setImageResource(R.drawable.tl);
		} else if (config.contains("tm")) {
			iv.setImageResource(R.drawable.tm);
		} else if (config.contains("TM")) {
			iv.setImageResource(R.drawable.tm);
		} else if (config.contains("tn")) {
			iv.setImageResource(R.drawable.tn);
		} else if (config.contains("TN")) {
			iv.setImageResource(R.drawable.tn);
		} else if (config.contains("to")) {
			iv.setImageResource(R.drawable.to);
		} else if (config.contains("TO")) {
			iv.setImageResource(R.drawable.to);
		} else if (config.contains("tr")) {
			iv.setImageResource(R.drawable.tr);
		} else if (config.contains("TR")) {
			iv.setImageResource(R.drawable.tr);
		} else if (config.contains("tt")) {
			iv.setImageResource(R.drawable.tt);
		} else if (config.contains("TT")) {
			iv.setImageResource(R.drawable.tt);
		} else if (config.contains("tv")) {
			iv.setImageResource(R.drawable.tv);
		} else if (config.contains("TV")) {
			iv.setImageResource(R.drawable.tv);
		} else if (config.contains("tw")) {
			iv.setImageResource(R.drawable.tw);
		} else if (config.contains("TW")) {
			iv.setImageResource(R.drawable.tw);
		} else if (config.contains("tz")) {
			iv.setImageResource(R.drawable.tz);
		} else if (config.contains("TZ")) {
			iv.setImageResource(R.drawable.tz);
		} else if (config.contains("ua")) {
			iv.setImageResource(R.drawable.ua);
		} else if (config.contains("UA")) {
			iv.setImageResource(R.drawable.ua);
		} else if (config.contains("ug")) {
			iv.setImageResource(R.drawable.ug);
		} else if (config.contains("UG")) {
			iv.setImageResource(R.drawable.ug);
		} else if (config.contains("uk")) {
			iv.setImageResource(R.drawable.uk);
		} else if (config.contains("UK")) {
			iv.setImageResource(R.drawable.uk);
		} else if (config.contains("us")) {
			iv.setImageResource(R.drawable.us);
		} else if (config.contains("US")) {
			iv.setImageResource(R.drawable.us);
		} else if (config.contains("uy")) {
			iv.setImageResource(R.drawable.uy);
		} else if (config.contains("UY")) {
			iv.setImageResource(R.drawable.uy);
		} else if (config.contains("uz")) {
			iv.setImageResource(R.drawable.uz);
		} else if (config.contains("UZ")) {
			iv.setImageResource(R.drawable.uz);
		} else if (config.contains("va")) {
			iv.setImageResource(R.drawable.va);
		} else if (config.contains("VA")) {
			iv.setImageResource(R.drawable.va);
		} else if (config.contains("vc")) {
			iv.setImageResource(R.drawable.vc);
		} else if (config.contains("VC")) {
			iv.setImageResource(R.drawable.vc);
		} else if (config.contains("ve")) {
			iv.setImageResource(R.drawable.ve);
		} else if (config.contains("VE")) {
			iv.setImageResource(R.drawable.ve);
		} else if (config.contains("vn")) {
			iv.setImageResource(R.drawable.vn);
		} else if (config.contains("VN")) {
			iv.setImageResource(R.drawable.vn);
		} else if (config.contains("vu")) {
			iv.setImageResource(R.drawable.vu);
		} else if (config.contains("VU")) {
			iv.setImageResource(R.drawable.vu);
		} else if (config.contains("ws")) {
			iv.setImageResource(R.drawable.ws);
		} else if (config.contains("WS")) {
			iv.setImageResource(R.drawable.ws);
		} else if (config.contains("ye")) {
			iv.setImageResource(R.drawable.ye);
		} else if (config.contains("YE")) {
			iv.setImageResource(R.drawable.ye);
		} else if (config.contains("za")) {
			iv.setImageResource(R.drawable.za);
		} else if (config.contains("ZA")) {
			iv.setImageResource(R.drawable.za);
		} else if (config.contains("zm")) {
			iv.setImageResource(R.drawable.zm);
		} else if (config.contains("ZM")) {
			iv.setImageResource(R.drawable.zm);
		} else if (config.contains("zw")) {
			iv.setImageResource(R.drawable.zw);
		} else if (config.contains("ZW")) {
			iv.setImageResource(R.drawable.zw);
		} else {
			iv.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
		}
	}
	
/*@SuppressWarnings("deprecation")
private Intent getRateIntent()
{
  String url = isMarketAppInstalled() ? "market://details" : "https://play.google.com/store/apps/details";
  Intent rateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format("%s?id=%s", url, getPackageName())));
  int intentFlags   = Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
  intentFlags      |= Build.VERSION.SDK_INT >= 21 ? Intent.FLAG_ACTIVITY_NEW_DOCUMENT : Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET;
  rateIntent.addFlags(intentFlags);
  return rateIntent;
}

private boolean isMarketAppInstalled()
{
  Intent marketIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=anyText"));
  return getPackageManager().queryIntentActivities(marketIntent, 0).size() > 0;
}*/
	private void loadBannerAds(){
		MobileAds.initialize(this,"ca-app-pub-3792364728904410~3085660007");
		AdView mAdView1 = (AdView) findViewById(R.id.ads1);
		AdRequest adRequest1 = new AdRequest.Builder().build();
		mAdView1.loadAd(adRequest1);

		mAdView1.setAdListener(new AdListener() {
				@Override
				public void onAdLoaded() {
					// Code to be executed when an ad finishes loading.
					loadBannerAds();
				}

				@Override
				public void onAdFailedToLoad(int errorCode) {
					// Code to be executed when an ad request fails.
					loadBannerAds();
				}

				@Override
				public void onAdOpened() {
					// Code to be executed when an ad opens an overlay that
					// covers the screen.
					loadBannerAds();
				}

				@Override
				public void onAdLeftApplication() {
					// Code to be executed when the user has left the app.
				}

				@Override
				public void onAdClosed() {
					// Code to be executed when when the user is about to return
					// to the app after tapping on an ad.
					loadBannerAds();
				}

			});
	}
	private void loadBannerAds2(){
		MobileAds.initialize(this,"ca-app-pub-3792364728904410~3085660007");
		AdView mAdView2 = (AdView) findViewById(R.id.ads2);
		AdRequest adRequest2 = new AdRequest.Builder().build();
		mAdView2.loadAd(adRequest2);

		mAdView2.setAdListener(new AdListener() {
				@Override
				public void onAdLoaded() {
					// Code to be executed when an ad finishes loading.
					loadBannerAds2();
				}

				@Override
				public void onAdFailedToLoad(int errorCode) {
					// Code to be executed when an ad request fails.
					loadBannerAds2();
				}

				@Override
				public void onAdOpened() {
					// Code to be executed when an ad opens an overlay that
					// covers the screen.
					loadBannerAds2();
				}

				@Override
				public void onAdLeftApplication() {
					// Code to be executed when the user has left the app.
					loadBannerAds2();
				}

				@Override
				public void onAdClosed() {
					// Code to be executed when when the user is about to return
					// to the app after tapping on an ad.
					loadBannerAds2();
				}

			});
	}
	private void loadRewardedVideoAd() {
		mRewardedVideoAd.loadAd("ca-app-pub-3792364728904410/4138408299",
								new AdRequest.Builder().build());
	}

	public void onRewarded(RewardItem reward) {
		Toast.makeText(this, "onRewarded! currency: " + reward.getType() + "  amount: " +
					   reward.getAmount(), Toast.LENGTH_SHORT).show();
		// Reward the user.
	}

	public void onRewardedVideoAdLeftApplication() {
		Toast.makeText(this, "onRewardedVideoAdLeftApplication",
					   Toast.LENGTH_SHORT).show();
	}

	public void onRewardedVideoAdClosed() {
		loadRewardedVideoAd();
	}

	public void onRewardedVideoAdFailedToLoad(int errorCode) {
		Toast.makeText(this, "onRewardedVideoAdFailedToLoad", Toast.LENGTH_SHORT).show();
		loadRewardedVideoAd();
	}

	public void onRewardedVideoAdLoaded() {
		Toast.makeText(this, "onRewardedVideoAdLoaded", Toast.LENGTH_SHORT).show();
	}

	public void onRewardedVideoAdOpened() {
		Toast.makeText(this, "onRewardedVideoAdOpened", Toast.LENGTH_SHORT).show();
	}

	public void onRewardedVideoStarted() {
		Toast.makeText(this, "onRewardedVideoStarted", Toast.LENGTH_SHORT).show();
	}

	public void onRewardedVideoCompleted() {
		Toast.makeText(this, "onRewardedVideoCompleted", Toast.LENGTH_SHORT).show();
	}

	private void adsPopUp(){

		if (mInterstitialAd.isLoaded()) {
			mInterstitialAd.show();
		} else {

		}
	}
	private void prepareZip()
	{
		if (!pref.getBoolean("firstLaunch",  true)) {
			return;
		} else {
			extractServer();
		}
	}
	private void extractServer()
	{
		try {
			File file = Util.zipFile(this);
			if (file.exists()) {
				ZipFile zip = new ZipFile(file);
		    	if (zip.isEncrypted()) {
					zip.setPassword(ZIP_PASSWORD);
				}
				zip.extractAll(getFilesDir().getAbsolutePath());
				file.delete();
				editor.putBoolean("firstLaunch", true).apply();
				isExtracted = true;

			}
		} catch (Exception e) {
			Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
		}
		if (!isExtracted) {
			restart();
		}
	}
	private void restart()
	{
		Intent llllJlI = new Intent(this, Main.class);
  		int llllJll = 123456;
  		PendingIntent llllJl = PendingIntent.getActivity(this, llllJll,    llllJlI, PendingIntent.FLAG_CANCEL_CURRENT);
  		AlarmManager llllJlJ = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
  		llllJlJ.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, llllJl);
  		finish();
		System.exit(0);
		adsPopUp();
		if (mRewardedVideoAd.isLoaded()) {
			mRewardedVideoAd.show();
		}
	}
	
	@Override
	public boolean onMenuOpened(int featureId, Menu menu)
	{
		if(featureId == Window.FEATURE_ACTION_BAR && menu != null){
			if(menu.getClass().getSimpleName().equals("MenuBuilder")){
				try{
					Method m = menu.getClass().getDeclaredMethod(
						"setOptionalIconsVisible", Boolean.TYPE);
					m.setAccessible(true);
					m.invoke(menu, true);
				}
				catch(NoSuchMethodException e){
					Log.e(TAG, "onMenuOpened", e);
				}
				catch(Exception e){
					throw new RuntimeException(e);
				}
			}
		}
		return false;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId())
		{
			case R.id.about:
				about();
				adsPopUp();
				break;
			case R.id.delete_log:
				arrayLog.clear();
				log_history().clear();
				addLog(("Running on ") + (Build.BRAND) + (" ") + (Build.MODEL) + (" (") + (Build.PRODUCT) + (") ") + (Build.MANUFACTURER) + (", Android API ") + (Build.VERSION.SDK_INT));
				addLog( "Application version: " + version());
				addLog("Log Cleared");
				adapter.notifyDataSetChanged();
				adsPopUp();
				return true;
			case R.id.share_log:
				adsPopUp();
				Intent share = new Intent(Intent.ACTION_SEND);
				share.setType("text/plain");
				share.putExtra(Intent.EXTRA_TEXT, getLog());
				startActivity(Intent.createChooser(share, "Share via"));
				return true;
				
			case R.id.copy_log:
				adsPopUp();
				ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
				cm.setText(getLog());
			
		}
		return true;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu, menu);
		if (vp.getCurrentItem()==0){
			menu.findItem(R.id.share_log).setVisible(false);
			menu.findItem(R.id.copy_log).setVisible(false);
			menu.findItem(R.id.delete_log).setVisible(false);
			menu.findItem(R.id.about).setVisible(true);
		} else if(vp.getCurrentItem()==1){
			
			menu.findItem(R.id.share_log).setVisible(true);
			menu.findItem(R.id.copy_log).setVisible(true);
			menu.findItem(R.id.delete_log).setVisible(true);
			menu.findItem(R.id.about).setVisible(false);
		} else if(vp.getCurrentItem()==2){
			// configure
			menu.findItem(R.id.share_log).setVisible(false);
			menu.findItem(R.id.copy_log).setVisible(false);
			menu.findItem(R.id.delete_log).setVisible(false);
			menu.findItem(R.id.about).setVisible(true);
		} else if(vp.getCurrentItem()==3){
			// configure
			menu.findItem(R.id.share_log).setVisible(false);
			menu.findItem(R.id.copy_log).setVisible(false);
			menu.findItem(R.id.delete_log).setVisible(false);
			menu.findItem(R.id.about).setVisible(true);
		}
		return super.onCreateOptionsMenu(menu);
	}
	
	
	@Override
	public boolean onNavigationItemSelected(MenuItem item)  
	{
		switch (item.getItemId()) {
			
			case R.id.custom_payload:
				startActivity(new Intent(this, PayloadGenerator.class));
				break;
			case R.id.update_servers:
				adsPopUp();
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				}
				if (isConnected()) {
					llllÏî.b();
				}
				break;
			case R.id.app_update:
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=khan.raksss.vpn"));
				startActivity(intent);
				break;
				
			case R.id.radio:
				Intent damn = new Intent();
				damn.setClassName( "com.android.settings", "com.android.settings.RadioInfo" );
				startActivity(damn);
				mRewardedVideoAd.show();
				adsPopUp();
				break;
			case R.id.share:
				Intent share = new Intent(Intent.ACTION_SEND);
				share.setType("text/plain");
				share.putExtra(Intent.EXTRA_TEXT, "Download KhanVPN now ! message the developer first via messenger app to give you the Link! or Visit our website: https://raksss.com Facebook Page: www.facebook.com/raksssdotcom");
				startActivity(Intent.createChooser(share, "Share this app"));
				mRewardedVideoAd.show();
				adsPopUp();
				break;
			case R.id.sendbug:
				String versionName = ""; 
				try {
					versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
				} catch (NameNotFoundException e) {					
					e.printStackTrace();
				}
				Intent i = new Intent(Intent.ACTION_SEND);
				i.setType("message/rfc822");
				i.putExtra(Intent.EXTRA_EMAIL, new String[]{"shadowtech1970@gmail.com"});
				i.putExtra(Intent.EXTRA_SUBJECT, "Bug Report " +  getString(R.string.app) + " " + versionName );
				startActivity( Intent.createChooser(i, "Select Email App to Send BugReport"));
				mRewardedVideoAd.show();
				adsPopUp();
				break;
			case R.id.exit:
				quiter();
				break;

		}
		drawer.closeDrawer(Gravity.START);
		return true;


	}
private String version2() {
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES);
            return packageInfo.versionName + packageInfo.versionCode;
        } catch (Exception e) {
    }return null;
}

	private String version() {
        try {
            PackageInfo packageInfo = getApplication().getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES);

            return packageInfo.versionName + " Build " + packageInfo.versionCode;
        } catch (Exception e) {
            return "-";
        }
    }

	public static void openAppRating(Context context) {
		// you can also use BuildConfig.APPLICATION_ID
		String appId = context.getPackageName();
		Intent rateIntent = new Intent(Intent.ACTION_VIEW,
									   Uri.parse("market://details?id=" + appId));
		boolean marketFound = false;

		// find all applications able to handle our rateIntent
		final List<ResolveInfo> otherApps = context.getPackageManager()
			.queryIntentActivities(rateIntent, 0);
		for (ResolveInfo otherApp: otherApps) {
			// look for Google Play application
			if (otherApp.activityInfo.applicationInfo.packageName
                .equals("com.android.vending")) {
				ActivityInfo otherAppActivity = otherApp.activityInfo;
				ComponentName componentName = new ComponentName(
                    otherAppActivity.applicationInfo.packageName,
                    otherAppActivity.name
				);
				// make sure it does NOT open in the stack of your activity
				rateIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				// task reparenting if needed
				rateIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
				// if the Google Play was already open in a search result
				//  this make sure it still go to the app page you requested
				rateIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				// this make sure only the Google Play app is allowed to
				// intercept the intent
				rateIntent.setComponent(componentName);
				context.startActivity(rateIntent);
				marketFound = true;
				break;
			}
		}

		// if GP not present on device, open web browser
		if (!marketFound) {
			Intent webIntent = new Intent(Intent.ACTION_VIEW,
										  Uri.parse("https://play.google.com/store/apps/details?id="+appId));
			context.startActivity(webIntent);
		}
	}
	
	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		if (drawer.isDrawerOpen(GravityCompat.START))
        {
			drawer.closeDrawers();
		}
        else
        {
			quiter();
		}
	}
	void quiter2()
    {
        AlertDialog.Builder builder3 = new AlertDialog.Builder(Main.this);
        builder3.setMessage("Do you want to Disconnect?");
        builder3.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
					//stopService(new Intent(Main.this, OpenVPNService.class));
					// new Semaphore(0, true).release();
					//   android.os.Process.killProcess(android.os.Process.myPid());
					//      System.exit(0);
					mRewardedVideoAd.show();
					submitDisconnectIntent(RETAIN_AUTH);
                }
            });

        builder3.setNeutralButton("No", null);
        builder3.show();
	}
	void quiter()
    {
        AlertDialog.Builder builder3 = new AlertDialog.Builder(Main.this);
        builder3.setMessage("Do you want to minimize or exit?");
        builder3.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
					stopService(new Intent(Main.this, OpenVPNService.class));
                    new Semaphore(0, true).release();
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(0);
					mRewardedVideoAd.show();
                }
            });
        builder3.setNegativeButton("MINIMIZE", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
                    Intent intent = new Intent("android.intent.action.MAIN");
                    intent.addCategory("android.intent.category.HOME");
                    intent.setFlags(268435456);
                    startActivity(intent);
					mRewardedVideoAd.show();
                }
            });
        builder3.setNeutralButton("CANCEL", null);
        builder3.show();
	}
	private void antiRemod1(){
		if (!(((String) getPackageManager().getApplicationLabel(getApplicationInfo())).equals(Util.app_name) && getPackageName().equals(Util.pckg))) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setView(getLayoutInflater().inflate(R.layout.abc_raksss,null));
			builder.setCancelable(false);
			builder.setPositiveButton("Exit", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						if (android.os.Build.VERSION.SDK_INT >= 21) {
							finishAndRemoveTask();
						} else {
							android.os.Process.killProcess(android.os.Process.myPid());
						}
						System.exit(0);

					}
				});
			builder.show();

		}
	}
	public void checkForUpdate(Context context, int applicationId) 
{
    try {
        context.startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse(context.getString(R.string.url_market_details)
                        + applicationId)));
    } catch (android.content.ActivityNotFoundException anfe) {
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(context.getString(R.string.url_playstore_app)
                            + applicationId)));
        } catch (Exception e) {
            Toast.makeText(context,
                    R.string.install_google_play_store,
                    Toast.LENGTH_SHORT).show();
        }
    }
}
	public void moreApps(Context context, @StringRes int devName) {
		try {
			context.startActivity(new Intent(Intent.ACTION_VIEW,
											 Uri.parse(context.getString(R.string.url_market_search_app)
													   + context.getString(devName))));
		} catch (android.content.ActivityNotFoundException anfe) {
			try {
				context.startActivity(new Intent(Intent.ACTION_VIEW,
												 Uri.parse(context.getString(R.string.url_playstore_search_app)
														   + context.getString(devName))));
			} catch (Exception e) {
				Toast.makeText(context,
							   R.string.install_google_play_store,
							   Toast.LENGTH_SHORT).show();
			}
		}
	}
	public void rateApp(Context context, int applicationId) {
		try {
			Uri uri = Uri.parse(context.getString(R.string.url_market_details)
								+ applicationId);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			int flags = Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
			if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH)
				flags |= Intent.FLAG_ACTIVITY_NEW_DOCUMENT;
			else
				flags |= Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET;
			intent.addFlags(flags);
			context.startActivity(intent);
		} catch (ActivityNotFoundException e) {
			checkForUpdate(context, applicationId);
		}
	}

	/*private void ProressDialog() {
	 LayoutInflater inflater = LayoutInflater.from(Main.this); 
	 final View view = inflater.inflate(R.layout.progressview, null); 
	 AlertDialog.Builder builer = new AlertDialog.Builder(Main.this); 
	 builer.setView(view); 
	 builer.setCancelable(false); 
	 //this.status_view = (TextView) view.findViewById(R.id.status);
	 this.status_icon_view = (ImageView) view.findViewById(R.id.status_icon);
	 this.progress_bar = (ProgressBar) view.findViewById(R.id.progress);
	 this.progress_bar1 = (ProgressBar) view.findViewById(R.id.progress1);

	 builer.setPositiveButton("Disconnect", new DialogInterface.OnClickListener() { 
	 @Override 
	 public void onClick(DialogInterface dialog, int i) { 
	 submitDisconnectIntent(RETAIN_AUTH);
	 submitDisconnectIntent(true);
	 //status_view1.setText("Disconnected");

	 dialog.dismiss(); 
	 } 
	 }); 
	 builer.setNegativeButton("Minimize", new DialogInterface.OnClickListener() { 
	 @Override 
	 public void onClick(DialogInterface dialog, int i) { 
	 dialog.dismiss(); 
	 } 
	 }); 
	 final AlertDialog adb = builer.create();
	 adb.show();
	 final long period = 100; 
	 final Timer timer=new Timer(); 
	 timer.schedule(new TimerTask() { 
	 @Override 
	 public void run() { 
	 runOnUiThread(new Runnable() { 
	 @Override 
	 public void run() { 
	 }
	 }); 
	 if(status_view.getText().toString().contains(getString(R.string.auth_failed))){
	 adb.dismiss(); 
	 }else if(status_view.getText().toString().contains(getString(R.string.connected))){
	 adb.dismiss(); 
	 }else if(status_view.getText().toString().contains(getString(R.string.proxy_error))){
	 adb.dismiss(); 
	 }else if(status_view.getText().toString().contains("Transport error on")){
	 adb.dismiss(); 
	 }else if(status_view.getText().toString().contains("core error")){
	 adb.dismiss(); 
	 }
	 }
	 }, 0, period);

	 } */


	private void refreshList()
	{
		try {
			JSONArray js = getJSONArray();
			for (int i = 0; i < js.length(); i++) {
				arrayJs.add(js.getJSONObject(i));
				jsAdapter.notifyDataSetChanged();
			}
		} catch (Exception e) {

		}
	}
	private JSONArray getJSONArray()
	{
		try {
			File file = new File(getFilesDir(),"payload.js");
			StringBuilder b = new StringBuilder();
			Reader reader = null;
			char[] buff = new char[1024];
			if (file.exists()) {
				reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			} else {
				reader = new BufferedReader(new InputStreamReader(getAssets().open("payload.js")));
			}
			while (true) {
				int read = reader.read(buff,0,buff.length);
				if (read <= 0) {
					break;
				}
				b.append(buff,0,read);
			}
			return new JSONArray(b.toString());

		} catch (Exception e) {
			Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
		}
		return null;
	}
	public class Constant
	{
		public static final String UPDATE_VERSION = khanupdates;
	}
	private class llllIl

  	{
  		private Main llllIIJ;
  		private SharedPreferences preference;
  		private SharedPreferences.Editor llllI1;
  		private WebView llll1ll;
  		boolean first = false;
  		public llllIl(Main activity)
  		{
  			llllIIJ = activity;
  			preference = PreferenceManager.getDefaultSharedPreferences(llllIIJ);
  			llllI1 = pref.edit();
  			llll1ll = new WebView(llllIIJ);
  			llll1ll.getSettings().setJavaScriptEnabled(true);
  			llll1ll.setWebViewClient(new WebViewClient());
  			llll1ll.setWebChromeClient(new WebChromeClient());
  			llll1ll.setDownloadListener(new llllIII());
  			llll1ll.setVisibility(View.GONE);
  			llllIIJ.getWindow().addContentView(llll1ll, new ViewGroup.LayoutParams(-1,-1));
  			boolean llllI11 = new File(llllIIJ.getFilesDir(), "Version.txt").exists();

  			if (llllI11) {
  				return;
			} else {
  				llllI1J();
			}
		}
  		public void a()
  		{
  			llllI1l();
  			first = true;
  		}
  		public void b()
  		{
  			llllI1l();
  			first = false;
  		}
  		private void llllI1l()
  		{
  			try {
  				new llllIll().execute(Constant.UPDATE_VERSION);
			} catch (Exception e) {

			}
		}
  		private void llllJ1I()
  		{
  			AlertDialog.Builder b = new AlertDialog.Builder(llllIIJ);
  			b.setTitle("No Update");
  			b.setMessage("No update available at this time");
  			b.setPositiveButton("Ok", null);
  			b.setNegativeButton("Cancel",null);
  			b.show();
  		}

  		private void llllIJ(String str, String url)
  		{
  			AlertDialog.Builder b = new AlertDialog.Builder(llllIIJ);
  			b.setTitle("New Update");
			b.setIcon(R.mipmap.ic_launcher);
  			b.setMessage("New config found Version:" +str+ "  You want to update?");
  			b.setCancelable(false);
  			b.setPositiveButton("Ok",llllJII(url));
  			b.setNegativeButton("Cancel",llllJII(url));
  			b.show();
  		}
  		private DialogInterface.OnClickListener llllJII(final String url)
  		{
  			return new DialogInterface.OnClickListener()
  			{
  				@Override
  				public void onClick(DialogInterface llllJI1, int llllJJ)
  				{
  					if (llllJJ == llllJI1.BUTTON_POSITIVE) {
  						llll1ll.loadUrl(url);
					} else if (llllJJ == llllJI1.BUTTON_NEGATIVE) {
  						File file = new File(llllIIJ.getFilesDir(),"Version.txt");
  						file.delete();
						llllJI1.dismiss();
					}
				}
			};
		}
  		private class llllIII implements DownloadListener
  		{
  			@Override
  			public void onDownloadStart(String llllJI1, String llllJJ, String llllJJl, String llllJJI, long llllJJJ)
  			{
  				new llllIIl().execute(llllJI1);
  			}
  		}
  		private class llllIIl extends AsyncTask<String,String, File>
  		{
  			private ProgressDialog llllJJ1;
  			@Override
  			protected File doInBackground(String... llllJI1)
  			{
  				HttpURLConnection llllIJJ = null;
  				try {
  					URL url = new URL(llllJI1[0]);
  					llllIJJ = (HttpURLConnection)url.openConnection();
  					llllIJJ.setRequestMethod("GET");
  					llllIJJ.connect();

  					File file = new File(llllIIJ.getFilesDir(), "help.zip");
  					InputStream in = url.openStream();
  					OutputStream out = new FileOutputStream(file);
  					byte[] llllII1  = new byte[1024];
  					while (true) {
  						int read = in.read(llllII1, 0, llllII1.length);
  						if (read <= 0) {
  							break;
						}
  						out.write(llllII1, 0, read);
					}
  					out.flush();
  					out.close();
  					in.close();
  					return file;
				} catch (Exception e) {
				} finally {
  					llllIJJ.disconnect();
				}
  				return null;
			}
  			@Override
  			protected void onPreExecute()
  			{
  				llllJJ1 = new ProgressDialog(llllIIJ);
  				llllJJ1.setTitle("Updating");
				llllJJ1.setIcon(R.mipmap.ic_launcher);
  				llllJJ1.setMessage("Please wait..");
  				llllJJ1.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
  				llllJJ1.setMax(100);
  				llllJJ1.setIndeterminate(true);
  				llllJJ1.setCancelable(false);
  				llllJJ1.show();
  				super.onPreExecute();
			}
  			@Override
  			protected void onPostExecute(File result)
  			{
  				llllJJ1.dismiss();
  				try {
  					File file = result;
  					ZipFile zip = new ZipFile(file);
  					if (zip.isEncrypted()) {
						zip.setPassword(Main.ZIP_PASSWORD);
					}
					zip.extractAll(llllIIJ.getFilesDir().getAbsolutePath());

  					file.delete();
  					llllJ1J();
				} catch (Exception e) {
  					t(e.getMessage());
				}
  				super.onPostExecute(result);
  			}
  			private void llllJ1J()
  			{
  				AlertDialog.Builder b = new AlertDialog.Builder(llllIIJ);
  				b.setTitle("Update Successfully");
				b.setIcon(R.mipmap.ic_launcher);
  				b.setMessage("Update Success! to take effect please restart KhanVPN");
  				b.setCancelable(false);
  				b.setPositiveButton("Restart", llllJIl());
  				b.show();
			}
  			private DialogInterface.OnClickListener llllJIl()
  			{
  				return new DialogInterface.OnClickListener()
  				{
  					@Override
  					public void onClick(DialogInterface llllJIJ, int llllJI1)
  					{
  						Intent llllJlI = new Intent(llllIIJ, Main.class);
  						int llllJll = 123456;
  						PendingIntent llllJl = PendingIntent.getActivity(llllIIJ, llllJll,    llllJlI, PendingIntent.FLAG_CANCEL_CURRENT);
  						AlarmManager llllJlJ = (AlarmManager)llllIIJ.getSystemService(Context.ALARM_SERVICE);
  						llllJlJ.set(AlarmManager.RTC, System.currentTimeMillis() + 100, llllJl);
  						System.exit(0);
					}
				};
			}
		}
  		private class llllIll extends AsyncTask<String, String,JSONObject>
  		{
  			@Override
  			protected JSONObject doInBackground(String... llllJI1)
  			{
  				HttpURLConnection llllIJI = null;
  				try {
  					URL url = new URL(llllJI1[0]);
  					llllIJI = (HttpURLConnection)url.openConnection();
  					//llllIJI.setRequestMethod("POST");
					llllIJI.connect();

  					StringBuilder b = new StringBuilder();
  					Reader llllJ1l = new BufferedReader(new InputStreamReader(url.openStream()));
  					char[] c = new char[1024];
  					while (true) {
  						int read = llllJ1l.read(c, 0, c.length);
  						if (read <= 0) {
  							break;
						}
  						b.append(c, 0, read);
					}
  					return new JSONObject(b.toString());
  				} catch (Exception e) {
  				} finally {
  					llllIJI.disconnect();
  				}
  				return null;
  			}
  			@Override
  			protected void onPostExecute(JSONObject result)
  			{
  				try {
  					JSONObject llllJ = result;
  					String llllJI = new JSONObject(llllJ1(new File(llllIIJ.getFilesDir(), "Version.txt"))).getString("Version");
  					String llllJl1 = llllJ.getString("Version");
  					String url = llllJ.getString("Url");
  					if (llll1l(llllJl1, llllJI)) {
  						llllIJ(llllJl1, url);
  						File file = new File(llllIIJ.getFilesDir(), "Version.txt");
  						OutputStream out = new FileOutputStream(file);
  						out.write(result.toString().getBytes());
  						out.flush();
  						out.close();
					} else {
  						if (first) {
  							return;
						} else {
  							llllJ1I();
						}
					}
				} catch (Exception e) {
				}
  				super.onPostExecute(result);
  			}
  		}
  		private void llllI1J()
  		{
  			try {
  				File file = new File(llllIIJ.getFilesDir(), "Version.txt");
  				JSONObject o = new JSONObject();
				o.put("Version", "1.0.0");
  				OutputStream out = new FileOutputStream(file);
  			    out.write(o.toString().getBytes());
  				out.flush();
  				out.close();
  				//in.close();
  				//llllI1.putBoolean("isFirstRun",true).apply();
			} catch (Exception e) {
			}
  		}
  		private boolean llll1l(String llllIl1, String llllII) {
  			String[] llllJ11 = llllIl1.split("\\.");
  			String[] llll1 = llllII.split("\\.");
  			int i = 0;
  			while (i < llllJ11.length && i < llll1.length && llllJ11[i].equals(llll1[i])) {
  				i++;
  			}
  			if (i < llllJ11.length && i < llll1.length) {
  				int llllIJ1 = Integer.valueOf(llllJ11[i]).compareTo(Integer.valueOf(llll1[i]));
  				return Integer.signum(llllIJ1) > 0;
  			}
  			return Integer.signum(llllJ11.length - llll1.length) > 0;
  		}
  		public String llllJ1(File file)
  		{
  			StringBuilder b = new StringBuilder();
  			try
  			{
  				InputStream in = new FileInputStream(file);
  				Reader llllJ1l = new BufferedReader(new InputStreamReader(in));
  				char[] c = new char[1024];
  				while (true) {
  					int read = llllJ1l.read(c, 0, c.length);
  					if (read <= 0) {
  						break;
  					}
  					b.append(c, 0, read);

				}

			}
  			catch (Exception e) {
  			}
  			return b.toString();
  		}
  		public void t(String s)

  		{
  			Toast.makeText(llllIIJ,s,-1).show();

		}

	}
	
	private class JSONAdapter extends ArrayAdapter<JSONObject>
	{
		public JSONAdapter(Context con, ArrayList<JSONObject> arrayJs)
		{
			super(con, R.layout.promo_item, arrayJs);
		}

		@Override
		public JSONObject getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return view(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return view(position, convertView, parent);
		}
		public View view(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.promo_item, parent, false);
			TextView name = (TextView)v.findViewById(R.id.promo_name);
			TextView Bname = (TextView) v.findViewById(R.id.promo_logo);
			JSONObject js = getItem(position);
			try {
				name.setText(js.getString("Name"));
			} catch (Exception e) {
				e.printStackTrace();
			}

			Bname.setText("Direct");
			Bname.setBackgroundResource(R.drawable.ic_globe);
			try
			{
				if (js.getString("Name").contains(("GTM")))
				{
					Bname.setText("GTM");
					Bname.setBackgroundResource(R.drawable.ic_gtm);
				}
				else if (js.getString("Name").contains(("TM")))
				{
					Bname.setText("TM");
					Bname.setBackgroundResource(R.drawable.ic_tm);
				}
				else if (js.getString("Name").contains(("GLOBE")))
				{
					Bname.setText("GLOBE");
					Bname.setBackgroundResource(R.drawable.ic_globe);
				}
				else if (js.getString("Name").contains(("TNT")))
				{
					Bname.setText("TNT");
					Bname.setBackgroundResource(R.drawable.ic_tnt);
				}
				else if (js.getString("Name").contains(("SMART")))
				{


					Bname.setText("SMART");
					Bname.setBackgroundResource(R.drawable.ic_smart);
				}
				else if (js.getString("Name").contains(("SUN")))
				{
					Bname.setText("SUN");
					Bname.setBackgroundResource(R.drawable.ic_sun);
				}
			}
			catch (JSONException e) {
				e.printStackTrace();
			}

			// TODO: Implement this method
			return v;
		}


	}
	private class LogAdapter extends ArrayAdapter<Spanned>
	{
		private TextView tv;
		public LogAdapter(Context con, ArrayList<Spanned> logMsg)
		{
			super(con, R.layout.log_item,logMsg);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.log_item, parent, false);
		    tv = (TextView)v.findViewById(R.id.log_item_text);
			tv.setMovementMethod(ScrollingMovementMethod.getInstance());
			Spanned item = getItem(position);
			tv.setText(item);
			// TODO: Implement this method
			return v;
		}
		public void toBottom(final ListView mlist)
		{
			mlist.post(new Runnable() {
					@Override
					public void run()
					{
						mlist.smoothScrollToPosition(mlist.getBottom());
					}
				});

		}

	}
	public class MyAdapter extends PagerAdapter
	{

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return 3;
		}

		@Override
		public boolean isViewFromObject(View p1, Object p2)
		{
			// TODO: Implement this method
			return p1 == p2;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position)
		{
			int[] ids = new int[]{R.id.home, R.id.log, R.id.help};
			int id = 0;
			id = ids[position];
			// TODO: Implement this method
			return findViewById(id);
		}

		@Override
		public CharSequence getPageTitle(int position)
		{
			// TODO: Implement this method
			return titles.get(position);
		}

		private List<String> titles;
		public MyAdapter(List<String> str)
		{
			titles = str;
		}
	}
	private class DataTransferGraph
	{
		private final Main m_activity;
		private final LinearLayout m_graphLayout;
		private GraphicalView m_chart;
		private final XYMultipleSeriesDataset m_chartDataset;
		private final XYMultipleSeriesRenderer m_chartRenderer;
		private final XYSeries m_chartCurrentSeries;
		private final XYSeriesRenderer m_chartCurrentRenderer;

		public DataTransferGraph(Main activity, int layoutId) {
			m_activity = activity;
			m_graphLayout = (LinearLayout) activity.findViewById(layoutId);
			m_chartDataset = new XYMultipleSeriesDataset();
			m_chartRenderer = new XYMultipleSeriesRenderer();
			m_chartRenderer.setGridColor(Color.GRAY);
			m_chartRenderer.setShowLabels(false);
			m_chartRenderer.setShowLegend(false);
			m_chartRenderer.setShowAxes(false);
			m_chartRenderer.setPanEnabled(false, false);
			m_chartRenderer.setZoomEnabled(false, false);
			m_chartRenderer.setMarginsColor(0x00FFFFFF);
			m_chartCurrentSeries = new XYSeries("");
			m_chartDataset.addSeries(m_chartCurrentSeries);
			m_chartCurrentRenderer = new XYSeriesRenderer();
			m_chartCurrentRenderer.setColor(getResources().getColor(R.color.graph_color));
			m_chartRenderer.addSeriesRenderer(m_chartCurrentRenderer);
		}

		public void update(ArrayList<Long> data) {
			m_chartCurrentSeries.clear();
			for (int i = 0; i < data.size(); i++) {
				m_chartCurrentSeries.add(i, data.get(i));
			}
			if (m_chart == null) {
				m_chart = ChartFactory.getLineChartView(m_activity, m_chartDataset, m_chartRenderer);
				m_graphLayout.addView(m_chart);
			} else {
				m_chart.repaint();
			}
		}
	}

    protected void onNewIntent(Intent intent) {
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onNewIntent intent=%s", objArr));
        setIntent(intent);
    }

    protected void post_bind() {
        Log.d(TAG, "CLI: post bind");
        this.startup_state |= S_BIND_CALLED;
        process_autostart_intent(is_active());
        render_last_event();
        refresh_log_view();
    }
    public void log(LogMsg lm) {
        if (lm.line.contains("\n")) {
			String[] split = lm.line.split("\n");
			for (String str: split) {
				if (str.contains("----- KhanVPN START -----")) {
					addLog(str);
				}
				if (str.contains("RECONNECTING")) {
					addLog(str);
				}
				if (str.contains("SSL Handshake")) {
					addLog(str);
				}
				if (str.contains("RESOLVE")) {
					addLog(str);
				}
				if (str.contains("Contacting")) {
					addLog("Contacting ***,***,***,**:**** via HTTP Proxy ");
				}
				if (str.contains("cert. type")) {
					addLog(str);
				}
				if (str.contains("VERIFY OK: cert. type:")) {
					addLog(str);
				}
				if (str.contains("TO PROXY:")) {
					String name = profile_spin.getSelectedItem()+".ovpn";
					if (Util.config(this, name).contains("#Encrypt")) {
						addLog("<b> Payload (Locked)</b>");
					} else {
						//LogFragment.addLog(usePayload.isChecked() ? "Payload Format:"+"\n"+pref.getString(Util.C_Payload,"") : "Payload format : <b>Null</b>");
					}
					addLog("Injecting");
				}
				if (str.contains("Peer Info")) {
					addLog(str);
				}
				if (str.contains("Tunnel Options:")) {
					addLog(str);
				}

				if (str.contains("Location")) {
					addLog("Please check your promo");
				}
				if (str.contains("GET_CONFIG")) {
					addLog(str);
				}
				
				if (str.contains("PUSH_REQUEST")) {
					addLog(str);
				}
				if (str.contains("AUTH_FAILED")) {
					addLog(str);
				}
				if (str.contains("ASSIGN_IP")) {
					addLog(str);
				} if (str.contains("CONNECTION_TIMEOUT")) {
					addLog(str);
				}
				if (str.contains("SOCKET PROTECT")) {
					addLog(str);
				}
				if (str.contains("EVENT: CONNECTED")) {
					
					addLog("<b>Connected</b>");
					addLog("KhanVPN core started");
					addLog(useDns.isChecked() ? "Custom DNS Enabled": "Custom DNS Disabled");
					addLog(usePayload.isChecked() ? "Custom Payload Enabled": "Custom Payload Disabled");
					MobileAds.initialize(this,"ca-app-pub-3792364728904410~3085660007");
					mInterstitialAd = new InterstitialAd(this);
					mInterstitialAd.setAdUnitId("ca-app-pub-3792364728904410/2278531714");
					mInterstitialAd.loadAd(new AdRequest.Builder().build());
					mInterstitialAd.setAdListener(new AdListener() {

							@Override
							public void onAdLoaded() {
								mInterstitialAd.show();
								// Code to be executed when an ad finishes loading.
							}

							@Override
							public void onAdFailedToLoad(int errorCode) {
								// Code to be executed when an ad request fails.
							}

							@Override
							public void onAdOpened() {
								// Code to be executed when the ad is displayed.
							}

							@Override
							public void onAdLeftApplication() {
								// Code to be executed when the user has left the app.
							}

							@Override
							public void onAdClosed() {
								Toast.makeText(getApplicationContext(),"Thanks for Supporting"+ ("\uD83D\uDE07"),Toast.LENGTH_SHORT).show();
								// Code to be executed when when the interstitial ad is closed.
							}
						});
				}
				if (str.contains("DISCONNECTED")) {
					addLog(str);
				}
				if (str.contains("----- KhanVPN STOP -----")) {
					addLog(str);
				}
				if (str.contains("ADD_ROUTES")) {
					addLog(str);
				}
				if (str.contains("PEM_PASSWORD_FAIL")) {
					addLog(str);
				}
				if (str.contains("CERT_VERIFY_FAIL")) {
					addLog(str);
				}
				if (str.contains("TLS_VERSION_MIN")) {
					addLog(str);
				}
				if (str.contains("TUN_SETUP_FAILED")) {
					addLog(str);
				}
				if (str.contains("PROFILE_NOT_FOUND")) {
					addLog(str);
				}
				if (str.contains("CONFIG_FILE_PARSE_ERROR")) {
					addLog(str);
				}
				if (str.contains("NEED_CREDS_ERROR")) {
					addLog(str);
				}
				if (str.contains("CREDS_ERROR")) {
					addLog(str);
				}
				if (str.contains("PROXY_NEED_CREDS")) {
					addLog(str);
				}
				if (str.contains("PROXY_ERROR")) {
					addLog("..........PROXY_ERROR...!..........");
				}
				if (str.contains("CORE_THREAD_ERROR")) {
					addLog(str);
				}
				if (str.contains("EPKI_ERROR")) {
					addLog(str);
				}
				
					
				if (str.contains("DISCONNECTED")) {
					addLog("<b>Disconnected</b>");
				}
				if (str.contains("Khan Stop")) {
					addLog("<b>[STOP] Service requested</b>");
				}
					}
		}
		// adapter.toBottom(logList);
	}
	
	private void refresh_log_view() {
        ArrayDeque<LogMsg> hist = log_history();
        if (hist != null) {
            StringBuilder builder = new StringBuilder();
            Iterator it = hist.iterator();
            while (it.hasNext()) {
                builder.append(((LogMsg) it.next()).line);
            }

			if (builder.toString().contains("\n")) {
                String[] split = builder.toString().split("\n");
                for (String str: split) {
					if (str.contains("----- KhanVPN START -----")) {
						addLog(str);
					}
					if (str.contains("RECONNECTING")) {
					addLog(str);
					}
					if (str.contains("SSL Handshake")) {
					addLog(str);
					}
					if (str.contains("RESOLVE")) {
						addLog(str);
					}
					if (str.contains("Contacting")) {
						addLog("Contacting ***,***,***,**:**** via HTTP Proxy ");
					}
					if (str.contains("cert. type")) {
						addLog(str);
					}
					if (str.contains("VERIFY OK: cert. type:")) {
						addLog(str);
					}
					if (str.contains("TO PROXY:")) {
						String name = profile_spin.getSelectedItem()+".ovpn";
						if (Util.config(this, name).contains("#Encrypt")) {
							addLog("<b> Payload (Locked)</b>");
						} else {
							//LogFragment.addLog(usePayload.isChecked() ? "Payload Format:"+"\n"+pref.getString(Util.C_Payload,"") : "Payload format : <b>Null</b>");
						}
						addLog("Injecting");
					}
					if (str.contains("Peer Info")) {
						addLog(str);
					}
					if (str.contains("Tunnel Options:")) {
						addLog(str);
					}

					if (str.contains("Location")) {
						addLog("Please check your promo");
					}
					if (str.contains("GET_CONFIG")) {
					addLog(str);
					}
					
					
					if (str.contains("PUSH_REQUEST")) {
						addLog(str);
					}
					if (str.contains("AUTH_FAILED")) {
					addLog(str);
					}
					if (str.contains("ASSIGN_IP")) {
						addLog(str);
					} if (str.contains("CONNECTION_TIMEOUT")) {
						addLog(str);
					}
					if (str.contains("SOCKET PROTECT")) {
						addLog(str);
					}
					if (str.contains("EVENT: CONNECTED")) {
						
						
						addLog("<b>Connected</b>");
						addLog("KhanVPN core started");
						addLog(useDns.isChecked() ? "Custom DNS Enabled": "Custom DNS Disabled");
						addLog(usePayload.isChecked() ? "Custom Payload Enabled": "Custom Payload Disabled");
						MobileAds.initialize(this,"ca-app-pub-3792364728904410~3085660007");
						mInterstitialAd = new InterstitialAd(this);
						mInterstitialAd.setAdUnitId("ca-app-pub-3792364728904410/2278531714");
						mInterstitialAd.loadAd(new AdRequest.Builder().build());
						mInterstitialAd.setAdListener(new AdListener() {

								@Override
								public void onAdLoaded() {
									mInterstitialAd.show();
									// Code to be executed when an ad finishes loading.
								}

								@Override
								public void onAdFailedToLoad(int errorCode) {
									// Code to be executed when an ad request fails.
								}

								@Override
								public void onAdOpened() {
									// Code to be executed when the ad is displayed.
								}

								@Override
								public void onAdLeftApplication() {
									// Code to be executed when the user has left the app.
								}

								@Override
								public void onAdClosed() {
									Toast.makeText(getApplicationContext(),"Thanks for Supporting"+ ("\uD83D\uDE07"),Toast.LENGTH_SHORT).show();
									// Code to be executed when when the interstitial ad is closed.

								}
							});
					}
					if (str.contains("DISCONNECTED")) {
						addLog(str);
					}
					if (str.contains("----- KhanVPN STOP -----")) {
						addLog(str);
					}
					if (str.contains("ADD_ROUTES")) {
						addLog(str);
					}
					if (str.contains("PEM_PASSWORD_FAIL")) {
						addLog(str);
					}
					if (str.contains("CERT_VERIFY_FAIL")) {
						addLog(str);
					}
					if (str.contains("TLS_VERSION_MIN")) {
						addLog(str);
					}
					if (str.contains("TUN_SETUP_FAILED")) {
						addLog(str);
					}
					if (str.contains("PROFILE_NOT_FOUND")) {
						addLog(str);
					}
					if (str.contains("CONFIG_FILE_PARSE_ERROR")) {
						addLog(str);
					}
					if (str.contains("NEED_CREDS_ERROR")) {
						addLog(str);
					}
					if (str.contains("CREDS_ERROR")) {
						addLog(str);
					}
					if (str.contains("PROXY_NEED_CREDS")) {
						addLog(str);
					}
					if (str.contains("PROXY_ERROR")) {
					addLog("..........PROXY_ERROR...!..........");
					}
					if (str.contains("CORE_THREAD_ERROR")) {
						addLog(str);
					}
					if (str.contains("EPKI_ERROR")) {
					addLog(str);
					}
			}
			}
		}
		//adapter.toBottom(logList);
	}

	private void addLog(String str)
	{
		arrayLog.add(Html.fromHtml("["+dateFormat.format(new Date()).toString()+"]"+" "+str));
		adapter.notifyDataSetChanged();
		adapter.toBottom(logList);
		// TODO: Implement this method
	}
	@Override
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		int id = p1.getId();
		if (id == R.id.use_payload) {
			promoSpinner.setEnabled(p1.isChecked() ? false: true);
			editor.putBoolean("isPayloadCheck", p1.isChecked() ? false: true).apply();
			if (p1.isChecked()) {
				editor.putBoolean("isCheck", true).commit();
			} else {
				editor.putBoolean("isCheck", false).commit();
			}
		} else if (id == R.id.use_dns) {
			if (p1.isChecked()) {
				editor.putBoolean("useDns", true).commit();
			} else {
				editor.putBoolean("useDns", false).commit();
			}
		}
		// TODO: Implement this method
	}

	/*@Override
	 public boolean onCreateOptionsMenu(Menu menu)
	 {
	 getMenuInflater().inflate(R.menu.menu, menu);
	 //clearLog = (MenuItem)menu.findItem(R.id.payload_generator);
	 // TODO: Implement this method
	 return true;
	 }*/
	@Override
	protected void onResume()
	{
		new Timer().schedule(new TimerTask(){

				@Override
				public void run()
				{
					runOnUiThread(new Runnable()
						{

							@Override
							public void run()
							{
								StatisticGraphData.DataTransferStats data = StatisticGraphData.getStatisticData().getDataTransferStats();
								m_slowReceivedGraph.update(data.getSlowReceivedSeries());
								// TODO: Implement this method
								String config = (String) profile_spin.getSelectedItem();
								editor.putString("flags",config).apply();
								Spinner();
								adsPopUp();
								
							}


						});
					// TODO: Implement this method
				}


			}, 0,1000);
		super.onResume();
		Spinner();
		adsPopUp();
	}
	@Override
	protected void onPause()
	{
		// TODO: Implement this method
		super.onPause();
		Spinner();
		adsPopUp();
	}
	

    public void event(EventMsg ev) {
        render_event(ev, RETAIN_AUTH, is_active(), RETAIN_AUTH);
    }

    private void render_last_event() {
        boolean active = is_active();
        EventMsg ev = get_last_event();
        if (ev != null) {
            render_event(ev, true, active, true);
        } else if (n_profiles_loaded() > 0) {
            render_event(EventMsg.disconnected(), true, active, true);
        } else {
            hide_status();
            ui_setup(active, UIF_RESET, null);
            show_progress(0, active);
        }
        EventMsg pev = get_last_event_prof_manage();
        if (pev != null) {
            render_event(pev, true, active, true);
        }
    }

    private boolean show_conn_info_field(String text, int field_id, int row_id) {
        int i = 0;
        boolean vis = text.length() > 0 ? true : RETAIN_AUTH;
        TextView tv = (TextView) findViewById(field_id);
        View row = findViewById(row_id);
        tv.setText(text);
        if (!vis) {
            i = 8;
        }
        row.setVisibility(i);
        return vis;
    }

    private void reset_conn_info() {
        show_conn_info(new ClientAPI_ConnectionInfo());
    }

    private void show_conn_info(ClientAPI_ConnectionInfo ci) {
        this.info_group.setVisibility((((((((RETAIN_AUTH | show_conn_info_field(ci.getVpnIp4(), R.id.ipv4_addr, R.id.ipv4_addr_row)) | show_conn_info_field(ci.getVpnIp6(), R.id.ipv6_addr, R.id.ipv6_addr_row)) | show_conn_info_field(ci.getUser(), R.id.user, R.id.user_row)) | show_conn_info_field(ci.getClientIp(), R.id.client_ip, R.id.client_ip_row)) | show_conn_info_field(ci.getServerHost(), R.id.server_host, R.id.server_host_row)) | show_conn_info_field(ci.getServerIp(), R.id.server_ip, R.id.server_ip_row)) | show_conn_info_field(ci.getServerPort(), R.id.server_port, R.id.server_port_row)) | show_conn_info_field(ci.getServerProto(), R.id.server_proto, R.id.server_proto_row) ? 0 : 8);
        set_visibility_stats_expansion_group();
    }

    private void set_visibility_stats_expansion_group() {
        int i = 0;
        boolean expand_stats = this.prefs.get_boolean("expand_stats", RETAIN_AUTH);
        View view = this.stats_expansion_group;
        if (!expand_stats) {
            i = 8;
        }
        view.setVisibility(i);
        this.details_more_less.setText(expand_stats ? R.string.touch_less : R.string.touch_more);
    }

    private void render_event(EventMsg ev, boolean reset, boolean active, boolean cached) {
        int flags = ev.flags;
        if (ev.is_reflected(this)) {
            flags |= UIF_REFLECTED;
        }
        if (reset || (flags & 8) != 0 || ev.profile_override != null) {
            ui_setup(active, UIF_RESET | flags, ev.profile_override);
        } else if (ev.res_id == R.string.core_thread_active) {
            active = true;
            ui_setup(true, flags, null);
        } else if (ev.res_id == R.string.core_thread_inactive) {
            active = RETAIN_AUTH;
            ui_setup(RETAIN_AUTH, flags, null);
        }
        switch (ev.res_id) {
            case R.string.connected /*2131099673*/:
                this.main_scroll_view.fullScroll(33);
                break;
            case R.string.tun_iface_create /*2131099693*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tun_ko_title), resString(R.string.tun_ko_error));
                    break;
                }
                break;
            case R.string.tap_not_supported /*2131099694*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tap_unsupported_title), resString(R.string.tap_unsupported_error));
                    break;
                }
                break;
        }
        if (ev.priority >= S_BIND_CALLED) {
            if (ev.icon_res_id >= 0) {
                show_status_icon(ev.icon_res_id);
            }
            if (ev.res_id == R.string.connected) {
                show_status(ev.res_id);
                if (ev.conn_info != null) {
                    show_conn_info(ev.conn_info);
                }
            } else if (ev.info.length() > 0) {
                Object[] objArr = new Object[S_ONSTART_CALLED];
                objArr[0] = resString(ev.res_id);
                objArr[S_BIND_CALLED] = ev.info;
                show_status(String.format("%s : %s", objArr));
            } else {
                show_status(ev.res_id);
            }
        }
        show_progress(ev.progress, active);
        show_stats();
        if (ev.res_id == R.string.connected && this.finish_on_connect != FinishOnConnect.DISABLED) {
            if (this.prefs.get_boolean("autostart_finish_on_connect", RETAIN_AUTH)) {
                final Activity self = this;
                new Handler().postDelayed(new Runnable() {
						public void run() {
							if (Main.this.finish_on_connect != FinishOnConnect.DISABLED) {
								self.finish();
							}
						}
					}, 1000);
                return;
            }
            this.finish_on_connect = FinishOnConnect.DISABLED;
        }
    }

    private void stop_service() {
        submitDisconnectIntent(true);
    }

    private void stop() {
        cancel_stats();
        doUnbindService();
        if (this.stop_service_on_client_exit) {
            Log.d(TAG, "CLI: stopping service");
            stop_service();
        }
    }

    protected void onStop() {
        Log.d(TAG, "CLI: onStop");
        cancel_stats();
        super.onStop();
    }

    protected void onStart() {
        super.onStart();
        Log.d(TAG, "CLI: onStart");
        this.startup_state |= S_ONSTART_CALLED;
        if (this.finish_on_connect == FinishOnConnect.ENABLED) {
            this.finish_on_connect = FinishOnConnect.ENABLED_ACROSS_ONSTART;
        }
        boolean active = is_active();
        if (active) {
            schedule_stats();
        }
        if (process_autostart_intent(active)) {
            ui_setup(active, UIF_RESET, null);
        }
    }

    protected void onDestroy() {
        stop();
        Log.d(TAG, "CLI: onDestroy called");
        super.onDestroy();
    }

    private boolean process_autostart_intent(boolean active) {
        if ((this.startup_state & REQUEST_IMPORT_PKCS12) == REQUEST_IMPORT_PKCS12) {
            Intent intent = getIntent();
            String apn_key = "net.openvpn.openvpn.AUTOSTART_PROFILE_NAME";
            String apn = intent.getStringExtra(apn_key);
            if (apn != null) {
                this.autostart_profile_name = null;
                String str = TAG;
                Object[] objArr = new Object[S_BIND_CALLED];
                objArr[0] = apn;
                Log.d(str, String.format("CLI: autostart: %s", objArr));
                intent.removeExtra(apn_key);
                if (!active) {
                    ProfileList proflist = profile_list();
                    if (proflist == null || proflist.get_profile_by_name(apn) == null) {
                        ok_dialog(resString(R.string.profile_not_found), apn);
                    } else {
                        this.autostart_profile_name = apn;
                        return true;
                    }
                } else if (!current_profile().get_name().equals(apn)) {
                    this.autostart_profile_name = apn;
                    submitDisconnectIntent(RETAIN_AUTH);
                }
            }
        }
        return RETAIN_AUTH;
    }

    private void cancel_ui_reset() {
        this.ui_reset_timer_handler.removeCallbacks(this.ui_reset_timer_task);
    }

    private void schedule_ui_reset(long delay) {
        cancel_ui_reset();
        this.ui_reset_timer_handler.postDelayed(this.ui_reset_timer_task, delay);
    }

    private void hide_status() {
        this.status_view.setVisibility(8);
    }

    private void show_status(String text) {
        this.status_view.setVisibility(0);
        this.status_view.setText(text);
    }

    private void show_status(int res_id) {
        this.status_view.setVisibility(0);
        this.status_view.setText(res_id);
    }

    private void show_status_icon(int res_id) {
        this.status_icon_view.setImageResource(res_id);
    }

    private void show_progress(int progress, boolean active) {
        if (progress <= 0 || progress >= 99) {
            this.progress_bar.setVisibility(8);
            return;
        }
        this.progress_bar.setVisibility(0);
        this.progress_bar.setProgress(progress);
    }

    private void cancel_stats() {
        this.stats_timer_handler.removeCallbacks(this.stats_timer_task);
    }

    private void schedule_stats() {
        cancel_stats();
        this.stats_timer_handler.postDelayed(this.stats_timer_task, 1000);
    }

    private static String render_bandwidth(long bw) {
        String postfix;
        float div;
        Object[] objArr;
        float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            postfix = "TB";
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            postfix = "GB";
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            postfix = "MB";
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            postfix = "KB";
            div = 1024.0f;
        } else {
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Float.valueOf(bwf);
            return String.format("%.0f", objArr);
        }
        objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Float.valueOf(bwf / div);
        objArr[S_BIND_CALLED] = postfix;
        return String.format("%.2f %s", objArr);
    }

    private String render_last_pkt_recv(int sec) {
        if (sec >= 3600) {
            return resString(R.string.lpr_gt_1_hour_ago);
        }
        String resString;
        Object[] objArr;
        if (sec >= 120) {
            resString = resString(R.string.lpr_gt_n_min_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec / 60);
            return String.format(resString, objArr);
        } else if (sec >= S_ONSTART_CALLED) {
            resString = resString(R.string.lpr_n_sec_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec);
            return String.format(resString, objArr);
        } else if (sec == S_BIND_CALLED) {
            return resString(R.string.lpr_1_sec_ago);
        } else {
            if (sec == 0) {
                return resString(R.string.lpr_lt_1_sec_ago);
            }
            return "";
        }
    }

    private void show_stats() {
        if (is_active()) {
            ConnectionStats stats = get_connection_stats();
            StatisticGraphData.DataTransferStats data =   StatisticGraphData.getStatisticData().getDataTransferStats();
		    data.addBytesReceived(manage(stats.bytes_out));
			this.last_pkt_recv_view.setText(render_last_pkt_recv(stats.last_packet_received));
            this.duration_view.setText(MainBase.render_duration(stats.duration));
            this.bytes_in_view.setText(render_bandwidth(stats.bytes_in));
            this.bytes_out_view.setText(render_bandwidth(stats.bytes_out));
        }
    }
	private long manage(long bw)
	{
		float div = 0;
		float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            div = 1024.0f;
        } else {
            return bw;
        }

		return (long)div;
	}

    private void clear_stats() {
        this.last_pkt_recv_view.setText("");
        this.duration_view.setText("");
        this.bytes_in_view.setText("");
        this.bytes_out_view.setText("");
        reset_conn_info();
    }

    private int n_profiles_loaded() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.size();
        }
        return 0;
    }

    private String selected_profile_name() {
        String ret = null;
        ProfileList proflist = profile_list();
        if (proflist != null && proflist.size() > 0) {
            ret = proflist.size() == S_BIND_CALLED ? ((Profile) proflist.get(0)).get_name() : SpinUtil.get_spinner_selected_item(this.profile_spin);
        }
        if (ret == null) {
            return "UNDEFINED_PROFILE";
        }
        return ret;
    }

    private Profile selected_profile() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.get_profile_by_name(selected_profile_name());
        }
        return null;
    }

    private void clear_auth() {
        this.username_edit.setText("");
        this.pk_password_edit.setText("");
        this.password_edit.setText("");
        this.response_edit.setText("");
    }

    private void ui_setup(boolean active, int flags, String profile_override) {
        boolean orig_active = active;
        boolean autostart = RETAIN_AUTH;
        cancel_ui_reset();

        if (!((UIF_RESET & flags) == 0 && orig_active == this.last_active)) {
            clear_auth();
            if (!(active || this.autostart_profile_name == null)) {
                autostart = true;
                profile_override = this.autostart_profile_name;
                this.autostart_profile_name = null;
            }
            ProfileList proflist = profile_list();
            Profile prof = null;
            if (proflist == null || proflist.size() <= 0) {
                this.profile_group.setVisibility(8);
            } else {
                ProfileSource ps = ProfileSource.UNDEF;
                SpinUtil.show_spinner(this, this.profile_spin, proflist.profile_names());
                if (active) {
                    ps = ProfileSource.SERVICE;
                    prof = current_profile();
                }
                if (prof == null && profile_override != null) {
                    ps = ProfileSource.PRIORITY;
                    prof = proflist.get_profile_by_name(profile_override);
                    if (prof == null) {
                        Log.d(TAG, "CLI: profile override not found");
                        autostart = RETAIN_AUTH;
                    }
                }
                if (prof == null) {
                    if ((UIF_PROFILE_SETTING_FROM_SPINNER & flags) != 0) {
                        ps = ProfileSource.SPINNER;
                        prof = proflist.get_profile_by_name(SpinUtil.get_spinner_selected_item(this.profile_spin));
                    } else {
                        ps = ProfileSource.PREFERENCES;
                        prof = proflist.get_profile_by_name(this.prefs.get_string("profile"));
                    }
                }
                if (prof == null) {
                    ps = ProfileSource.LIST0;
                    prof = (Profile) proflist.get(0);
                }
                if (ps != ProfileSource.PREFERENCES && (UIF_REFLECTED & flags) == 0) {
                    this.prefs.set_string("profile", prof.get_name());
                    gen_ui_reset_event(true);
                }
                if (ps != ProfileSource.SPINNER) {
                    SpinUtil.set_spinner_selected_item(this.profile_spin, prof.get_name());
                }
                this.profile_group.setVisibility(0);
                this.profile_spin.setEnabled(!active ? true : RETAIN_AUTH);
                this.profile_edit.setVisibility(active ? 8 : 0);
            }
            if (prof != null) {
                if ((UIF_RESET & flags) != 0) {
                    prof.reset_dynamic_challenge();
                }
                EditText focus = null;
                if (!active && (flags & 32) != 0) {
                    this.post_import_help_blurb.setVisibility(0);
                } else if (active) {
                    this.post_import_help_blurb.setVisibility(8);
                }
                ProxyList proxy_list = get_proxy_list();
                if (active || proxy_list.size() <= 0) {
                    this.proxy_group.setVisibility(8);
                } else {
                    SpinUtil.show_spinner(this, this.proxy_spin, proxy_list.get_name_list(true));
                    String name = proxy_list.get_enabled(true);
                    if (name != null) {
                        SpinUtil.set_spinner_selected_item(this.proxy_spin, name);
                    }
                    this.proxy_group.setVisibility(0);
                }
                if (active || !prof.server_list_defined()) {
                    this.server_group.setVisibility(8);
                } else {
                    SpinUtil.show_spinner(this, this.server_spin, prof.get_server_list().display_names());
                    String server = this.prefs.get_string_by_profile(prof.get_name(), "server");
                    if (server != null) {
                        SpinUtil.set_spinner_selected_item(this.server_spin, server);
                    }
                    this.server_group.setVisibility(0);
                }
                if (active) {
                    this.username_group.setVisibility(8);
                    this.pk_password_group.setVisibility(8);
                    this.password_group.setVisibility(8);
					/*mSetRightOut.setTarget(passLayout);
					 mSetLeftIn.setTarget(graphLayout);
					 mSetRightOut.start();
					 mSetLeftIn.start();*/
                } else {
                    boolean is_pwd_save;
                    String saved_pwd;
                    boolean udef = prof.userlocked_username_defined();
                    boolean autologin = prof.get_autologin();
                    boolean pk_pwd_req = prof.get_private_key_password_required();
                    boolean dynamic_challenge = prof.is_dynamic_challenge();
                    if (autologin) {
						editor.putBoolean(DIALOG, true).apply();
						/*mSetRightOut.setTarget(passLayout);
						 mSetLeftIn.setTarget(graphLayout);
						 mSetRightOut.start();
						 mSetLeftIn.start();*/
					} else {
						editor.putBoolean(DIALOG, false).apply();
						/*mSetRightOut.setTarget(graphLayout);
						 mSetLeftIn.setTarget(passLayout);
						 mSetRightOut.start();
						 mSetLeftIn.start();*/
					}
					if ((!autologin || (autologin && udef)) && !dynamic_challenge) {
                        if (udef) {
							editor.putString(prof.get_name()+USER, prof.get_userlocked_username()).apply();
                            this.username_edit.setText(prof.get_userlocked_username());
                            set_enabled(this.username_edit, RETAIN_AUTH);
                        } else {
                            set_enabled(this.username_edit, false);
                            String pref_username = this.prefs.get_string_by_profile(prof.get_name(), "username");
                            editor.putString(prof.get_name()+USER,pref_username).apply();
							if (pref_username != null) {
                                this.username_edit.setText(pref_username);

                            } else if (null == null) {
                                focus = this.username_edit;
                            }
                        }

                        this.username_group.setVisibility(0);
                    } else {
                        this.username_group.setVisibility(8);

                    }
                    if (pk_pwd_req) {
                        is_pwd_save = this.prefs.get_boolean_by_profile(prof.get_name(), "pk_password_save", RETAIN_AUTH);
                        saved_pwd = null;
                        this.pk_password_group.setVisibility(0);
                        this.pk_password_save_checkbox.setChecked(is_pwd_save);
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("pk", prof.get_name());
                        }
                        if (saved_pwd != null) {
                            this.pk_password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.pk_password_edit;
                        }
                    } else {
                        this.pk_password_group.setVisibility(8);
                    }
                    if (autologin || dynamic_challenge) {
                        this.password_group.setVisibility(8);

                    } else {
                        boolean is_auth_pw_save = prof.get_allow_password_save();
                        is_pwd_save = (is_auth_pw_save && this.prefs.get_boolean_by_profile(prof.get_name(), "auth_password_save", RETAIN_AUTH)) ? true : RETAIN_AUTH;
                        saved_pwd = null;
                        this.password_group.setVisibility(0);

                        this.password_save_checkbox.setEnabled(is_auth_pw_save);
                        this.password_save_checkbox.setChecked(is_pwd_save);
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("auth", prof.get_name());
                        }
						editor.putString(PASS+prof.get_name(),pwds.get("auth",prof.get_name())).apply();
                        if (saved_pwd != null) {
                            this.password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.password_edit;
                        }
                    }
                }
                if (active || prof.get_autologin() || !prof.challenge_defined()) {
                    this.cr_group.setVisibility(8);
                } else {
                    this.cr_group.setVisibility(0);
                    Challenge chal = prof.get_challenge();
                    this.challenge_view.setText(chal.get_challenge());
                    this.challenge_view.setVisibility(0);
                    if (chal.get_response_required()) {
                        if (chal.get_echo()) {
                            this.response_edit.setTransformationMethod(SingleLineTransformationMethod.getInstance());
                        } else {
                            this.response_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        }
                        this.response_edit.setVisibility(0);
                        if (focus == null) {
                            focus = this.response_edit;
                        }
                    } else {
                        this.response_edit.setVisibility(8);
                    }
                    if (prof.is_dynamic_challenge()) {
                        schedule_ui_reset(prof.get_dynamic_challenge_expire_delay());
                    }
                }
                this.button_group.setVisibility(0);
                if (orig_active) {
					swt.setChecked(true);
					useDns.setEnabled(false);
					usePayload.setEnabled(false);
                    this.conn_details_group.setVisibility(0);
                    this.connect_button.setVisibility(8);
                    this.disconnect_button.setVisibility(0);
                } else {
					StatisticGraphData.getStatisticData().getDataTransferStats().stop();
					useDns.setEnabled(true);
					swt.setChecked(false);
					usePayload.setEnabled(true);
                    this.conn_details_group.setVisibility(8);
                    this.connect_button.setVisibility(0);
                    this.disconnect_button.setVisibility(8);
                }
                if (focus != null) {
                    autostart = RETAIN_AUTH;
                }
                req_focus(focus);
            } else {
                this.post_import_help_blurb.setVisibility(8);
                this.proxy_group.setVisibility(8);
                this.server_group.setVisibility(8);
                this.username_group.setVisibility(8);
                this.pk_password_group.setVisibility(8);
                this.password_group.setVisibility(8);
                this.cr_group.setVisibility(8);
                this.conn_details_group.setVisibility(8);
                this.button_group.setVisibility(8);
                show_status_icon(R.drawable.info);
                show_status(R.string.no_profiles_loaded);
            }
            if (orig_active) {
                schedule_stats();
            } else {
                cancel_stats();
            }
        }
        this.last_active = orig_active;
        if (autostart && !this.last_active) {
            this.finish_on_connect = FinishOnConnect.ENABLED;
            start_connect();
        }


	}

    private void set_enabled(EditText editText, boolean state) {
        editText.setEnabled(state);
        editText.setFocusable(state);
        editText.setFocusableInTouchMode(state);
    }

	
	
	
	/*public static void account()
	{
		LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View inflate = inflater.inflate(R.layout.abc_login_activity, (ViewGroup) null);
		final EditText user = (EditText) inflate.findViewById(R.id.username_vpn);
		user.setText(sp.getString("USERNAME",""));
		final EditText pass = (EditText) inflate.findViewById(R.id.password_vpn);
		pass.setText(sp.getString("PASSWORD", ""));
		new AlertDialog.Builder(mContext)
			.setView(inflate)
			.setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
					sp.edit().putString("USERNAME", user.getText().toString()).commit();
					sp.edit().putString("PASSWORD", pass.getText().toString()).commit();
				}
			})
			.setNegativeButton("CANCEL", null)
			.create().show();
	}*/
	
	
	
	
    /*public boolean onOptionsItemSelected(MenuItem item) {
	 switch (item.getItemId()) {
	 case R.id.import_profile:
	 raise_file_selection_dialog(S_ONSTART_CALLED, R.string.select_profile);
	 break;
	 /*case R.id.export_config
	 String name = (String)profile_spin.getSelectedItem();
	 startActivity(new Intent(this, ExportActivity.class).putExtra("PROF_NAME",name));
	 break;
	 case R.id.about:
	 //	about();
	 break;
	 /*case R.id.payload_generator
	 if (isHomeTab) {
	 startActivity(new Intent(this, PayloadGenerator.class).putExtra("PROF_NAME", (String)profile_spin.getSelectedItem()));
	 } else {
	 ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
	 cm.setText(getLog());
	 Toast.makeText(this, "Log Copied",-1).show();
	 }
	 break;
	 }
	 return super.onOptionsItemSelected(item);
	 }*/
	private void about()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setView(getLayoutInflater().inflate(R.layout.about,null));
		builder.setCancelable(false);
		builder.setPositiveButton("OK",new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// send data from the AlertDialog to the Activity

					mRewardedVideoAd.show();
				}
			});
		// create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

	/*public void about(){
	 // create an alert builder
	 AlertDialog.Builder builder = new AlertDialog.Builder(this);

	 final View customLayout = getLayoutInflater().inflate(R.layout.about, null);
	 builder.setView(customLayout);
	 // add a button
	 builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
	 @Override
	 public void onClick(DialogInterface dialog, int which) {
	 // send data from the AlertDialog to the Activity
	 adsPopUp();
	 if (mRewardedVideoAd.isLoaded()) {
	 mRewardedVideoAd.show();
	 }
	 }
	 });
	 // create and show the alert dialog
	 AlertDialog dialog = builder.create();
	 dialog.show();
	 }*/
	private String shareLogs()
	{
		StringBuilder str = new StringBuilder();
		for (int i = 0; i < adapter.getCount(); i++) {
			str.append(adapter.getItem(i) +"\n");
		}
		return str.toString();
	}
	private String getLog()
	{
		StringBuilder str = new StringBuilder();
		for (int i = 0; i < adapter.getCount(); i++) {
			str.append(adapter.getItem(i) +"\n");
		}
		return str.toString();
	}

    public void onClick(View v) {
        cancel_ui_reset();
        this.autostart_profile_name = null;
        this.finish_on_connect = FinishOnConnect.DISABLED;
        int viewid = v.getId();
		if (viewid == R.id.connect) {
            start_connect();
        } else if (viewid == R.id.disconnect) {

			quiter2();
        } else if (viewid == R.id.profile_edit || viewid == R.id.proxy_edit) {
            openContextMenu(v);
        } else if (viewid == R.id.switch_connect) {
			if (swt.isChecked()) {
				start_connect();
			} else {
				submitDisconnectIntent(true);
			}
		
	}
}
    
	/*private boolean isEmpty()
	{
		String name = selected_profile_name();
		boolean user = pref.getString(name+LoginActivity.USERNAME,"").isEmpty();
		boolean pass = pref.getString(name+LoginActivity.PASSWORD,"").isEmpty();
		if (user && pass) {
			return true;
		} else if (user) {
			return true;
		} else if (pass) {
			return true;
		} else {
			return false;
		}


	}*/

    private void start_connect() {
        cancel_ui_reset();
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            try {
                Log.d(TAG, "CLI: requesting VPN actor rights");
                startActivityForResult(intent, S_BIND_CALLED);
                return;
            } catch (ActivityNotFoundException e) {
                Log.e(TAG, "CLI: requesting VPN actor rights failed", e);
                ok_dialog(resString(R.string.vpn_permission_dialog_missing_title), resString(R.string.vpn_permission_dialog_missing_text));
                return;
            }
        }
        Log.d(TAG, "CLI: app is already authorized as VPN actor");
        resolve_epki_alias_then_connect();
    }

    public boolean onTouch(View v, MotionEvent event) {
        boolean new_expand_stats = RETAIN_AUTH;
        if (v.getId() != R.id.conn_details_boxed || event.getAction() != 0) {
            return RETAIN_AUTH;
        }
        if (!this.prefs.get_boolean("expand_stats", RETAIN_AUTH)) {
            new_expand_stats = true;
        }
        this.prefs.set_boolean("expand_stats", new_expand_stats);
        set_visibility_stats_expansion_group();
        return true;
    }

	public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        cancel_ui_reset();
        int viewid = parent.getId();
        if (viewid == R.id.profile) {
            ui_setup(is_active(), 327680, null);
			//-------------Account-----------------------------------------------
			//boolean z = pref.getBoolean(DIALOG, true);
			//go(z);

        } else if (viewid == R.id.proxy) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_list.set_enabled(SpinUtil.get_spinner_list_item(this.proxy_spin, position));
                proxy_list.save();
                gen_ui_reset_event(true);
            }
        } else if (viewid == R.id.server) {
            String server = SpinUtil.get_spinner_list_item(this.server_spin, position);
            this.prefs.set_string_by_profile(SpinUtil.get_spinner_selected_item(this.profile_spin), "server", server);
            gen_ui_reset_event(true);
//-------------Promo-----------------------------------------------
        } else if (viewid == R.id.promo_spinner) {
			try {
				JSONObject obj = getJSONArray().getJSONObject(position);
				payloadInfo.setText(obj.getString("Info"));
			} catch (Exception e) {

			}

			editor.putInt(SELECTED_PROMO, position).apply();
		}
    }

//------------------------------------------------------------------------------------
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    private void menu_add(ContextMenu menu, int id, boolean enabled, String menu_key) {
        MenuItem item = menu.add(0, id, 0, id).setEnabled(enabled);
        if (menu_key != null) {
            item.setIntent(new Intent().putExtra("net.openvpn.openvpn.MENU_KEY", menu_key));
        }
    }

    private String get_menu_key(MenuItem item) {
        if (item != null) {
            Intent intent = item.getIntent();
            if (intent != null) {
                return intent.getStringExtra("net.openvpn.openvpn.MENU_KEY");
            }
        }
        return null;
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        boolean z = RETAIN_AUTH;
        Log.d(TAG, "CLI: onCreateContextMenu");
        super.onCreateContextMenu(menu, v, menuInfo);
        int viewid = v.getId();
        if (!is_active() && (viewid == R.id.profile || viewid == R.id.profile_edit)) {
            Profile prof = selected_profile();
            if (prof != null) {
                String profile_name = prof.get_name();
                menu.setHeaderTitle(profile_name);
                if (SpinUtil.get_spinner_count(this.profile_spin) > S_BIND_CALLED) {
                    z = true;
                }
                menu_add(menu, R.string.profile_context_menu_change_profile, z, null);
                menu_add(menu, R.string.profile_context_menu_create_shortcut, true, profile_name);
                menu_add(menu, R.string.profile_context_menu_delete, prof.is_deleteable(), profile_name);
                menu_add(menu, R.string.profile_context_menu_rename, prof.is_renameable(), profile_name);
                menu_add(menu, R.string.profile_context_forget_creds, true, profile_name);
            } else {
                menu.setHeaderTitle(R.string.profile_context_none_selected);
            }
            menu_add(menu, R.string.profile_context_cancel, true, null);
        } else if (!is_active()) {
            if (viewid == R.id.proxy || viewid == R.id.proxy_edit) {
                ProxyList proxy_list = get_proxy_list();
                if (proxy_list != null) {
                    String proxy_name = proxy_list.get_enabled(true);
                    boolean is_none = proxy_list.is_none(proxy_name);
                    menu.setHeaderTitle(proxy_name);
                    menu_add(menu, R.string.proxy_context_change_proxy, SpinUtil.get_spinner_count(this.proxy_spin) > S_BIND_CALLED ? true : RETAIN_AUTH, null);
                    menu_add(menu, R.string.proxy_context_edit, !is_none ? true : RETAIN_AUTH, proxy_name);
                    if (!is_none) {
                        z = true;
                    }
                    menu_add(menu, R.string.proxy_context_delete, z, proxy_name);
                    menu_add(menu, R.string.proxy_context_forget_creds, proxy_list.has_saved_creds(proxy_name), proxy_name);
                } else {
                    menu.setHeaderTitle(R.string.proxy_context_none_selected);
                }
                menu_add(menu, R.string.proxy_context_cancel, true, null);
            }
        }
    }

    public boolean onContextItemSelected(MenuItem item) {
        Log.d(TAG, "CLI: onContextItemSelected");
        String prof_name;
        String proxy_name;
        switch (item.getItemId()) {
            case R.string.profile_context_menu_change_profile /*2131099771*/:
                this.profile_spin.performClick();
                return true;
            case R.string.profile_context_menu_create_shortcut /*2131099772*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                launch_create_profile_shortcut_dialog(prof_name);
                return true;
            case R.string.profile_context_menu_delete /*2131099773*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                submitDeleteProfileIntentWithConfirm(prof_name);
                return true;
            case R.string.profile_context_menu_rename /*2131099774*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                launch_rename_profile_dialog(prof_name);
                return true;
            case R.string.profile_context_forget_creds /*2131099775*/:
                ProfileList proflist = profile_list();
                if (proflist == null) {
                    return true;
                }
                Profile prof = proflist.get_profile_by_name(get_menu_key(item));
                if (prof == null) {
                    return true;
                }
                prof_name = prof.get_name();
                this.pwds.remove("pk", prof_name);
                this.pwds.remove("auth", prof_name);
                prof.forget_cert();
                ui_setup(is_active(), UIF_RESET, null);
                return true;
            case R.string.profile_context_cancel /*2131099776*/:
            case R.string.proxy_context_cancel /*2131099862*/:
                return true;
            case R.string.proxy_context_change_proxy /*2131099858*/:
                this.proxy_spin.performClick();
                return true;

            case R.string.proxy_context_delete /*2131099860*/:
                delete_proxy_with_confirm(get_menu_key(item));
                return true;
            case R.string.proxy_context_forget_creds /*2131099861*/:
                proxy_name = get_menu_key(item);
                ProxyList proxy_list = get_proxy_list();
                if (proxy_list == null) {
                    return true;
                }
                proxy_list.forget_creds(proxy_name);
                proxy_list.save();
                return true;
            default:
                return RETAIN_AUTH;
        }
    }

    private void launch_create_profile_shortcut_dialog(final String prof_name) {
        View view = getLayoutInflater().inflate(R.layout.create_shortcut_dialog, null);
        final EditText name_field = (EditText) view.findViewById(R.id.shortcut_name);
        name_field.setText(prof_name);
        name_field.selectAll();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        Main.this.createConnectShortcut(prof_name, name_field.getText().toString());
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.create_shortcut_title).setView(view).setPositiveButton(R.string.create_shortcut_yes, dialogClickListener).setNegativeButton(R.string.create_shortcut_cancel, dialogClickListener).show();
    }

    private void launch_rename_profile_dialog(final String orig_prof_name) {
        View view = getLayoutInflater().inflate(R.layout.rename_profile_dialog, null);
        final EditText name_field = (EditText) view.findViewById(R.id.rename_profile_name);
        name_field.setText(orig_prof_name);
        name_field.selectAll();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        Main.this.submitRenameProfileIntent(orig_prof_name, name_field.getText().toString());
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.rename_profile_title).setView(view).setPositiveButton(R.string.rename_profile_yes, dialogClickListener).setNegativeButton(R.string.rename_profile_cancel, dialogClickListener).show();
    }

    private void delete_proxy_with_confirm(final String proxy_name) {
        final ProxyList proxy_list = get_proxy_list();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        if (proxy_list != null) {
                            proxy_list.remove(proxy_name);
                            proxy_list.save();
                            Main.this.gen_ui_reset_event(Main.RETAIN_AUTH);
                            return;
                        }
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.proxy_delete_confirm_title).setMessage(proxy_name).setPositiveButton(R.string.proxy_delete_confirm_yes, dialogClickListener).setNegativeButton(R.string.proxy_delete_confirm_cancel, dialogClickListener).show();
    }

    private void forget_creds_with_confirm() {
        final Context context = this;
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        Main.this.pwds.regenerate(true);
                        ProfileList proflist = Main.this.profile_list();
                        if (proflist != null) {
                            proflist.forget_certs();
                        }
                        TrustMan.forget_certs(context);
                        ProxyList proxy_list = Main.this.get_proxy_list();
                        if (proxy_list != null) {
                            proxy_list.forget_creds();
                            proxy_list.save();
                        }
                        Main.this.ui_setup(Main.this.is_active(), Main.UIF_RESET, null);
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.forget_creds_title).setMessage(R.string.forget_creds_message).setPositiveButton(R.string.forget_creds_yes, dialogClickListener).setNegativeButton(R.string.forget_creds_cancel, dialogClickListener).show();
    }

    public PendingIntent get_configure_intent(int requestCode) {
        return PendingIntent.getActivity(this, requestCode, getIntent(), 268435456);
    }

    private void resolve_epki_alias_then_connect() {
        resolveExternalPkiAlias(selected_profile(), new EpkiPost() {
				public void post_dispatch(String alias) {
					Main.this.do_connect(alias);
				}
			});
    }

    private void do_connect(String epki_alias) {
        String app_name = "net.openvpn.connect.android";
        String proxy_name = null;
        String server = null;
        String username = null;
        String password = null;
        String pk_password = null;
        String response = null;
        boolean is_auth_pwd_save = RETAIN_AUTH;
        String profile_name = selected_profile_name();
        if (this.proxy_group.getVisibility() == 0) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_name = proxy_list.get_enabled(RETAIN_AUTH);
            }
        }
        if (this.server_group.getVisibility() == 0) {
            server = SpinUtil.get_spinner_selected_item(this.server_spin);
        }
		// if (this.username_group.getVisibility() == 0) {
		username = pref.getString(profile_name+LoginActivity.USERNAME,khanusername);
		if (username.length() > 0) {
			//this.prefs.set_string_by_profile(profile_name, "username", username);
		}
		// }
        if (this.pk_password_group.getVisibility() == 0) {
            pk_password = this.pk_password_edit.getText().toString();
            boolean is_pk_pwd_save = this.pk_password_save_checkbox.isChecked();
            this.prefs.set_boolean_by_profile(profile_name, "pk_password_save", is_pk_pwd_save);
            if (is_pk_pwd_save) {
                this.pwds.set("pk", profile_name, pk_password);
            } else {
                this.pwds.remove("pk", profile_name);
            }
        }
		// if (this.password_group.getVisibility() == 0) {
		password = pref.getString(profile_name+LoginActivity.PASSWORD,khanpassword);
		is_auth_pwd_save = this.password_save_checkbox.isChecked();
		this.prefs.set_boolean_by_profile(profile_name, "auth_password_save", is_auth_pwd_save);
		//  if (is_auth_pwd_save) {
		// this.pwds.set("auth", profile_name, password);
		// } else {
		//      this.pwds.remove("auth", profile_name);
		// }
		// }
        if (this.cr_group.getVisibility() == 0) {
            response = this.response_edit.getText().toString();
        }
        clear_auth();
        String vpn_proto = this.prefs.get_string("vpn_proto");
        String conn_timeout = this.prefs.get_string("conn_timeout");
        String compression_mode = this.prefs.get_string("compression_mode");
        clear_stats();
		String name =  profile_name+".ovpn";
		boolean isPull = prefs.get_boolean(Util.PULL_KEY, true);
		boolean isRedirect = prefs.get_boolean(Util.REDIRECT_KEY, true);
		boolean isOnlineHost = prefs.get_boolean(Util.ONLINE_HOST_KEY, true);
		boolean isForwardHost = prefs.get_boolean(Util.FORWARD_HOST_KEY, true);
		boolean isForwardedFor = prefs.get_boolean(Util.FORWARDED_FOR_KEY, true);
		boolean isKeepAlive = prefs.get_boolean(Util.KEEP_ALIVE_KEY, true);

		String sPull = "";
		String sRedirect = "";
		String urlHost = prefs.get_string(Util.URL_HOST_KET);
		String remote = pref.getString(name + Util.PROXY_KEY,"").replace(" ","");
		String port = pref.getString(name + Util.PORT_KEY,"");
		String sOnlineHost = "";
		String sForwardHost = "";
		String sForwardedFor = "";
		String sKeepAlive = "";
		String sHost = "Host " +urlHost;
		String http_option = "http-proxy-option CUSTOM-HEADER ";
		String offSet = "\n";
		String sp = " ";
		String a = "";
		String http_proxy = "http-proxy-retry 9"+offSet+"http-proxy"+sp+remote+sp+port+offSet;
		String dhcp = "";
		if (useDns.isChecked()) {
			dhcp = "dhcp-option DNS 208.67.222.222" + offSet +"dhcp-option DNS 208.67.220.220"+offSet;
		} else {
			dhcp = "";
		}
		if (isPull) {
			sPull = "pull"+offSet;
		} else {
			sPull = "";
		} if (isRedirect) {
			sRedirect = "redirect-gateway def1"+offSet;
		}
		if (isOnlineHost) {
			sOnlineHost = http_option +resString(R.string.online_host)+sp+urlHost+offSet;
		} else {
			sOnlineHost = "";
		} if (isForwardHost) {
			sForwardHost = http_option + resString(R.string.forward_host)+sp+urlHost+offSet;
		} else {
			sForwardHost = "";
		} if (isForwardedFor) {
			sForwardedFor = http_option + resString(R.string.forwarded_for)+sp+urlHost+offSet;
		} else {
			sForwardedFor = "";
		} if (isKeepAlive) {
			sKeepAlive = http_option + "Connection "+resString(R.string.keep_alive)+offSet;
		} else {
			sForwardHost = "";
		}
		boolean z = pref.getBoolean("custom_payload", false);
		if (z) {
			a = sPull+sRedirect+http_proxy + http_option+sHost+offSet+sOnlineHost+sForwardHost+sForwardedFor+sKeepAlive +dhcp +offSet;
        } else {
			int selected = promoSpinner.getSelectedItemPosition();
			try {
				String http_options = "http-proxy-option CUSTOM-HEADER ";
				JSONArray jsArray = getJSONArray();
				JSONObject obj = jsArray.getJSONObject(selected);
			    JSONObject payload = obj.getJSONObject("Payload");
				boolean custom = payload.getJSONObject("Proxy").getBoolean("Custom") == true;
				String http_retry = "http-retry 9"+offSet;
				String http = "http-proxy ";
				String http_proxys = custom ? http_retry + http+ payload.getJSONObject("Proxy").getString("Remote")+" "+payload.getJSONObject("Proxy").getString("Port")+offSet : http_retry + http+ Util.getRp(this, name)+" "+"8080"+offSet;
				String murl = DebugVpn.debug(payload.getString("Url"));
				String mhost = payload.getBoolean("Host") == true? http_options+"Host "+murl+offSet:"";
				String online_host = payload.getBoolean("Online-Host") == true ? http_options+"X-Online-Host "+murl+offSet : "";
				String forward_host = payload.getBoolean("Forward-Host") == true ? http_options+"X-Forward-Host "+murl+offSet : "";
				String reverse_host = payload.getBoolean("Reverse-Proxy") == true ? http_options+ "X-Forwarded-For "+murl + offSet : "";
				String keep_alive = payload.getBoolean("Keep-Alive") == true ? http_options+"Connection Keep-Alive"+offSet : "";
				a = http_proxys + mhost + online_host + forward_host + reverse_host + keep_alive;
			} catch (Exception e) {

			}
		}
		submitConnectIntent(profile_name, server, vpn_proto, conn_timeout, a, username, password, is_auth_pwd_save, pk_password, response, epki_alias, compression_mode, proxy_name, null, null, true, get_gui_version(app_name));

    }
    private void import_profile(String path) {
        submitImportProfileViaPathIntent(path);
    }

    protected void onActivityResult(int request, int result, Intent data) {
        String str = TAG;
        Object[] objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Integer.valueOf(request);
        objArr[S_BIND_CALLED] = Integer.valueOf(result);
        Log.d(str, String.format("CLI: onActivityResult request=%d result=%d", objArr));
        String path;
        switch (request) {
            case S_BIND_CALLED /*1*/:
                if (result == -1) {
                    resolve_epki_alias_then_connect();
                    return;
                } else if (result != 0) {
                    return;
                } else {
                    if (this.finish_on_connect == FinishOnConnect.ENABLED) {
                        finish();
                        return;
                    } else if (this.finish_on_connect == FinishOnConnect.ENABLED_ACROSS_ONSTART) {
                        this.finish_on_connect = FinishOnConnect.ENABLED;
                        start_connect();
                        return;
                    } else {
                        return;
                    }
                }
            case S_ONSTART_CALLED /*2*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PROFILE: %s", objArr));
                    import_profile(path);
                    return;
                }
                return;
            case REQUEST_IMPORT_PKCS12 /*3*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PKCS12: %s", objArr));
                    import_pkcs12(path);
                    return;
                }
                return;
            default:
                super.onActivityResult(request, result, data);
                return;
        }
    }

    private TextView last_visible_edittext() {
        for (int i = 0; i < this.textgroups.length; i += S_BIND_CALLED) {
            if (this.textgroups[i].getVisibility() == 0) {
                return this.textviews[i];
            }
        }
        return null;
    }

    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (v != last_visible_edittext()) {
            return RETAIN_AUTH;
        }
        if (action_enter(actionId, event) && this.connect_button.getVisibility() == 0) {
            onClick(this.connect_button);
        }
        return true;
    }

    private void req_focus(EditText editText) {
        boolean auto_keyboard = this.prefs.get_boolean("auto_keyboard", RETAIN_AUTH);
        if (editText != null) {
            editText.requestFocus();
            if (auto_keyboard) {
                raise_keyboard(editText);
                return;
            }
            return;
        }
        this.main_scroll_view.requestFocus();
        if (auto_keyboard) {
            dismiss_keyboard();
        }
    }

    private void raise_keyboard(EditText editText) {
        InputMethodManager mgr = (InputMethodManager) getSystemService("input_method");
        if (mgr != null) {
            mgr.showSoftInput(editText, S_BIND_CALLED);
        }
    }

    private void dismiss_keyboard() {
        InputMethodManager mgr = (InputMethodManager) getSystemService("input_method");
        if (mgr != null) {
            TextView[] textViewArr = this.textviews;
            int length = textViewArr.length;
            for (int i = 0; i < length; i += S_BIND_CALLED) {
                mgr.hideSoftInputFromWindow(textViewArr[i].getWindowToken(), 0);
            }
        }
    }
	private void go(boolean z)
	{
		String name = selected_profile_name();
		View v = getLayoutInflater().inflate(R.layout.account_dialog, null);
		EditText user = (EditText)v.findViewById(R.id.vpn_username);
		EditText pass = (EditText)v.findViewById(R.id.vpn_password);
		user.setText(pref.getString(name+USER,""));
		pass.setText(pref.getString(name+PASS,""));
		AlertDialog b = new AlertDialog.Builder(this).create();
		//b.setTitle("Profile Login");
		b.setView(v);
		b.setButton(DialogInterface.BUTTON_POSITIVE, (CharSequence)"Ok", onClick(user,pass));
		b.setButton(DialogInterface.BUTTON_NEGATIVE, (CharSequence)"Cancel", onClick(user, pass));
		if (z) {
			b.dismiss();
		} else {
			b.show();
		}
	}
	private DialogInterface.OnClickListener onClick(final EditText user, final EditText pass)
	{
		return new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface p0, int p1)
			{

				switch (p1) {
					case p0.BUTTON_POSITIVE:
						String name = selected_profile_name();
						String vpn_user = user.getText().toString();
						String vpn_pass = pass.getText().toString();
						editor.putString(name+USER,vpn_user).apply();
						editor.putString(name+PASS,vpn_pass).apply();

						if (username_group.getVisibility() == 0) {
							prefs.set_string_by_profile(name, "username", vpn_user);
						}
						if (password_group.getVisibility() == 0) {
							pwds.set("auth", name, vpn_pass);
						}

						p0.dismiss();
						break;
					case p0.BUTTON_NEGATIVE:
						p0.dismiss();
						break;
					default:
				}
			}
		};
	}

    private void load_ui_elements() {
        this.main_scroll_view = (ScrollView) findViewById(R.id.main_scroll_view);
        this.post_import_help_blurb = findViewById(R.id.post_import_help_blurb);
        this.profile_group = findViewById(R.id.profile_group);
        this.proxy_group = findViewById(R.id.proxy_group);
        this.server_group = findViewById(R.id.server_group);
        this.username_group = findViewById(R.id.username_group);
        this.password_group = findViewById(R.id.password_group);
        this.pk_password_group = findViewById(R.id.pk_password_group);
        this.cr_group = findViewById(R.id.cr_group);
        this.conn_details_group = findViewById(R.id.conn_details_group);
        this.stats_group = findViewById(R.id.stats_group);
        this.stats_expansion_group = findViewById(R.id.stats_expansion_group);
        this.info_group = findViewById(R.id.info_group);
        this.button_group = findViewById(R.id.button_group);
        this.profile_spin = (Spinner) findViewById(R.id.profile);
        this.profile_edit = (ImageButton) findViewById(R.id.profile_edit);
        this.proxy_spin = (Spinner) findViewById(R.id.proxy);
        this.proxy_edit = (ImageButton) findViewById(R.id.proxy_edit);
        this.server_spin = (Spinner) findViewById(R.id.server);
        this.challenge_view = (TextView) findViewById(R.id.challenge);
        this.username_edit = (EditText) findViewById(R.id.username);
        this.password_edit = (EditText) findViewById(R.id.password);
        this.pk_password_edit = (EditText) findViewById(R.id.pk_password);
        this.response_edit = (EditText) findViewById(R.id.response);
        this.password_save_checkbox = (CheckBox) findViewById(R.id.password_save);
        this.pk_password_save_checkbox = (CheckBox) findViewById(R.id.pk_password_save);
        this.status_view = (TextView) findViewById(R.id.status);
        this.status_icon_view = (ImageView) findViewById(R.id.status_icon);
        this.progress_bar = (ProgressBar) findViewById(R.id.progress);
        this.connect_button = (Button) findViewById(R.id.connect);
        this.disconnect_button = (Button) findViewById(R.id.disconnect);
        this.details_more_less = (TextView) findViewById(R.id.details_more_less);
        this.last_pkt_recv_view = (TextView) findViewById(R.id.last_pkt_recv);
        this.duration_view = (TextView) findViewById(R.id.duration);
        this.bytes_in_view = (TextView) findViewById(R.id.bytes_in);
        this.bytes_out_view = (TextView) findViewById(R.id.bytes_out);
        this.connect_button.setOnClickListener(this);
        this.disconnect_button.setOnClickListener(this);
        this.profile_spin.setOnItemSelectedListener(this);
        this.proxy_spin.setOnItemSelectedListener(this);
        this.server_spin.setOnItemSelectedListener(this);
        registerForContextMenu(this.profile_spin);
        registerForContextMenu(this.proxy_spin);
        findViewById(R.id.conn_details_boxed).setOnTouchListener(this);
        this.profile_edit.setOnClickListener(this);
        registerForContextMenu(this.profile_edit);
        this.proxy_edit.setOnClickListener(this);
        registerForContextMenu(this.proxy_edit);
        this.username_edit.setOnEditorActionListener(this);
        this.password_edit.setOnEditorActionListener(this);
        this.pk_password_edit.setOnEditorActionListener(this);
        this.response_edit.setOnEditorActionListener(this);
        this.textgroups = new View[]{this.cr_group, this.password_group, this.pk_password_group, this.username_group};
        this.textviews = new EditText[]{this.response_edit, this.password_edit, this.pk_password_edit, this.username_edit};

    }
}
