package net.openvpn.openvpn;

import android.os.Bundle;
import net.openvpn.openvpn.*;
import android.preference.*;
import khan.raksss.vpn.*;
import android.app.*;

public class SettingsActivity extends MainBase
{
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.settings);
		
		//getFragmentManager().beginTransaction().add(R.id.settings_layout, new SettingsFragment()).commit();
    }
	public class SettingsFragment extends PreferenceFragment implements Preference.OnPreferenceChangeListener
	{
		private CheckBoxPreference cbPayload, cbSettings;
		@Override
		public void onCreate(Bundle bundle)
		{
			super.onCreate(bundle);
			addPreferencesFromResource(R.xml.mypreference);
			cbPayload = (CheckBoxPreference)findPreference("custom_payload");
			cbSettings = (CheckBoxPreference)findPreference("update_settings");
			
			cbPayload.setOnPreferenceChangeListener(this);
			cbSettings.setOnPreferenceChangeListener(this);
		}

		@Override
		public boolean onPreferenceChange(Preference p1, Object p2)
		{
			if (p1.getKey().equals("custom_payload")) {
				cbPayload.getEditor().putBoolean("custom_payload", cbPayload.isChecked()).apply();
			} else if (p1.getKey().equals("update_settings")) {
				cbSettings.getEditor().putBoolean("update_settings", cbSettings.isChecked()).apply();
			}
			// TODO: Implement this method
			return true;
		}
		
	}
}
