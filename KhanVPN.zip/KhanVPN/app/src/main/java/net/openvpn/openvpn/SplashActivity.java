package net.openvpn.openvpn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import khan.raksss.vpn.R;
import android.view.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.util.*;
/**
 * Created by AbhiAndroid
 */

public class SplashActivity extends AppCompatActivity {

    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		
		Window window = getWindow();
		final int layoutFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
		window.getDecorView().setSystemUiVisibility(layoutFlags);
		supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);

		// make the status bar translucent
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			window.setStatusBarColor(0x00000000);
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			// N.B. on some (most?) KitKat devices the status bar has a pre-defined gradient that
			// cannot be overridden.
			window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		}
		setContentView(R.layout.abc_screen_material_default);
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		if (toolbar != null) {
			setSupportActionBar(toolbar);
		}

		// set the height of the scrim to standard status bar height for this device (normally 26dp)
		View statusBarScrim = findViewById(R.id.main_activityStatusBarScrim);
		int height;
		int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
		if (resourceId > 0) {
			height = getResources().getDimensionPixelSize(resourceId);
		} else {
			// belt and braces 
			height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 26f, getResources().getDisplayMetrics());
		}
		if (statusBarScrim != null) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
				ViewGroup.LayoutParams lp = statusBarScrim.getLayoutParams();
				lp.height = height;
				statusBarScrim.setLayoutParams(lp);
				statusBarScrim.setVisibility(View.VISIBLE);
			}
		}
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abc_splashscreen);

        handler=new Handler();
        handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					Intent intent=new Intent(SplashActivity.this,Main.class);
					startActivity(intent);
					finish();
				}
			},2000);

    }
}
