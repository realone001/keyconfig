package net.openvpn.openvpn;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.Arrays;
import android.widget.*;
import android.view.*;
import khan.raksss.vpn.*;

public class SpinUtil {
    public static String[] get_spinner_list(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        int len = aa.getCount();
        String[] ret = new String[len];
        for (int i = 0; i < len; i++) {
            ret[i] = (String) aa.getItem(i);
        }
        return ret;
    }

    public static int get_spinner_count(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return 0;
        }
        return aa.getCount();
    }

    public static String get_spinner_list_item(Spinner spin, int position) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        return (String) aa.getItem(position);
    }

    public static String get_spinner_selected_item(Spinner spin) {
        return (String) spin.getSelectedItem();
    }

    public static void set_spinner_selected_item(Spinner spin, String selected_item) {
        if (selected_item != null) {
            String sel = get_spinner_selected_item(spin);
            if (sel == null || !selected_item.equals(sel)) {
                ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
                int len = aa.getCount();
                for (int pos = 0; pos < len; pos++) {
                    if (selected_item.equals(aa.getItem(pos))) {
                        spin.setSelection(pos);
                    }
                }
            }
        }
    }

     public static void show_spinner(Context context, Spinner spin, String[] content) {
        if (content != null) {
            String[] live_content = get_spinner_list(spin);
            if (live_content == null || !Arrays.equals(content, live_content)) {
                SpinnerAdapter aa = new RenzAdapter(context, content);
                spin.setAdapter(aa);
            }
        }
    }
	public static class RenzAdapter extends ArrayAdapter<String>
	{
		public RenzAdapter(Context context, String[] names)
		{
			super(context, R.layout.spinner_item, names);
		}

		@Override
		public String getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}
		public View getCustomView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.spinner_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.spinner_item_txt);
			ImageView iv = (ImageView)v.findViewById(R.id.spinner_item_image);

			TextView tv2 = (TextView)v.findViewById(R.id.category_name);

			String config = getItem(position);
			tv.setText(config);

			if (config.contains("Lv1")) {
				tv2.setText("FREE");
				tv2.setBackgroundResource(R.drawable.ic_free);
			} else if (config.contains("Lv2")){
				tv2.setText("VIP");
				tv2.setBackgroundResource(R.drawable.ic_premium);
			} else if (config.contains("Lv3")) {
				tv2.setText("PREMIUM");
				tv2.setBackgroundResource(R.drawable.ic_vip);
			}
			iv.setImageResource(android.R.drawable.ic_menu_view);
			if (config.contains("ae")) {
				iv.setImageResource(R.drawable.ae);
			} else if (config.contains("AE")) {
				iv.setImageResource(R.drawable.ae);
			} else if (config.contains("al")) {
				iv.setImageResource(R.drawable.al);
			} else if (config.contains("AL")) {
				iv.setImageResource(R.drawable.al);
			} else if (config.contains("au")) {
				iv.setImageResource(R.drawable.au);
			} else if (config.contains("AU")) {
				iv.setImageResource(R.drawable.au);
			} else if (config.contains("az")) {
				iv.setImageResource(R.drawable.az);
			} else if (config.contains("AZ")) {
				iv.setImageResource(R.drawable.az);
			} else if (config.contains("ad")) {
				iv.setImageResource(R.drawable.ad);
			} else if (config.contains("AD")) {
				iv.setImageResource(R.drawable.ad);
			} else if (config.contains("af")) {
				iv.setImageResource(R.drawable.af);
			} else if (config.contains("AF")) {
				iv.setImageResource(R.drawable.af);
			} else if (config.contains("ag")) {
				iv.setImageResource(R.drawable.ag);
			} else if (config.contains("AG")) {
				iv.setImageResource(R.drawable.ag);
			} else if (config.contains("am")) {
				iv.setImageResource(R.drawable.am);
			} else if (config.contains("AM")) {
				iv.setImageResource(R.drawable.am);
			} else if (config.contains("ao")) {
				iv.setImageResource(R.drawable.ao);
			} else if (config.contains("AO")) {
				iv.setImageResource(R.drawable.ao);
			} else if (config.contains("ar")) {
				iv.setImageResource(R.drawable.ar);
			} else if (config.contains("AR")) {
				iv.setImageResource(R.drawable.ar);
			} else if (config.contains("at")) {
				iv.setImageResource(R.drawable.at);
			} else if (config.contains("AT")) {
				iv.setImageResource(R.drawable.at);
			} else if (config.contains("ba")) {
				iv.setImageResource(R.drawable.ba);
			} else if (config.contains("BA")) {
				iv.setImageResource(R.drawable.ba);
			} else if (config.contains("bb")) {
				iv.setImageResource(R.drawable.bb);
			} else if (config.contains("BB")) {
				iv.setImageResource(R.drawable.bb);
			} else if (config.contains("bd")) {
				iv.setImageResource(R.drawable.bd);
			} else if (config.contains("BD")) {
				iv.setImageResource(R.drawable.bd);
			} else if (config.contains("be")) {
				iv.setImageResource(R.drawable.be);
			} else if (config.contains("BE")) {
				iv.setImageResource(R.drawable.be);
			} else if (config.contains("bf")) {
				iv.setImageResource(R.drawable.bf);
			} else if (config.contains("BF")) {
				iv.setImageResource(R.drawable.bf);
			} else if (config.contains("bh")) {
				iv.setImageResource(R.drawable.bh);
			} else if (config.contains("BH")) {
				iv.setImageResource(R.drawable.bh);
			} else if (config.contains("bi")) {
				iv.setImageResource(R.drawable.bi);
			} else if (config.contains("BI")) {
				iv.setImageResource(R.drawable.bi);
			} else if (config.contains("bj")) {
				iv.setImageResource(R.drawable.bj);
			} else if (config.contains("BJ")) {
				iv.setImageResource(R.drawable.bj);
			} else if (config.contains("bn")) {
				iv.setImageResource(R.drawable.bn);
			} else if (config.contains("BN")) {
				iv.setImageResource(R.drawable.bn);
			} else if (config.contains("bo")) {
				iv.setImageResource(R.drawable.bo);
			} else if (config.contains("BO")) {
				iv.setImageResource(R.drawable.bo);
			} else if (config.contains("br")) {
				iv.setImageResource(R.drawable.br);
			} else if (config.contains("BR")) {
				iv.setImageResource(R.drawable.br);
			} else if (config.contains("bs")) {
				iv.setImageResource(R.drawable.bs);
			} else if (config.contains("BS")) {
				iv.setImageResource(R.drawable.bs);
			} else if (config.contains("bt")) {
				iv.setImageResource(R.drawable.bt);
			} else if (config.contains("BT")) {
				iv.setImageResource(R.drawable.bt);
			} else if (config.contains("bw")) {
				iv.setImageResource(R.drawable.bw);
			} else if (config.contains("BW")) {
				iv.setImageResource(R.drawable.bw);
			} else if (config.contains("by")) {
				iv.setImageResource(R.drawable.by);
			} else if (config.contains("BY")) {
				iv.setImageResource(R.drawable.by);
			} else if (config.contains("bz")) {
				iv.setImageResource(R.drawable.bz);
			} else if (config.contains("BZ")) {
				iv.setImageResource(R.drawable.bz);
			} else if (config.contains("ca")) {
				iv.setImageResource(R.drawable.ca);
			} else if (config.contains("CA")) {
				iv.setImageResource(R.drawable.ca);
			} else if (config.contains("cd")) {
				iv.setImageResource(R.drawable.cd);
			} else if (config.contains("CD")) {
				iv.setImageResource(R.drawable.cd);
			} else if (config.contains("cf")) {
				iv.setImageResource(R.drawable.cf);
			} else if (config.contains("CF")) {
				iv.setImageResource(R.drawable.cf);
			} else if (config.contains("cg")) {
				iv.setImageResource(R.drawable.cg);
			} else if (config.contains("CG")) {
				iv.setImageResource(R.drawable.cg);
			} else if (config.contains("ch")) {
				iv.setImageResource(R.drawable.ch);
			} else if (config.contains("CH")) {
				iv.setImageResource(R.drawable.ch);
			} else if (config.contains("ci")) {
				iv.setImageResource(R.drawable.ci);
			} else if (config.contains("CI")) {
				iv.setImageResource(R.drawable.ci);
			} else if (config.contains("cl")) {
				iv.setImageResource(R.drawable.cl);
			} else if (config.contains("CL")) {
				iv.setImageResource(R.drawable.cl);
			} else if (config.contains("cm")) {
				iv.setImageResource(R.drawable.cm);
			} else if (config.contains("CM")) {
				iv.setImageResource(R.drawable.cm);
			} else if (config.contains("cn")) {
				iv.setImageResource(R.drawable.cn);
			} else if (config.contains("CN")) {
				iv.setImageResource(R.drawable.cn);
			} else if (config.contains("co")) {
				iv.setImageResource(R.drawable.co);
			} else if (config.contains("CO")) {
				iv.setImageResource(R.drawable.co);
			} else if (config.contains("cr")) {
				iv.setImageResource(R.drawable.cr);
			} else if (config.contains("CR")) {
				iv.setImageResource(R.drawable.cr);
			} else if (config.contains("cu")) {
				iv.setImageResource(R.drawable.cu);
			} else if (config.contains("CU")) {
				iv.setImageResource(R.drawable.cu);
			} else if (config.contains("cv")) {
				iv.setImageResource(R.drawable.cv);
			} else if (config.contains("CV")) {
				iv.setImageResource(R.drawable.cv);
			} else if (config.contains("cy")) {
				iv.setImageResource(R.drawable.cy);
			} else if (config.contains("CY")) {
				iv.setImageResource(R.drawable.cy);
			} else if (config.contains("cz")) {
				iv.setImageResource(R.drawable.cz);
			} else if (config.contains("CZ")) {
				iv.setImageResource(R.drawable.cz);
			} else if (config.contains("de")) {
				iv.setImageResource(R.drawable.de);
			} else if (config.contains("DE")) {
				iv.setImageResource(R.drawable.de);
			} else if (config.contains("dj")) {
				iv.setImageResource(R.drawable.dj);
			} else if (config.contains("DJ")) {
				iv.setImageResource(R.drawable.dj);
			} else if (config.contains("dk")) {
				iv.setImageResource(R.drawable.dk);
			} else if (config.contains("DK")) {
				iv.setImageResource(R.drawable.dk);
			} else if (config.contains("dm")) {
				iv.setImageResource(R.drawable.dm);
			} else if (config.contains("DM")) {
				iv.setImageResource(R.drawable.dm);
			} else if (config.contains("dz")) {
				iv.setImageResource(R.drawable.dz);
			} else if (config.contains("DZ")) {
				iv.setImageResource(R.drawable.dz);
			} else if (config.contains("ec")) {
				iv.setImageResource(R.drawable.ec);
			} else if (config.contains("EC")) {
				iv.setImageResource(R.drawable.ec);
			} else if (config.contains("ee")) {
				iv.setImageResource(R.drawable.ee);
			} else if (config.contains("EE")) {
				iv.setImageResource(R.drawable.ee);
			} else if (config.contains("eg")) {
				iv.setImageResource(R.drawable.eg);
			} else if (config.contains("EG")) {
				iv.setImageResource(R.drawable.eg);
			} else if (config.contains("eh")) {
				iv.setImageResource(R.drawable.eh);
			} else if (config.contains("EH")) {
				iv.setImageResource(R.drawable.eh);
			} else if (config.contains("er")) {
				iv.setImageResource(R.drawable.er);
			} else if (config.contains("ER")) {
				iv.setImageResource(R.drawable.er);
			} else if (config.contains("es")) {
				iv.setImageResource(R.drawable.es);
			} else if (config.contains("ES")) {
				iv.setImageResource(R.drawable.es);
			} else if (config.contains("et")) {
				iv.setImageResource(R.drawable.et);
			} else if (config.contains("ET")) {
				iv.setImageResource(R.drawable.et);
			} else if (config.contains("fi")) {
				iv.setImageResource(R.drawable.fi);
			} else if (config.contains("FI")) {
				iv.setImageResource(R.drawable.fi);
			} else if (config.contains("fj")) {
				iv.setImageResource(R.drawable.fj);
			} else if (config.contains("FJ")) {
				iv.setImageResource(R.drawable.fj);
			} else if (config.contains("fm")) {
				iv.setImageResource(R.drawable.fm);
			} else if (config.contains("FM")) {
				iv.setImageResource(R.drawable.fm);
			} else if (config.contains("fr")) {
				iv.setImageResource(R.drawable.fr);
			} else if (config.contains("FR")) {
				iv.setImageResource(R.drawable.fr);
			} else if (config.contains("ga")) {
				iv.setImageResource(R.drawable.ga);
			} else if (config.contains("GA")) {
				iv.setImageResource(R.drawable.ga);
			} else if (config.contains("gb")) {
				iv.setImageResource(R.drawable.gb);
			} else if (config.contains("GB")) {
				iv.setImageResource(R.drawable.gb);
			} else if (config.contains("gd")) {
				iv.setImageResource(R.drawable.gd);
			} else if (config.contains("GD")) {
				iv.setImageResource(R.drawable.gd);
			} else if (config.contains("ge")) {
				iv.setImageResource(R.drawable.ge);
			} else if (config.contains("GE")) {
				iv.setImageResource(R.drawable.ge);
			} else if (config.contains("gh")) {
				iv.setImageResource(R.drawable.gh);
			} else if (config.contains("GH")) {
				iv.setImageResource(R.drawable.gh);
			} else if (config.contains("gm")) {
				iv.setImageResource(R.drawable.gm);
			} else if (config.contains("GM")) {
				iv.setImageResource(R.drawable.gm);
			} else if (config.contains("gn")) {
				iv.setImageResource(R.drawable.gn);
			} else if (config.contains("GN")) {
				iv.setImageResource(R.drawable.gn);
			} else if (config.contains("gq")) {
				iv.setImageResource(R.drawable.gq);
			} else if (config.contains("GQ")) {
				iv.setImageResource(R.drawable.gq);
			} else if (config.contains("gr")) {
				iv.setImageResource(R.drawable.gr);
			} else if (config.contains("GR")) {
				iv.setImageResource(R.drawable.gr);
			} else if (config.contains("gt")) {
				iv.setImageResource(R.drawable.gt);
			} else if (config.contains("GT")) {
				iv.setImageResource(R.drawable.gt);
			} else if (config.contains("gw")) {
				iv.setImageResource(R.drawable.gw);
			} else if (config.contains("GW")) {
				iv.setImageResource(R.drawable.gw);
			} else if (config.contains("gy")) {
				iv.setImageResource(R.drawable.gy);
			} else if (config.contains("GY")) {
				iv.setImageResource(R.drawable.gy);
			} else if (config.contains("hk")) {
				iv.setImageResource(R.drawable.hk);
			} else if (config.contains("HK")) {
				iv.setImageResource(R.drawable.hk);
			} else if (config.contains("hn")) {
				iv.setImageResource(R.drawable.hn);
			} else if (config.contains("HN")) {
				iv.setImageResource(R.drawable.hn);
			} else if (config.contains("hr")) {
				iv.setImageResource(R.drawable.hr);
			} else if (config.contains("HR")) {
				iv.setImageResource(R.drawable.hr);
			} else if (config.contains("ht")) {
				iv.setImageResource(R.drawable.ht);
			} else if (config.contains("HT")) {
				iv.setImageResource(R.drawable.ht);
			} else if (config.contains("hu")) {
				iv.setImageResource(R.drawable.hu);
			} else if (config.contains("HU")) {
				iv.setImageResource(R.drawable.hu);
			} else if (config.contains("id")) {
				iv.setImageResource(R.drawable.id);
			} else if (config.contains("ID")) {
				iv.setImageResource(R.drawable.id);
			} else if (config.contains("ie")) {
				iv.setImageResource(R.drawable.ie);
			} else if (config.contains("IE")) {
				iv.setImageResource(R.drawable.ie);
			} else if (config.contains("il")) {
				iv.setImageResource(R.drawable.il);
			} else if (config.contains("IL")) {
				iv.setImageResource(R.drawable.il);
			} else if (config.contains("in")) {
				iv.setImageResource(R.drawable.in);
			} else if (config.contains("IN")) {
				iv.setImageResource(R.drawable.in);
			} else if (config.contains("iq")) {
				iv.setImageResource(R.drawable.iq);
			} else if (config.contains("IQ")) {
				iv.setImageResource(R.drawable.iq);
			} else if (config.contains("ir")) {
				iv.setImageResource(R.drawable.ir);
			} else if (config.contains("IR")) {
				iv.setImageResource(R.drawable.ir);
			} else if (config.contains("is")) {
				iv.setImageResource(R.drawable.is);
			} else if (config.contains("IS")) {
				iv.setImageResource(R.drawable.is);
			} else if (config.contains("it")) {
				iv.setImageResource(R.drawable.it);
			} else if (config.contains("IT")) {
				iv.setImageResource(R.drawable.it);
			} else if (config.contains("jm")) {
				iv.setImageResource(R.drawable.jm);
			} else if (config.contains("JM")) {
				iv.setImageResource(R.drawable.jm);
			} else if (config.contains("jo")) {
				iv.setImageResource(R.drawable.jo);
			} else if (config.contains("JO")) {
				iv.setImageResource(R.drawable.jo);
			} else if (config.contains("jp")) {
				iv.setImageResource(R.drawable.jp);
			} else if (config.contains("JP")) {
				iv.setImageResource(R.drawable.jp);
			} else if (config.contains("ke")) {
				iv.setImageResource(R.drawable.ke);
			} else if (config.contains("KE")) {
				iv.setImageResource(R.drawable.ke);
			} else if (config.contains("kg")) {
				iv.setImageResource(R.drawable.kg);
			} else if (config.contains("KG")) {
				iv.setImageResource(R.drawable.kg);
			} else if (config.contains("kh")) {
				iv.setImageResource(R.drawable.kh);
			} else if (config.contains("KH")) {
				iv.setImageResource(R.drawable.kh);
			} else if (config.contains("ki")) {
				iv.setImageResource(R.drawable.ki);
			} else if (config.contains("KI")) {
				iv.setImageResource(R.drawable.ki);
			} else if (config.contains("km")) {
				iv.setImageResource(R.drawable.km);
			} else if (config.contains("KM")) {
				iv.setImageResource(R.drawable.km);
			} else if (config.contains("kn")) {
				iv.setImageResource(R.drawable.kn);
			} else if (config.contains("KN")) {
				iv.setImageResource(R.drawable.kn);
			} else if (config.contains("kp")) {
				iv.setImageResource(R.drawable.kp);
			} else if (config.contains("KP")) {
				iv.setImageResource(R.drawable.kp);
			} else if (config.contains("kr")) {
				iv.setImageResource(R.drawable.kr);
			} else if (config.contains("KR")) {
				iv.setImageResource(R.drawable.kr);
			} else if (config.contains("ks")) {
				iv.setImageResource(R.drawable.ks);
			} else if (config.contains("KS")) {
				iv.setImageResource(R.drawable.ks);
			} else if (config.contains("kw")) {
				iv.setImageResource(R.drawable.kw);
			} else if (config.contains("KW")) {
				iv.setImageResource(R.drawable.kw);
			} else if (config.contains("kz")) {
				iv.setImageResource(R.drawable.kz);
			} else if (config.contains("KZ")) {
				iv.setImageResource(R.drawable.kz);
			} else if (config.contains("la")) {
				iv.setImageResource(R.drawable.la);
			} else if (config.contains("LA")) {
				iv.setImageResource(R.drawable.la);
			} else if (config.contains("lb")) {
				iv.setImageResource(R.drawable.lb);
			} else if (config.contains("LB")) {
				iv.setImageResource(R.drawable.lb);
			} else if (config.contains("lc")) {
				iv.setImageResource(R.drawable.lc);
			} else if (config.contains("LC")) {
				iv.setImageResource(R.drawable.lc);
			} else if (config.contains("li")) {
				iv.setImageResource(R.drawable.li);
			} else if (config.contains("LI")) {
				iv.setImageResource(R.drawable.li);
			} else if (config.contains("lk")) {
				iv.setImageResource(R.drawable.lk);
			} else if (config.contains("LK")) {
				iv.setImageResource(R.drawable.lk);
			} else if (config.contains("lr")) {
				iv.setImageResource(R.drawable.lr);
			} else if (config.contains("LR")) {
				iv.setImageResource(R.drawable.lr);
			} else if (config.contains("ls")) {
				iv.setImageResource(R.drawable.ls);
			} else if (config.contains("LS")) {
				iv.setImageResource(R.drawable.ls);
			} else if (config.contains("lt")) {
				iv.setImageResource(R.drawable.lt);
			} else if (config.contains("LT")) {
				iv.setImageResource(R.drawable.lt);
			} else if (config.contains("lu")) {
				iv.setImageResource(R.drawable.lu);
			} else if (config.contains("LU")) {
				iv.setImageResource(R.drawable.lu);
			} else if (config.contains("lv")) {
				iv.setImageResource(R.drawable.lv);
			} else if (config.contains("LV")) {
				iv.setImageResource(R.drawable.lv);
			} else if (config.contains("ly")) {
				iv.setImageResource(R.drawable.ly);
			} else if (config.contains("LY")) {
				iv.setImageResource(R.drawable.ly);
			} else if (config.contains("ma")) {
				iv.setImageResource(R.drawable.ma);
			} else if (config.contains("MA")) {
				iv.setImageResource(R.drawable.ma);
			} else if (config.contains("mc")) {
				iv.setImageResource(R.drawable.mc);
			} else if (config.contains("MC")) {
				iv.setImageResource(R.drawable.mc);
			} else if (config.contains("md")) {
				iv.setImageResource(R.drawable.md);
			} else if (config.contains("MD")) {
				iv.setImageResource(R.drawable.md);
			} else if (config.contains("me")) {
				iv.setImageResource(R.drawable.me);
			} else if (config.contains("ME")) {
				iv.setImageResource(R.drawable.me);
			} else if (config.contains("mg")) {
				iv.setImageResource(R.drawable.mg);
			} else if (config.contains("MG")) {
				iv.setImageResource(R.drawable.mg);
			} else if (config.contains("mh")) {
				iv.setImageResource(R.drawable.mh);
			} else if (config.contains("MH")) {
				iv.setImageResource(R.drawable.mh);
			} else if (config.contains("mk")) {
				iv.setImageResource(R.drawable.mk);
			} else if (config.contains("MK")) {
				iv.setImageResource(R.drawable.mk);
			} else if (config.contains("ml")) {
				iv.setImageResource(R.drawable.ml);
			} else if (config.contains("ML")) {
				iv.setImageResource(R.drawable.ml);
			} else if (config.contains("mm")) {
				iv.setImageResource(R.drawable.mm);
			} else if (config.contains("MM")) {
				iv.setImageResource(R.drawable.mm);
			} else if (config.contains("mn")) {
				iv.setImageResource(R.drawable.mn);
			} else if (config.contains("MN")) {
				iv.setImageResource(R.drawable.mn);
			} else if (config.contains("mu")) {
				iv.setImageResource(R.drawable.mu);
			} else if (config.contains("MU")) {
				iv.setImageResource(R.drawable.mu);
			} else if (config.contains("mv")) {
				iv.setImageResource(R.drawable.mv);
			} else if (config.contains("MV")) {
				iv.setImageResource(R.drawable.mv);
			} else if (config.contains("mw")) {
				iv.setImageResource(R.drawable.mw);
			} else if (config.contains("MW")) {
				iv.setImageResource(R.drawable.mw);
			} else if (config.contains("mx")) {
				iv.setImageResource(R.drawable.mx);
			} else if (config.contains("MX")) {
				iv.setImageResource(R.drawable.mx);
			} else if (config.contains("my")) {
				iv.setImageResource(R.drawable.my);
			} else if (config.contains("MY")) {
				iv.setImageResource(R.drawable.my);
			} else if (config.contains("mz")) {
				iv.setImageResource(R.drawable.mz);
			} else if (config.contains("MZ")) {
				iv.setImageResource(R.drawable.mz);
			} else if (config.contains("na")) {
				iv.setImageResource(R.drawable.na);
			} else if (config.contains("NA")) {
				iv.setImageResource(R.drawable.na);
			} else if (config.contains("ng")) {
				iv.setImageResource(R.drawable.ng);
			} else if (config.contains("NG")) {
				iv.setImageResource(R.drawable.ng);
			} else if (config.contains("ni")) {
				iv.setImageResource(R.drawable.ni);
			} else if (config.contains("NI")) {
				iv.setImageResource(R.drawable.ni);
			} else if (config.contains("nl")) {
				iv.setImageResource(R.drawable.nl);
			} else if (config.contains("NL")) {
				iv.setImageResource(R.drawable.nl);
			} else if (config.contains("no")) {
				iv.setImageResource(R.drawable.no);
			} else if (config.contains("NO")) {
				iv.setImageResource(R.drawable.no);
			} else if (config.contains("np")) {
				iv.setImageResource(R.drawable.np);
			} else if (config.contains("NP")) {
				iv.setImageResource(R.drawable.np);
			} else if (config.contains("nr")) {
				iv.setImageResource(R.drawable.nr);
			} else if (config.contains("NR")) {
				iv.setImageResource(R.drawable.nr);
			} else if (config.contains("nz")) {
				iv.setImageResource(R.drawable.nz);
			} else if (config.contains("NZ")) {
				iv.setImageResource(R.drawable.nz);
			} else if (config.contains("om")) {
				iv.setImageResource(R.drawable.om);
			} else if (config.contains("OM")) {
				iv.setImageResource(R.drawable.om);
			} else if (config.contains("pa")) {
				iv.setImageResource(R.drawable.pa);
			} else if (config.contains("PA")) {
				iv.setImageResource(R.drawable.pa);
			} else if (config.contains("pe")) {
				iv.setImageResource(R.drawable.pe);
			} else if (config.contains("PE")) {
				iv.setImageResource(R.drawable.pe);
			} else if (config.contains("pg")) {
				iv.setImageResource(R.drawable.pg);
			} else if (config.contains("PG")) {
				iv.setImageResource(R.drawable.pg);
			} else if (config.contains("ph")) {
				iv.setImageResource(R.drawable.ph);
			} else if (config.contains("PH")) {
				iv.setImageResource(R.drawable.ph);
			} else if (config.contains("pk")) {
				iv.setImageResource(R.drawable.pk);
			} else if (config.contains("PK")) {
				iv.setImageResource(R.drawable.pk);
			} else if (config.contains("pl")) {
				iv.setImageResource(R.drawable.pl);
			} else if (config.contains("PL")) {
				iv.setImageResource(R.drawable.pl);
			} else if (config.contains("pt")) {
				iv.setImageResource(R.drawable.pt);
			} else if (config.contains("PT")) {
				iv.setImageResource(R.drawable.pt);
			} else if (config.contains("pw")) {
				iv.setImageResource(R.drawable.pw);
			} else if (config.contains("PW")) {
				iv.setImageResource(R.drawable.pw);
			} else if (config.contains("pw")) {
				iv.setImageResource(R.drawable.pw);
			} else if (config.contains("PW")) {
				iv.setImageResource(R.drawable.pw);
			} else if (config.contains("qa")) {
				iv.setImageResource(R.drawable.qa);
			} else if (config.contains("QA")) {
				iv.setImageResource(R.drawable.qa);
			} else if (config.contains("ro")) {
				iv.setImageResource(R.drawable.ro);
			} else if (config.contains("RO")) {
				iv.setImageResource(R.drawable.ro);
			} else if (config.contains("rs")) {
				iv.setImageResource(R.drawable.rs);
			} else if (config.contains("RS")) {
				iv.setImageResource(R.drawable.rs);
			} else if (config.contains("ru")) {
				iv.setImageResource(R.drawable.ru);
			} else if (config.contains("RU")) {
				iv.setImageResource(R.drawable.ru);
			} else if (config.contains("rw")) {
				iv.setImageResource(R.drawable.rw);
			} else if (config.contains("RW")) {
				iv.setImageResource(R.drawable.rw);
			} else if (config.contains("sa")) {
				iv.setImageResource(R.drawable.sa);
			} else if (config.contains("SA")) {
				iv.setImageResource(R.drawable.sa);
			} else if (config.contains("sb")) {
				iv.setImageResource(R.drawable.sb);
			} else if (config.contains("SB")) {
				iv.setImageResource(R.drawable.sb);
			} else if (config.contains("sc")) {
				iv.setImageResource(R.drawable.sc);
			} else if (config.contains("SC")) {
				iv.setImageResource(R.drawable.sc);
			} else if (config.contains("sd")) {
				iv.setImageResource(R.drawable.sd);
			} else if (config.contains("SD")) {
				iv.setImageResource(R.drawable.sd);
			} else if (config.contains("se")) {
				iv.setImageResource(R.drawable.se);
			} else if (config.contains("SE")) {
				iv.setImageResource(R.drawable.se);
			} else if (config.contains("sg")) {
				iv.setImageResource(R.drawable.sg);
			} else if (config.contains("SG")) {
				iv.setImageResource(R.drawable.sg);
			} else if (config.contains("si")) {
				iv.setImageResource(R.drawable.si);
			} else if (config.contains("SI")) {
				iv.setImageResource(R.drawable.si);
			} else if (config.contains("sk")) {
				iv.setImageResource(R.drawable.sk);
			} else if (config.contains("SK")) {
				iv.setImageResource(R.drawable.sk);
			} else if (config.contains("sl")) {
				iv.setImageResource(R.drawable.sl);
			} else if (config.contains("SL")) {
				iv.setImageResource(R.drawable.sl);
			} else if (config.contains("sm")) {
				iv.setImageResource(R.drawable.sm);
			} else if (config.contains("SM")) {
				iv.setImageResource(R.drawable.sm);
			} else if (config.contains("sn")) {
				iv.setImageResource(R.drawable.sn);
			} else if (config.contains("SN")) {
				iv.setImageResource(R.drawable.sn);
			} else if (config.contains("so")) {
				iv.setImageResource(R.drawable.so);
			} else if (config.contains("SO")) {
				iv.setImageResource(R.drawable.so);
			} else if (config.contains("sr")) {
				iv.setImageResource(R.drawable.sr);
			} else if (config.contains("SR")) {
				iv.setImageResource(R.drawable.sr);
			} else if (config.contains("st")) {
				iv.setImageResource(R.drawable.st);
			} else if (config.contains("ST")) {
				iv.setImageResource(R.drawable.st);
			} else if (config.contains("sv")) {
				iv.setImageResource(R.drawable.sv);
			} else if (config.contains("SV")) {
				iv.setImageResource(R.drawable.sv);
			} else if (config.contains("sy")) {
				iv.setImageResource(R.drawable.sy);
			} else if (config.contains("SY")) {
				iv.setImageResource(R.drawable.sy);
			} else if (config.contains("sz")) {
				iv.setImageResource(R.drawable.sz);
			} else if (config.contains("SZ")) {
				iv.setImageResource(R.drawable.sz);
			} else if (config.contains("td")) {
				iv.setImageResource(R.drawable.td);
			} else if (config.contains("TD")) {
				iv.setImageResource(R.drawable.td);
			} else if (config.contains("tg")) {
				iv.setImageResource(R.drawable.tg);
			} else if (config.contains("TG")) {
				iv.setImageResource(R.drawable.tg);
			} else if (config.contains("th")) {
				iv.setImageResource(R.drawable.th);
			} else if (config.contains("TH")) {
				iv.setImageResource(R.drawable.th);
			} else if (config.contains("tj")) {
				iv.setImageResource(R.drawable.tj);
			} else if (config.contains("TJ")) {
				iv.setImageResource(R.drawable.tj);
			} else if (config.contains("tl")) {
				iv.setImageResource(R.drawable.tl);
			} else if (config.contains("TL")) {
				iv.setImageResource(R.drawable.tl);
			} else if (config.contains("tm")) {
				iv.setImageResource(R.drawable.tm);
			} else if (config.contains("TM")) {
				iv.setImageResource(R.drawable.tm);
			} else if (config.contains("tn")) {
				iv.setImageResource(R.drawable.tn);
			} else if (config.contains("TN")) {
				iv.setImageResource(R.drawable.tn);
			} else if (config.contains("to")) {
				iv.setImageResource(R.drawable.to);
			} else if (config.contains("TO")) {
				iv.setImageResource(R.drawable.to);
			} else if (config.contains("tr")) {
				iv.setImageResource(R.drawable.tr);
			} else if (config.contains("TR")) {
				iv.setImageResource(R.drawable.tr);
			} else if (config.contains("tt")) {
				iv.setImageResource(R.drawable.tt);
			} else if (config.contains("TT")) {
				iv.setImageResource(R.drawable.tt);
			} else if (config.contains("tv")) {
				iv.setImageResource(R.drawable.tv);
			} else if (config.contains("TV")) {
				iv.setImageResource(R.drawable.tv);
			} else if (config.contains("tw")) {
				iv.setImageResource(R.drawable.tw);
			} else if (config.contains("TW")) {
				iv.setImageResource(R.drawable.tw);
			} else if (config.contains("tz")) {
				iv.setImageResource(R.drawable.tz);
			} else if (config.contains("TZ")) {
				iv.setImageResource(R.drawable.tz);
			} else if (config.contains("ua")) {
				iv.setImageResource(R.drawable.ua);
			} else if (config.contains("UA")) {
				iv.setImageResource(R.drawable.ua);
			} else if (config.contains("ug")) {
				iv.setImageResource(R.drawable.ug);
			} else if (config.contains("UG")) {
				iv.setImageResource(R.drawable.ug);
			} else if (config.contains("uk")) {
				iv.setImageResource(R.drawable.uk);
			} else if (config.contains("UK")) {
				iv.setImageResource(R.drawable.uk);
			} else if (config.contains("us")) {
				iv.setImageResource(R.drawable.us);
			} else if (config.contains("US")) {
				iv.setImageResource(R.drawable.us);
			} else if (config.contains("uy")) {
				iv.setImageResource(R.drawable.uy);
			} else if (config.contains("UY")) {
				iv.setImageResource(R.drawable.uy);
			} else if (config.contains("uz")) {
				iv.setImageResource(R.drawable.uz);
			} else if (config.contains("UZ")) {
				iv.setImageResource(R.drawable.uz);
			} else if (config.contains("va")) {
				iv.setImageResource(R.drawable.va);
			} else if (config.contains("VA")) {
				iv.setImageResource(R.drawable.va);
			} else if (config.contains("vc")) {
				iv.setImageResource(R.drawable.vc);
			} else if (config.contains("VC")) {
				iv.setImageResource(R.drawable.vc);
			} else if (config.contains("ve")) {
				iv.setImageResource(R.drawable.ve);
			} else if (config.contains("VE")) {
				iv.setImageResource(R.drawable.ve);
			} else if (config.contains("vn")) {
				iv.setImageResource(R.drawable.vn);
			} else if (config.contains("VN")) {
				iv.setImageResource(R.drawable.vn);
			} else if (config.contains("vu")) {
				iv.setImageResource(R.drawable.vu);
			} else if (config.contains("VU")) {
				iv.setImageResource(R.drawable.vu);
			} else if (config.contains("ws")) {
				iv.setImageResource(R.drawable.ws);
			} else if (config.contains("WS")) {
				iv.setImageResource(R.drawable.ws);
			} else if (config.contains("ye")) {
				iv.setImageResource(R.drawable.ye);
			} else if (config.contains("YE")) {
				iv.setImageResource(R.drawable.ye);
			} else if (config.contains("za")) {
				iv.setImageResource(R.drawable.za);
			} else if (config.contains("ZA")) {
				iv.setImageResource(R.drawable.za);
			} else if (config.contains("zm")) {
				iv.setImageResource(R.drawable.zm);
			} else if (config.contains("ZM")) {
				iv.setImageResource(R.drawable.zm);
			} else if (config.contains("zw")) {
				iv.setImageResource(R.drawable.zw);
			} else if (config.contains("ZW")) {
				iv.setImageResource(R.drawable.zw);
			
			} else {
				iv.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
			}
			// TODO: Implement this method
			return v;
		}

	}
	
}

	

	
