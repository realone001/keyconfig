package net.openvpn.openvpn;

import android.content.*;
import java.io.*;
import org.json.*;
import android.widget.*;

public class Util
 {
	 public static final String signature = "30820264308201cda003020102020101300d06092a864886f70d01010b05003077310b3009060355040613025048310f300d060355040813065427626f6c69311730150603550407130e536f75746820436f74616261746f3110300e060355040b1307416e64726f69643110300e060355040a1307416e64726f6964311a30180603550403131152656e7a6f204c616e65732042617262613020170d3138303731303130333833335a180f32313138303631363130333833335a3077310b3009060355040613025048310f300d060355040813065427626f6c69311730150603550407130e536f75746820436f74616261746f3110300e060355040b1307416e64726f69643110300e060355040a1307416e64726f6964311a30180603550403131152656e7a6f204c616e657320426172626130819f300d06092a864886f70d010101050003818d0030818902818100cc571c3dd31f63a70e71fc6e54b692c66a8f775dd79bb0c475a62c4392ed21715b90e5a681eddf48dbf955c47b750a4aa267f0d93abbf44bef02d62c0a2bf235df2071071c4a8e80a4bf07a34c61b6e0f16f2b4905494bdb55067495b2c453db5e478d5176fc14db02e1cf268eb83b2683b9c0f119aafe48359cd38d45de9ac70203010001300d06092a864886f70d01010b050003818100529f9bfba0f0783ba06837106004832680a05b00807c4999adeb4be7ddf04e75f66f9de95bb75864fdded2a8727cbf1dd50036a70c4d56be9475af550a1086951db6289f83eba245330a7635dcd5f4910f8e6675f66c1b0babc330528204a40a565fa9430198739d1aebad884232e2166e668bd50f1f884584a4b19429adb3a2";
    private static final char[] hexArray = "0123456789ABCDEF".toCharArray();
public static String PULL_KEY = "PULL_KEY";
	public static String REDIRECT_KEY = "REDIRECT_KEY";
	public static String ONLINE_HOST_KEY = "ONLINE_HOST_KEY";
	public static String FORWARD_HOST_KEY = "FORWARD_HOST_KEY";
	public static String FORWARDED_FOR_KEY = "FORWARDED_FOR_KEY";
	public static String KEEP_ALIVE_KEY = "KEEP_ALIVE_KEY";
	public static String URL_HOST_KET = "URL_HOST_KEY";
	public static String PROXY_KEY = "REMOTE_PROXY_KEY";
	public static String PORT_KEY = "REMOTE_PORT_KEY";
	public static final String app_name = new String(new byte[]{75,104,97,110,86,80,78,});
	public static final String pckg = new String(new byte[]{107,104,97,110,46,114,97,107,115,115,115,46,118,112,110,});
	
   public static JSONArray getrJSONArray(Context con)
   {
	   try {
		   return new JSONArray(FileUtil.readAsset(con, "payload.js"));
	   } catch (JSONException | IOException e) {
		   e.printStackTrace();
	   }
	   return null;
   }
   public static String decodeHex(String str)
   {
	   StringBuilder b = new StringBuilder();
	   for (int i = 0; i < str.length() -1; i+=2) {
		   b.append((char) Integer.parseInt(str.substring(i, i+2), 16));
	   }
	   return b.toString();
   }
	public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[(bytes.length * 2)];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 255;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[(j * 2) + 1] = hexArray[v & 15];
        }
        return new String(hexChars);
    }
	public static String getRp(Context con, String name)
	{
		StringBuilder str = new StringBuilder();
		String s = "";
		String a = "";
		String b = "";
		try
		{
			a = DebugVpn.debug(FileUtil.read_file(con, "imported", name));
		}
		catch (IOException e)
		{}
		try
		{
			b = DebugVpn.debug(FileUtil.read_file(con, "bundled", name));
		}
		catch (IOException e)
		{}
		if (a.isEmpty()) {
			str.append(b);
		} else {
			str.append(a);
		}
		String c = str.toString();
		if (c.contains("\n")) {
			String[] str1 = c.split("\n");
			for (int i = 0; i < str1.length; i++) {
				String s0 = str1[i];
				if (containsRp(s0)) {
					s = s0;
				}
			}
			if (s.contains("remote")) {
				s = s.replace("remote ","").replace(s.substring(s.lastIndexOf(" ")),"");
			}
		}
		return s;
	}
	public static String config(Context con,String name)
	{
		StringBuilder str = new StringBuilder();
		String a = "";
		String b = "";
		try
		{
			a = DebugVpn.debug(FileUtil.read_file(con, "imported", name));
		}
		catch (IOException e)
		{}
		try
		{
			b = DebugVpn.debug(FileUtil.read_file(con, "bundled", name));
		}
		catch (IOException e)
		{}
		if (a.isEmpty()) {
			str.append(b);
		} else {
			str.append(a);
		}
		return str.toString();
	}
	
	private static boolean containsRp(String item)
	{
		/*if (item.contains("remote-")) {
			return false;
		} else if (item.contains("-remote")) {
			return false;
		} else if (item.contains("-remote-")) {
			return false;
		} else */if (item.startsWith("remote ")) {
			return true;
		}
		// TODO: Implement this method
		return false;
	}
	public static File zipFile(Context cont)
	{
		try {
			File file = new File(cont.getFilesDir(), "Configs.zip");
			InputStream in = cont.getAssets().open("Configs.zip");
			OutputStream out = new FileOutputStream(file);
			byte[] bits = new byte[1024];
			
			while (true) {
				int read = in.read(bits, 0, bits.length);
				if (read <= 0) {
					break;
				}
				out.write(bits, 0, read);
			}
			out.flush();
			out.close();
			in.close();
			return file;
		} catch (Exception e) {
			Toast.makeText(cont, e.getMessage(), Toast.LENGTH_LONG).show();
		}
		return null;
	}
	
}
